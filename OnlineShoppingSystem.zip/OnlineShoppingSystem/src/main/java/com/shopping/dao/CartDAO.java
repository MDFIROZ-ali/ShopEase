package com.shopping.dao;

import com.shopping.model.Cart;
import com.shopping.model.Product;
import com.shopping.db.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CartDAO {
    private ProductDAO productDAO = new ProductDAO();
    
    // Add to cart
    public boolean addToCart(int userId, int productId, int quantity) {
        // Check if product already in cart
        String checkSql = "SELECT id, quantity FROM cart WHERE user_id = ? AND product_id = ?";
        try (ResultSet rs = DatabaseConnection.executeQuery(checkSql, userId, productId)) {
            if (rs.next()) {
                // Update quantity
                int newQuantity = rs.getInt("quantity") + quantity;
                String updateSql = "UPDATE cart SET quantity = ? WHERE id = ?";
                int result = DatabaseConnection.executeUpdate(updateSql, newQuantity, rs.getInt("id"));
                return result > 0;
            } else {
                // Add new item
                String insertSql = "INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)";
                int result = DatabaseConnection.executeInsert(insertSql, userId, productId, quantity);
                return result > 0;
            }
        } catch (SQLException e) {
            System.err.println("Add to cart error: " + e.getMessage());
            return false;
        }
    }
    
    // Get cart items
    public List<Cart> getCartItems(int userId) {
        List<Cart> cartItems = new ArrayList<>();
        String sql = "SELECT * FROM cart WHERE user_id = ?";
        try (ResultSet rs = DatabaseConnection.executeQuery(sql, userId)) {
            while (rs.next()) {
                Cart cart = new Cart();
                cart.setId(rs.getInt("id"));
                cart.setUserId(rs.getInt("user_id"));
                cart.setProductId(rs.getInt("product_id"));
                cart.setQuantity(rs.getInt("quantity"));
                
                // Get product details
                Product product = productDAO.getProductById(cart.getProductId());
                cart.setProduct(product);
                
                cartItems.add(cart);
            }
        } catch (SQLException e) {
            System.err.println("Get cart error: " + e.getMessage());
        }
        return cartItems;
    }
    
    // Update cart quantity
    public boolean updateQuantity(int cartId, int quantity) {
        if (quantity <= 0) {
            return removeFromCart(cartId);
        }
        String sql = "UPDATE cart SET quantity = ? WHERE id = ?";
        try {
            int result = DatabaseConnection.executeUpdate(sql, quantity, cartId);
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Update quantity error: " + e.getMessage());
            return false;
        }
    }
    
    // Remove from cart
    public boolean removeFromCart(int cartId) {
        String sql = "DELETE FROM cart WHERE id = ?";
        try {
            int result = DatabaseConnection.executeUpdate(sql, cartId);
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Remove from cart error: " + e.getMessage());
            return false;
        }
    }
    
    // Clear cart
    public boolean clearCart(int userId) {
        String sql = "DELETE FROM cart WHERE user_id = ?";
        try {
            int result = DatabaseConnection.executeUpdate(sql, userId);
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Clear cart error: " + e.getMessage());
            return false;
        }
    }
    
    // Get cart total
    public double getCartTotal(int userId) {
        double total = 0;
        List<Cart> items = getCartItems(userId);
        for (Cart item : items) {
            total += item.getSubtotal();
        }
        return total;
    }
    
    // Get cart item count
    public int getCartCount(int userId) {
        String sql = "SELECT SUM(quantity) as count FROM cart WHERE user_id = ?";
        try (ResultSet rs = DatabaseConnection.executeQuery(sql, userId)) {
            if (rs.next()) {
                return rs.getInt("count");
            }
        } catch (SQLException e) {
            System.err.println("Cart count error: " + e.getMessage());
        }
        return 0;
    }
}