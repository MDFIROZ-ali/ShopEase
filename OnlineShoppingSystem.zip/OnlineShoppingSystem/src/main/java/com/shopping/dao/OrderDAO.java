package com.shopping.dao;

import com.shopping.model.Order;
import com.shopping.model.OrderItem;
import com.shopping.model.User;
import com.shopping.db.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class OrderDAO {
    private UserDAO userDAO = new UserDAO();
    private ProductDAO productDAO = new ProductDAO();
    
    // Create order
    public boolean createOrder(Order order, List<OrderItem> items) {
        try {
            // Generate order number
            String orderNumber = "ORD-" + System.currentTimeMillis();
            order.setOrderNumber(orderNumber);
            
            // Insert order
            String orderSql = "INSERT INTO orders (order_number, user_id, total_amount, discount, final_amount, " +
                             "shipping_address, city, state, pincode, payment_method, payment_status, order_status, notes) " +
                             "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            int orderId = DatabaseConnection.executeInsert(orderSql,
                order.getOrderNumber(),
                order.getUserId(),
                order.getTotalAmount(),
                order.getDiscount(),
                order.getFinalAmount(),
                order.getShippingAddress(),
                order.getCity(),
                order.getState(),
                order.getPincode(),
                order.getPaymentMethod(),
                "pending",
                "pending",
                order.getNotes()
            );
            
            if (orderId <= 0) return false;
            
            // Insert order items
            for (OrderItem item : items) {
                String itemSql = "INSERT INTO order_items (order_id, product_id, product_name, quantity, price, total) " +
                                "VALUES (?, ?, ?, ?, ?, ?)";
                
                DatabaseConnection.executeUpdate(itemSql,
                    orderId,
                    item.getProductId(),
                    item.getProductName(),
                    item.getQuantity(),
                    item.getPrice(),
                    item.getTotal()
                );
                
                // Update product stock
                productDAO.updateProductStock(item.getProductId(), item.getQuantity());
            }
            
            return true;
        } catch (SQLException e) {
            System.err.println("Create order error: " + e.getMessage());
            return false;
        }
    }
    
    // Get orders by user
    public List<Order> getOrdersByUser(int userId) {
        List<Order> orders = new ArrayList<>();
        String sql = "SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC";
        try (ResultSet rs = DatabaseConnection.executeQuery(sql, userId)) {
            while (rs.next()) {
                Order order = extractOrder(rs);
                order.setItems(getOrderItems(order.getId()));
                orders.add(order);
            }
        } catch (SQLException e) {
            System.err.println("Get user orders error: " + e.getMessage());
        }
        return orders;
    }
    
    // Get all orders (admin)
    public List<Order> getAllOrders() {
        List<Order> orders = new ArrayList<>();
        String sql = "SELECT * FROM orders ORDER BY created_at DESC";
        try (ResultSet rs = DatabaseConnection.executeQuery(sql)) {
            while (rs.next()) {
                Order order = extractOrder(rs);
                User user = userDAO.getUserById(order.getUserId());
                order.setUser(user);
                order.setItems(getOrderItems(order.getId()));
                orders.add(order);
            }
        } catch (SQLException e) {
            System.err.println("Get all orders error: " + e.getMessage());
        }
        return orders;
    }
    
    // Get order by ID
    public Order getOrderById(int orderId) {
        String sql = "SELECT * FROM orders WHERE id = ?";
        try (ResultSet rs = DatabaseConnection.executeQuery(sql, orderId)) {
            if (rs.next()) {
                Order order = extractOrder(rs);
                order.setUser(userDAO.getUserById(order.getUserId()));
                order.setItems(getOrderItems(order.getId()));
                return order;
            }
        } catch (SQLException e) {
            System.err.println("Get order error: " + e.getMessage());
        }
        return null;
    }
    
    // Update order status
    public boolean updateOrderStatus(int orderId, String status) {
        String sql = "UPDATE orders SET order_status = ? WHERE id = ?";
        try {
            int result = DatabaseConnection.executeUpdate(sql, status, orderId);
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Update order status error: " + e.getMessage());
            return false;
        }
    }
    
    // Update payment status
    public boolean updatePaymentStatus(int orderId, String paymentStatus) {
        String sql = "UPDATE orders SET payment_status = ? WHERE id = ?";
        try {
            int result = DatabaseConnection.executeUpdate(sql, paymentStatus, orderId);
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Update payment status error: " + e.getMessage());
            return false;
        }
    }
    
    // Get order items
    public List<OrderItem> getOrderItems(int orderId) {
        List<OrderItem> items = new ArrayList<>();
        String sql = "SELECT * FROM order_items WHERE order_id = ?";
        try (ResultSet rs = DatabaseConnection.executeQuery(sql, orderId)) {
            while (rs.next()) {
                OrderItem item = new OrderItem();
                item.setId(rs.getInt("id"));
                item.setOrderId(rs.getInt("order_id"));
                item.setProductId(rs.getInt("product_id"));
                item.setProductName(rs.getString("product_name"));
                item.setQuantity(rs.getInt("quantity"));
                item.setPrice(rs.getDouble("price"));
                item.setTotal(rs.getDouble("total"));
                items.add(item);
            }
        } catch (SQLException e) {
            System.err.println("Get order items error: " + e.getMessage());
        }
        return items;
    }
    
    // Get order count
    public int getOrderCount() {
        String sql = "SELECT COUNT(*) as count FROM orders";
        try (ResultSet rs = DatabaseConnection.executeQuery(sql)) {
            if (rs.next()) {
                return rs.getInt("count");
            }
        } catch (SQLException e) {
            System.err.println("Order count error: " + e.getMessage());
        }
        return 0;
    }
    
    // Get total revenue
    public double getTotalRevenue() {
        String sql = "SELECT SUM(final_amount) as total FROM orders WHERE order_status != 'cancelled'";
        try (ResultSet rs = DatabaseConnection.executeQuery(sql)) {
            if (rs.next()) {
                return rs.getDouble("total");
            }
        } catch (SQLException e) {
            System.err.println("Revenue error: " + e.getMessage());
        }
        return 0;
    }
    
    private Order extractOrder(ResultSet rs) throws SQLException {
        Order order = new Order();
        order.setId(rs.getInt("id"));
        order.setOrderNumber(rs.getString("order_number"));
        order.setUserId(rs.getInt("user_id"));
        order.setTotalAmount(rs.getDouble("total_amount"));
        order.setDiscount(rs.getDouble("discount"));
        order.setFinalAmount(rs.getDouble("final_amount"));
        order.setShippingAddress(rs.getString("shipping_address"));
        order.setCity(rs.getString("city"));
        order.setState(rs.getString("state"));
        order.setPincode(rs.getString("pincode"));
        order.setPaymentMethod(rs.getString("payment_method"));
        order.setPaymentStatus(rs.getString("payment_status"));
        order.setOrderStatus(rs.getString("order_status"));
        order.setTrackingNumber(rs.getString("tracking_number"));
        order.setNotes(rs.getString("notes"));
        order.setCreatedAt(rs.getTimestamp("created_at"));
        return order;
    }
}