package com.shopping.dao;

import com.shopping.model.Product;
import com.shopping.db.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {
    public List<Product> getAllProducts() {
        List<Product> products = new ArrayList<>();
        String sql = "SELECT * FROM product WHERE active = 'Yes' ORDER BY id DESC";
        
        try (ResultSet rs = DatabaseConnection.executeQuery(sql)) {
            while (rs.next()) {
                Product product = new Product();
                product.setId(rs.getInt("id"));
                product.setName(rs.getString("name"));
                product.setCategory(rs.getString("category")); // Use category string directly
                product.setPrice(rs.getInt("price"));
                product.setStatus(rs.getString("active"));
                product.setStock(rs.getInt("stock")); // Only if you added stock column
                products.add(product);
            }
        } catch (SQLException e) {
            System.err.println("Get products error: " + e.getMessage());
        }
        return products;
    }
    
    // Get product by ID
    public Product getProductById(int productId) {
        String sql = "SELECT * FROM product WHERE id = ?";
        
        try (ResultSet rs = DatabaseConnection.executeQuery(sql, productId)) {
            if (rs.next()) {
                Product product = new Product();
                product.setId(rs.getInt("id"));
                product.setName(rs.getString("name"));
                product.setCategory(rs.getString("category"));
                product.setPrice(rs.getInt("price"));
                product.setStatus(rs.getString("active"));
                product.setStock(rs.getInt("stock"));
                return product;
            }
        } catch (SQLException e) {
            System.err.println("Get product error: " + e.getMessage());
        }
        return null;
    }
    
    // Add product
    public boolean addProduct(Product product) {
        String sql = "INSERT INTO product (name, category, price, stock, active) VALUES (?, ?, ?, ?, ?)";
        
        try {
            int result = DatabaseConnection.executeInsert(sql,
                product.getName(),
                product.getCategory(),
                product.getPrice(),
                product.getStock(),
                product.getStatus()
            );
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Add product error: " + e.getMessage());
            return false;
        }
    }
    
    // Update product
    public boolean updateProduct(Product product) {
        String sql = "UPDATE product SET name = ?, category = ?, price = ?, stock = ?, active = ? WHERE id = ?";
        
        try {
            int result = DatabaseConnection.executeUpdate(sql,
                product.getName(),
                product.getCategory(),
                product.getPrice(),
                product.getStock(),
                product.getStatus(),
                product.getId()
            );
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Update product error: " + e.getMessage());
            return false;
        }
    }
    
    // Delete product
    public boolean deleteProduct(int productId) {
        String sql = "DELETE FROM product WHERE id = ?";
        
        try {
            int result = DatabaseConnection.executeUpdate(sql, productId);
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Delete product error: " + e.getMessage());
            return false;
        }
    }
    
    // ============ STOCK MANAGEMENT METHODS ============
    
    // Update product stock (decrease)
    public boolean updateProductStock(int productId, int quantity) {
        String sql = "UPDATE product SET stock = stock - ? WHERE id = ? AND stock >= ?";
        try {
            int result = DatabaseConnection.executeUpdate(sql, quantity, productId, quantity);
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Update stock error: " + e.getMessage());
            return false;
        }
    }
    
    // Check stock availability
    public boolean checkStock(int productId, int quantity) {
        String sql = "SELECT stock FROM product WHERE id = ?";
        try (ResultSet rs = DatabaseConnection.executeQuery(sql, productId)) {
            if (rs.next()) {
                int stock = rs.getInt("stock");
                return stock >= quantity;
            }
        } catch (SQLException e) {
            System.err.println("Check stock error: " + e.getMessage());
        }
        return false;
    }
    
    // Restore product stock (increase)
    public boolean restoreProductStock(int productId, int quantity) {
        String sql = "UPDATE product SET stock = stock + ? WHERE id = ?";
        try {
            int result = DatabaseConnection.executeUpdate(sql, quantity, productId);
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Restore stock error: " + e.getMessage());
            return false;
        }
    }
    
    // Get current stock
    public int getCurrentStock(int productId) {
        String sql = "SELECT stock FROM product WHERE id = ?";
        try (ResultSet rs = DatabaseConnection.executeQuery(sql, productId)) {
            if (rs.next()) {
                return rs.getInt("stock");
            }
        } catch (SQLException e) {
            System.err.println("Get stock error: " + e.getMessage());
        }
        return 0;
    }
}