package com.shopping.dao;

import com.shopping.model.User;
import com.shopping.db.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {
    
    // Register new user
    public boolean register(User user) {
        String sql = "INSERT INTO users (full_name, email, password, mobile, role) VALUES (?, ?, ?, ?, ?)";
        try {
            int result = DatabaseConnection.executeInsert(sql, 
                user.getFullName(), 
                user.getEmail(), 
                user.getPassword(),
                user.getMobile(),
                user.getRole()
            );
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Registration error: " + e.getMessage());
            return false;
        }
    }
    
    // Login user
    public User login(String email, String password) {
        String sql = "SELECT * FROM users WHERE email = ? AND password = ?";
        try (ResultSet rs = DatabaseConnection.executeQuery(sql, email, password)) {
            if (rs.next()) {
                User user = new User();
                user.setId(rs.getInt("id"));
                user.setFullName(rs.getString("full_name"));
                user.setEmail(rs.getString("email"));
                user.setPassword(rs.getString("password"));
                user.setMobile(rs.getString("mobile"));
                user.setAddress(rs.getString("address"));
                user.setCity(rs.getString("city"));
                user.setState(rs.getString("state"));
                user.setPincode(rs.getString("pincode"));
                user.setRole(rs.getString("role"));
                user.setCreatedAt(rs.getTimestamp("created_at"));
                return user;
            }
        } catch (SQLException e) {
            System.err.println("Login error: " + e.getMessage());
        }
        return null;
    }
    
    // Get user by ID
    public User getUserById(int userId) {
        String sql = "SELECT * FROM users WHERE id = ?";
        try (ResultSet rs = DatabaseConnection.executeQuery(sql, userId)) {
            if (rs.next()) {
                User user = new User();
                user.setId(rs.getInt("id"));
                user.setFullName(rs.getString("full_name"));
                user.setEmail(rs.getString("email"));
                user.setMobile(rs.getString("mobile"));
                user.setAddress(rs.getString("address"));
                user.setCity(rs.getString("city"));
                user.setState(rs.getString("state"));
                user.setPincode(rs.getString("pincode"));
                user.setRole(rs.getString("role"));
                return user;
            }
        } catch (SQLException e) {
            System.err.println("Get user error: " + e.getMessage());
        }
        return null;
    }
    
    // Update user profile
    public boolean updateProfile(User user) {
        String sql = "UPDATE users SET full_name = ?, mobile = ?, address = ?, city = ?, state = ?, pincode = ? WHERE id = ?";
        try {
            int result = DatabaseConnection.executeUpdate(sql,
                user.getFullName(),
                user.getMobile(),
                user.getAddress(),
                user.getCity(),
                user.getState(),
                user.getPincode(),
                user.getId()
            );
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Update profile error: " + e.getMessage());
            return false;
        }
    }
    
    // Change password
    public boolean changePassword(int userId, String newPassword) {
        String sql = "UPDATE users SET password = ? WHERE id = ?";
        try {
            int result = DatabaseConnection.executeUpdate(sql, newPassword, userId);
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Change password error: " + e.getMessage());
            return false;
        }
    }
    
    // Get all users (for admin)
    public List<User> getAllUsers() {
        List<User> users = new ArrayList<>();
        String sql = "SELECT * FROM users WHERE role = 'user' ORDER BY created_at DESC";
        try (ResultSet rs = DatabaseConnection.executeQuery(sql)) {
            while (rs.next()) {
                User user = new User();
                user.setId(rs.getInt("id"));
                user.setFullName(rs.getString("full_name"));
                user.setEmail(rs.getString("email"));
                user.setMobile(rs.getString("mobile"));
                user.setRole(rs.getString("role"));
                user.setCreatedAt(rs.getTimestamp("created_at"));
                users.add(user);
            }
        } catch (SQLException e) {
            System.err.println("Get users error: " + e.getMessage());
        }
        return users;
    }
    
    // Get user count
    public int getUserCount() {
        String sql = "SELECT COUNT(*) as count FROM users WHERE role = 'user'";
        try (ResultSet rs = DatabaseConnection.executeQuery(sql)) {
            if (rs.next()) {
                return rs.getInt("count");
            }
        } catch (SQLException e) {
            System.err.println("User count error: " + e.getMessage());
        }
        return 0;
    }
}