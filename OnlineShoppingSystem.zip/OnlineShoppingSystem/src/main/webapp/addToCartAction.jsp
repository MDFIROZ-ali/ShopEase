<%@ page import="com.shopping.db.DatabaseConnection"%>
<%@ page import="java.sql.*"%>

<%
Integer userId = (Integer) session.getAttribute("userId");
String productId = request.getParameter("id");

if(userId == null) {
    response.sendRedirect("login.jsp");
    return;
}

if(productId == null || productId.isEmpty()) {
    response.sendRedirect("user/products.jsp");
    return;
}

try {
    Connection con = DatabaseConnection.getConnection();
    
    // Check if product already in cart
    PreparedStatement check = con.prepareStatement("SELECT * FROM cart WHERE user_id = ? AND product_id = ?");
    check.setInt(1, userId);
    check.setInt(2, Integer.parseInt(productId));
    ResultSet rs = check.executeQuery();
    
    if(rs.next()) {
        // Update quantity
        int newQty = rs.getInt("quantity") + 1;
        PreparedStatement update = con.prepareStatement("UPDATE cart SET quantity = ? WHERE user_id = ? AND product_id = ?");
        update.setInt(1, newQty);
        update.setInt(2, userId);
        update.setInt(3, Integer.parseInt(productId));
        update.executeUpdate();
    } else {
        // Add new item
        PreparedStatement insert = con.prepareStatement("INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, 1)");
        insert.setInt(1, userId);
        insert.setInt(2, Integer.parseInt(productId));
        insert.executeUpdate();
    }
    
    response.sendRedirect("user/cart.jsp");
    con.close();
} catch(Exception e) {
    System.out.println("Cart Error: " + e.getMessage());
    response.sendRedirect("user/products.jsp");
}
%>