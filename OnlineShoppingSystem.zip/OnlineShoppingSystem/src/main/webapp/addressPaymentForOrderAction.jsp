<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.shopping.db.DatabaseConnection"%>
<%@ page import="java.sql.*"%>
<%@ page import="java.time.LocalDateTime"%>
<%@ page import="java.time.format.DateTimeFormatter"%>

<%
Integer userId = (Integer) session.getAttribute("userId");

if(userId == null) {
    response.sendRedirect("login.jsp");
    return;
}

String address = request.getParameter("address");
String city = request.getParameter("city");
String state = request.getParameter("state");
String country = request.getParameter("country");
String mobileNumber = request.getParameter("mobileNumber");
String paymentMethod = request.getParameter("paymentMethod");

try {
    Connection con = DatabaseConnection.getConnection();
    
    // 1. Update user's address
    PreparedStatement updateUser = con.prepareStatement("UPDATE users SET address=?, city=?, state=?, mobileNumber=? WHERE id=?");
    updateUser.setString(1, address);
    updateUser.setString(2, city);
    updateUser.setString(3, state);
    updateUser.setString(4, mobileNumber);
    updateUser.setInt(5, userId);
    updateUser.executeUpdate();
    
    // 2. Get current timestamp
    String now = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    
    // 3. Simple update - remove status filter
    PreparedStatement updateCart = con.prepareStatement(
        "UPDATE cart SET address=?, city=?, state=?, paymentMethod=?, orderDate=?, status='pending' WHERE user_id=?"
    );
    updateCart.setString(1, address);
    updateCart.setString(2, city);
    updateCart.setString(3, state);
    updateCart.setString(4, paymentMethod);
    updateCart.setString(5, now);
    updateCart.setInt(6, userId);
    
    int rowsUpdated = updateCart.executeUpdate();
    System.out.println("Orders placed: " + rowsUpdated);
    
    if(rowsUpdated > 0) {
        response.sendRedirect("user/orders.jsp?msg=success");
    } else {
        response.sendRedirect("user/cart.jsp?msg=empty");
    }
    con.close();
    
} catch(Exception e) {
    System.out.println("Checkout error: " + e.getMessage());
    response.sendRedirect("user/checkout.jsp?msg=error");
}
%>