<%@ page import="com.shopping.db.DatabaseConnection"%>
<%@ page import="java.sql.*"%>

<%
String name = request.getParameter("name");
String category = request.getParameter("category");
String price = request.getParameter("price");
String stock = request.getParameter("stock");
String image_url = request.getParameter("image_url");
String active = request.getParameter("active");

if(image_url == null || image_url.trim().isEmpty()) {
    if(category.equals("Electronics")) image_url = "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=300&h=200&fit=crop";
    else if(category.equals("Clothing")) image_url = "https://images.unsplash.com/photo-1523381210434-271e8be1f52b?w=300&h=200&fit=crop";
    else image_url = "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=300&h=200&fit=crop";
}

try {
    Connection con = DatabaseConnection.getConnection();
    PreparedStatement ps = con.prepareStatement("INSERT INTO product (name, category, price, stock, image_url, active) VALUES (?, ?, ?, ?, ?, ?)");
    ps.setString(1, name); ps.setString(2, category); ps.setInt(3, Integer.parseInt(price));
    ps.setInt(4, Integer.parseInt(stock)); ps.setString(5, image_url); ps.setString(6, active);
    ps.executeUpdate();
    response.sendRedirect("products.jsp?msg=added");
    con.close();
} catch(Exception e) { response.sendRedirect("add-product.jsp?error=exception"); }
%>