<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>

<%
String email = (String) session.getAttribute("email");
if(email == null || !"admin@gmail.com".equals(email)) {
    response.sendRedirect("../login.jsp");
    return;
}
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product - ShopEase Luxury Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Space Grotesk', sans-serif;
            background: #0a0a0a;
            color: #ffffff;
        }
        
        /* Sidebar */
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            height: 100%;
            width: 280px;
            background: linear-gradient(180deg, #0f0f0f 0%, #0a0a0a 100%);
            border-right: 1px solid rgba(212, 175, 55, 0.15);
            padding: 25px 0;
            z-index: 100;
        }
        
        .sidebar-header {
            text-align: center;
            padding: 0 20px 25px;
            border-bottom: 1px solid rgba(212, 175, 55, 0.15);
            margin-bottom: 20px;
        }
        
        .sidebar-header h3 {
            font-size: 24px;
            font-weight: 700;
            background: linear-gradient(135deg, #d4af37, #fff);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
        
        .sidebar-header p {
            font-size: 12px;
            color: rgba(255,255,255,0.5);
            margin-top: 5px;
        }
        
        .sidebar-menu {
            padding: 0 15px;
        }
        
        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 12px 18px;
            margin: 5px 0;
            color: rgba(255,255,255,0.7);
            text-decoration: none;
            border-radius: 12px;
            transition: 0.3s;
            font-weight: 500;
        }
        
        .sidebar-menu a i {
            width: 25px;
            margin-right: 12px;
            font-size: 18px;
        }
        
        .sidebar-menu a:hover {
            background: rgba(212, 175, 55, 0.1);
            color: #d4af37;
        }
        
        .sidebar-menu a.active {
            background: linear-gradient(135deg, #d4af37, #b8960c);
            color: #0a0a0a;
        }
        
        /* Main Content */
        .main-content {
            margin-left: 280px;
            padding: 25px;
            min-height: 100vh;
        }
        
        /* Top Bar */
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid rgba(212, 175, 55, 0.15);
        }
        
        .page-title h2 {
            font-size: 28px;
            font-weight: 700;
            background: linear-gradient(135deg, #fff, #d4af37);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
        
        .page-title p {
            color: rgba(255,255,255,0.5);
            font-size: 14px;
        }
        
        /* Form Container */
        .form-container {
            background: rgba(20, 20, 30, 0.6);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(212, 175, 55, 0.15);
            border-radius: 20px;
            padding: 35px;
            max-width: 700px;
            margin: 0 auto;
        }
        
        .form-group {
            margin-bottom: 22px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: rgba(255,255,255,0.8);
        }
        
        .form-group label i {
            color: #d4af37;
            margin-right: 8px;
        }
        
        .form-control, .form-select {
            width: 100%;
            padding: 14px 18px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(212, 175, 55, 0.2);
            border-radius: 12px;
            color: white;
            font-size: 15px;
            transition: 0.3s;
        }
        
        .form-control:focus, .form-select:focus {
            outline: none;
            border-color: #d4af37;
            box-shadow: 0 0 15px rgba(212, 175, 55, 0.2);
            background: rgba(255, 255, 255, 0.08);
        }
        
        textarea.form-control {
            resize: vertical;
            min-height: 100px;
        }
        
        /* Image Preview */
        .image-preview {
            margin-top: 15px;
            text-align: center;
        }
        
        .image-preview img {
            max-width: 200px;
            max-height: 150px;
            border-radius: 12px;
            border: 1px solid rgba(212, 175, 55, 0.3);
            background: #1a1a2e;
        }
        
        .image-help {
            font-size: 12px;
            color: rgba(255,255,255,0.5);
            margin-top: 8px;
        }
        
        .suggestions {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 10px;
        }
        
        .suggestion-badge {
            background: rgba(212, 175, 55, 0.15);
            border: 1px solid rgba(212, 175, 55, 0.2);
            border-radius: 20px;
            padding: 5px 12px;
            font-size: 11px;
            color: #d4af37;
            cursor: pointer;
            transition: 0.3s;
        }
        
        .suggestion-badge:hover {
            background: rgba(212, 175, 55, 0.3);
        }
        
        /* Buttons */
        .btn-add {
            background: linear-gradient(135deg, #d4af37, #b8960c);
            color: #0a0a0a;
            padding: 14px 30px;
            border: none;
            border-radius: 50px;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            transition: 0.3s;
            width: 100%;
        }
        
        .btn-add:hover {
            transform: scale(1.02);
            box-shadow: 0 0 25px rgba(212, 175, 55, 0.5);
        }
        
        .btn-cancel {
            background: transparent;
            border: 1px solid rgba(212, 175, 55, 0.3);
            color: #d4af37;
            padding: 12px 25px;
            border-radius: 50px;
            text-decoration: none;
            display: inline-block;
            transition: 0.3s;
            text-align: center;
        }
        
        .btn-cancel:hover {
            background: rgba(212, 175, 55, 0.1);
        }
        
        .button-group {
            display: flex;
            gap: 15px;
            margin-top: 25px;
        }
        
        .button-group .btn-add {
            flex: 2;
        }
        
        .button-group .btn-cancel {
            flex: 1;
        }
        
        /* Alert */
        .alert {
            padding: 15px 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            font-size: 14px;
        }
        
        .alert-danger {
            background: rgba(220, 53, 69, 0.2);
            border: 1px solid rgba(220, 53, 69, 0.3);
            color: #ff6b6b;
        }
        
        /* Footer */
        .footer {
            text-align: center;
            padding: 25px 0;
            margin-top: 30px;
            border-top: 1px solid rgba(212, 175, 55, 0.15);
            color: rgba(255,255,255,0.4);
            font-size: 13px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 70px;
            }
            .sidebar-header h3, .sidebar-header p, .sidebar-menu a span {
                display: none;
            }
            .sidebar-menu a {
                justify-content: center;
                padding: 12px;
            }
            .sidebar-menu a i {
                margin-right: 0;
            }
            .main-content {
                margin-left: 70px;
            }
            .form-container {
                padding: 25px;
            }
            .button-group {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <div class="sidebar-header">
        <h3><i class="fas fa-crown"></i> ShopEase</h3>
        <p>Admin Panel v2.0</p>
    </div>
    <div class="sidebar-menu">
        <a href="dashboard.jsp">
            <i class="fas fa-tachometer-alt"></i> <span>Dashboard</span>
        </a>
        <a href="products.jsp" class="active">
            <i class="fas fa-box"></i> <span>Products</span>
        </a>
        <a href="orders.jsp">
            <i class="fas fa-shopping-cart"></i> <span>Orders</span>
        </a>
        <a href="users.jsp">
            <i class="fas fa-users"></i> <span>Users</span>
        </a>
        <a href="../logout.jsp">
            <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
        </a>
    </div>
</div>

<!-- Main Content -->
<div class="main-content">
    <div class="top-bar">
        <div class="page-title">
            <h2><i class="fas fa-plus-circle"></i> Add New Product</h2>
            <p>Add a new luxury product to your inventory</p>
        </div>
    </div>
    
    <div class="form-container">
        <%
        String error = request.getParameter("error");
        if("exception".equals(error)) {
        %>
        <div class="alert alert-danger">
            <i class="fas fa-exclamation-circle"></i> Failed to add product! Please check all fields and try again.
        </div>
        <% } %>
        
        <form action="add-product-action.jsp" method="post">
            <div class="form-group">
                <label><i class="fas fa-tag"></i> Product Name</label>
                <input type="text" name="name" class="form-control" placeholder="Enter product name" required>
            </div>
            
            <div class="form-group">
                <label><i class="fas fa-folder"></i> Category</label>
                <select name="category" class="form-select" required>
                    <option value="Electronics">Electronics</option>
                    <option value="Clothing">Clothing</option>
                    <option value="Home">Home & Living</option>
                    <option value="Books">Books</option>
                    <option value="Sports">Sports</option>
                    <option value="Beauty">Beauty</option>
                </select>
            </div>
            
            <div class="form-group">
                <label><i class="fas fa-rupee-sign"></i> Price (₹)</label>
                <input type="number" name="price" class="form-control" placeholder="Enter price" required>
            </div>
            
            <div class="form-group">
                <label><i class="fas fa-boxes"></i> Stock Quantity</label>
                <input type="number" name="stock" class="form-control" placeholder="Enter stock quantity" value="0" required>
            </div>
            
            <div class="form-group">
                <label><i class="fas fa-image"></i> Image URL</label>
                <input type="text" name="image_url" id="image_url" class="form-control" placeholder="https://example.com/product-image.jpg">
                <div class="image-help">Leave empty to use default image based on category</div>
                <div class="suggestions">
                    <span class="suggestion-badge" onclick="setImage('https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=300&h=200&fit=crop')">📱 Phone</span>
                    <span class="suggestion-badge" onclick="setImage('https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=300&h=200&fit=crop')">⌚ Watch</span>
                    <span class="suggestion-badge" onclick="setImage('https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=300&h=200&fit=crop')">🎧 Headphones</span>
                    <span class="suggestion-badge" onclick="setImage('https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=300&h=200&fit=crop')">👟 Shoes</span>
                    <span class="suggestion-badge" onclick="setImage('https://images.unsplash.com/photo-1523381210434-271e8be1f52b?w=300&h=200&fit=crop')">👕 Clothing</span>
                    <span class="suggestion-badge" onclick="setImage('https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=300&h=200&fit=crop')">👖 Jeans</span>
                </div>
                <div class="image-preview" id="imagePreview"></div>
            </div>
            
            <div class="form-group">
                <label><i class="fas fa-toggle-on"></i> Status</label>
                <select name="active" class="form-select">
                    <option value="Yes">Active</option>
                    <option value="No">Inactive</option>
                </select>
            </div>
            
            <div class="button-group">
                <button type="submit" class="btn-add"><i class="fas fa-save"></i> Add Product</button>
                <a href="products.jsp" class="btn-cancel"><i class="fas fa-times"></i> Cancel</a>
            </div>
        </form>
    </div>
    
    <div class="footer">
        <p>&copy; 2024 ShopEase Luxury Admin Panel. All rights reserved.</p>
    </div>
</div>

<script>
// Image preview
const imageInput = document.getElementById('image_url');
const imagePreview = document.getElementById('imagePreview');

imageInput.addEventListener('input', function() {
    const url = this.value;
    if(url) {
        imagePreview.innerHTML = `<img src="${url}" alt="Preview" onerror="this.src='https://via.placeholder.com/200x150/1a1a2e/d4af37?text=Invalid+URL'">`;
    } else {
        imagePreview.innerHTML = '';
    }
});

function setImage(url) {
    imageInput.value = url;
    imagePreview.innerHTML = `<img src="${url}" alt="Preview" onerror="this.src='https://via.placeholder.com/200x150/1a1a2e/d4af37?text=Invalid+URL'">`;
}
</script>
</body>
</html>