<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.shopping.db.DatabaseConnection"%>
<%@ page import="java.sql.*"%>
<%@ page import="java.text.*"%>

<%
String email = (String) session.getAttribute("email");
if(email == null || !"admin@gmail.com".equals(email)) {
    response.sendRedirect("../login.jsp");
    return;
}
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - ShopEase Luxury</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Space Grotesk', sans-serif;
            background: #0a0a0a;
            color: #ffffff;
        }
        
        /* Sidebar */
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            height: 100%;
            width: 280px;
            background: linear-gradient(180deg, #0f0f0f 0%, #0a0a0a 100%);
            border-right: 1px solid rgba(212, 175, 55, 0.15);
            padding: 25px 0;
            z-index: 100;
        }
        
        .sidebar-header {
            text-align: center;
            padding: 0 20px 25px;
            border-bottom: 1px solid rgba(212, 175, 55, 0.15);
            margin-bottom: 20px;
        }
        
        .sidebar-header h3 {
            font-size: 24px;
            font-weight: 700;
            background: linear-gradient(135deg, #d4af37, #fff);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
        
        .sidebar-header p {
            font-size: 12px;
            color: rgba(255,255,255,0.5);
            margin-top: 5px;
        }
        
        .sidebar-menu {
            padding: 0 15px;
        }
        
        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 12px 18px;
            margin: 5px 0;
            color: rgba(255,255,255,0.7);
            text-decoration: none;
            border-radius: 12px;
            transition: 0.3s;
            font-weight: 500;
        }
        
        .sidebar-menu a i {
            width: 25px;
            margin-right: 12px;
            font-size: 18px;
        }
        
        .sidebar-menu a:hover {
            background: rgba(212, 175, 55, 0.1);
            color: #d4af37;
        }
        
        .sidebar-menu a.active {
            background: linear-gradient(135deg, #d4af37, #b8960c);
            color: #0a0a0a;
        }
        
        /* Main Content */
        .main-content {
            margin-left: 280px;
            padding: 25px;
            min-height: 100vh;
        }
        
        /* Top Bar */
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid rgba(212, 175, 55, 0.15);
        }
        
        .page-title h2 {
            font-size: 28px;
            font-weight: 700;
            background: linear-gradient(135deg, #fff, #d4af37);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
        
        .page-title p {
            color: rgba(255,255,255,0.5);
            font-size: 14px;
        }
        
        .admin-info {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .admin-info span {
            color: #d4af37;
        }
        
        .logout-btn {
            background: rgba(220, 53, 69, 0.2);
            border: 1px solid rgba(220, 53, 69, 0.3);
            color: #ff6b6b;
            padding: 8px 20px;
            border-radius: 50px;
            text-decoration: none;
            font-size: 14px;
            transition: 0.3s;
        }
        
        .logout-btn:hover {
            background: #dc3545;
            color: white;
        }
        
        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 25px;
            margin-bottom: 35px;
        }
        
        .stat-card {
            background: rgba(20, 20, 30, 0.6);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(212, 175, 55, 0.15);
            border-radius: 20px;
            padding: 22px;
            transition: 0.3s;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            border-color: rgba(212, 175, 55, 0.4);
            box-shadow: 0 15px 35px rgba(212,175,55,0.1);
        }
        
        .stat-icon {
            width: 55px;
            height: 55px;
            background: rgba(212, 175, 55, 0.15);
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 15px;
        }
        
        .stat-icon i {
            font-size: 28px;
            color: #d4af37;
        }
        
        .stat-number {
            font-size: 32px;
            font-weight: 800;
            color: #d4af37;
            margin-bottom: 5px;
        }
        
        .stat-label {
            color: rgba(255,255,255,0.7);
            font-size: 14px;
        }
        
        .stat-trend {
            font-size: 12px;
            margin-top: 10px;
            color: #28a745;
        }
        
        /* Charts Row */
        .charts-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 25px;
            margin-bottom: 35px;
        }
        
        .chart-card {
            background: rgba(20, 20, 30, 0.6);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(212, 175, 55, 0.15);
            border-radius: 20px;
            padding: 22px;
        }
        
        .chart-card h5 {
            margin-bottom: 20px;
            color: #d4af37;
            font-weight: 600;
        }
        
        canvas {
            max-height: 250px;
        }
        
        /* Recent Orders Table */
        .recent-orders {
            background: rgba(20, 20, 30, 0.6);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(212, 175, 55, 0.15);
            border-radius: 20px;
            padding: 22px;
        }
        
        .recent-orders h5 {
            margin-bottom: 20px;
            color: #d4af37;
            font-weight: 600;
        }
        
        .table-custom {
            width: 100%;
            border-collapse: collapse;
        }
        
        .table-custom th {
            text-align: left;
            padding: 12px 10px;
            color: rgba(255,255,255,0.7);
            font-weight: 500;
            border-bottom: 1px solid rgba(212, 175, 55, 0.15);
        }
        
        .table-custom td {
            padding: 12px 10px;
            border-bottom: 1px solid rgba(255,255,255,0.05);
        }
        
        .status-badge {
            padding: 4px 12px;
            border-radius: 50px;
            font-size: 11px;
            font-weight: 600;
        }
        
        .status-pending {
            background: rgba(255, 193, 7, 0.2);
            color: #ffc107;
            border: 1px solid rgba(255, 193, 7, 0.3);
        }
        
        .status-processing {
            background: rgba(23, 162, 184, 0.2);
            color: #17a2b8;
            border: 1px solid rgba(23, 162, 184, 0.3);
        }
        
        .status-delivered {
            background: rgba(40, 167, 69, 0.2);
            color: #28a745;
            border: 1px solid rgba(40, 167, 69, 0.3);
        }
        
        .view-btn {
            background: rgba(212, 175, 55, 0.2);
            border: 1px solid rgba(212, 175, 55, 0.3);
            color: #d4af37;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 11px;
            text-decoration: none;
        }
        
        .view-btn:hover {
            background: #d4af37;
            color: #0a0a0a;
        }
        
        /* Quick Actions */
        .quick-actions {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            margin-top: 20px;
        }
        
        .action-btn {
            background: rgba(212, 175, 55, 0.1);
            border: 1px solid rgba(212, 175, 55, 0.2);
            color: #d4af37;
            padding: 10px 20px;
            border-radius: 50px;
            text-decoration: none;
            font-size: 14px;
            transition: 0.3s;
        }
        
        .action-btn:hover {
            background: #d4af37;
            color: #0a0a0a;
        }
        
        /* Footer */
        .footer {
            text-align: center;
            padding: 25px 0;
            margin-top: 30px;
            border-top: 1px solid rgba(212, 175, 55, 0.15);
            color: rgba(255,255,255,0.4);
            font-size: 13px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 70px;
            }
            .sidebar-header h3, .sidebar-header p, .sidebar-menu a span {
                display: none;
            }
            .sidebar-menu a {
                justify-content: center;
                padding: 12px;
            }
            .sidebar-menu a i {
                margin-right: 0;
            }
            .main-content {
                margin-left: 70px;
            }
            .charts-row {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <div class="sidebar-header">
        <h3><i class="fas fa-crown"></i> ShopEase</h3>
        <p>Admin Panel v2.0</p>
    </div>
    <div class="sidebar-menu">
        <a href="dashboard.jsp" class="active">
            <i class="fas fa-tachometer-alt"></i> <span>Dashboard</span>
        </a>
        <a href="products.jsp">
            <i class="fas fa-box"></i> <span>Products</span>
        </a>
        <a href="orders.jsp">
            <i class="fas fa-shopping-cart"></i> <span>Orders</span>
        </a>
        <a href="users.jsp">
            <i class="fas fa-users"></i> <span>Users</span>
        </a>
        <a href="../logout.jsp">
            <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
        </a>
    </div>
</div>

<!-- Main Content -->
<div class="main-content">
    <div class="top-bar">
        <div class="page-title">
            <h2><i class="fas fa-chart-line"></i> Dashboard</h2>
            <p>Welcome back, Admin</p>
        </div>
        <div class="admin-info">
            <span><i class="fas fa-user-circle"></i> <%=email%></span>
            <a href="../logout.jsp" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </div>
    
    <%
    int totalProducts = 0;
    int totalOrders = 0;
    int totalUsers = 0;
    int totalRevenue = 0;
    int pendingOrders = 0;
    int completedOrders = 0;
    DecimalFormat df = new DecimalFormat("#,###");
    
    try {
        Connection con = DatabaseConnection.getConnection();
        Statement st = con.createStatement();
        
        ResultSet rs1 = st.executeQuery("SELECT COUNT(*) as count FROM product WHERE active='Yes'");
        if(rs1.next()) totalProducts = rs1.getInt("count");
        
        ResultSet rs2 = st.executeQuery("SELECT COUNT(*) as count FROM cart WHERE address IS NOT NULL");
        if(rs2.next()) totalOrders = rs2.getInt("count");
        
        ResultSet rs3 = st.executeQuery("SELECT COUNT(*) as count FROM users WHERE role='user' OR role IS NULL");
        if(rs3.next()) totalUsers = rs3.getInt("count");
        
        ResultSet rs4 = st.executeQuery("SELECT SUM(total) as revenue FROM cart WHERE address IS NOT NULL");
        if(rs4.next()) totalRevenue = rs4.getInt("revenue");
        
        ResultSet rs5 = st.executeQuery("SELECT COUNT(*) as count FROM cart WHERE address IS NOT NULL AND (status='pending' OR status IS NULL)");
        if(rs5.next()) pendingOrders = rs5.getInt("count");
        
        ResultSet rs6 = st.executeQuery("SELECT COUNT(*) as count FROM cart WHERE address IS NOT NULL AND status='delivered'");
        if(rs6.next()) completedOrders = rs6.getInt("count");
        
        con.close();
    } catch(Exception e) {
        System.out.println("Dashboard error: " + e);
    }
    %>
    
    <!-- Stats Cards -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon"><i class="fas fa-box"></i></div>
            <div class="stat-number"><%=totalProducts%></div>
            <div class="stat-label">Total Products</div>
            <div class="stat-trend"><i class="fas fa-arrow-up"></i> Active products</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon"><i class="fas fa-shopping-cart"></i></div>
            <div class="stat-number"><%=totalOrders%></div>
            <div class="stat-label">Total Orders</div>
            <div class="stat-trend"><i class="fas fa-clock"></i> <%=pendingOrders%> pending</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon"><i class="fas fa-users"></i></div>
            <div class="stat-number"><%=totalUsers%></div>
            <div class="stat-label">Total Users</div>
            <div class="stat-trend"><i class="fas fa-user-plus"></i> Registered customers</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon"><i class="fas fa-rupee-sign"></i></div>
            <div class="stat-number">₹ <%=df.format(totalRevenue)%></div>
            <div class="stat-label">Total Revenue</div>
            <div class="stat-trend"><i class="fas fa-chart-line"></i> Lifetime sales</div>
        </div>
    </div>
    
    <!-- Charts Row -->
    <div class="charts-row">
        <div class="chart-card">
            <h5><i class="fas fa-chart-pie"></i> Order Status Distribution</h5>
            <canvas id="orderChart"></canvas>
            <div class="mt-3 text-center">
                <small>Pending: <%=pendingOrders%> | Completed: <%=completedOrders%> | Total: <%=totalOrders%></small>
            </div>
        </div>
        <div class="chart-card">
            <h5><i class="fas fa-bolt"></i> Quick Actions</h5>
            <div class="quick-actions">
                <a href="add-product.jsp" class="action-btn"><i class="fas fa-plus"></i> Add Product</a>
                <a href="products.jsp" class="action-btn"><i class="fas fa-edit"></i> Manage Products</a>
                <a href="orders.jsp" class="action-btn"><i class="fas fa-truck"></i> View Orders</a>
                <a href="users.jsp" class="action-btn"><i class="fas fa-users"></i> Manage Users</a>
            </div>
        </div>
    </div>
    
    <!-- Recent Orders -->
    <div class="recent-orders">
        <h5><i class="fas fa-clock"></i> Recent Orders</h5>
        <div class="table-responsive">
            <table class="table-custom">
                <thead>
                    <tr><th>Order ID</th><th>Customer</th><th>Amount</th><th>Date</th><th>Status</th><th>Action</th></tr>
                </thead>
                <tbody>
                    <%
                    try {
                        Connection con = DatabaseConnection.getConnection();
                        Statement st = con.createStatement();
                        ResultSet rs = st.executeQuery(
                            "SELECT c.*, u.email as customer_email FROM cart c " +
                            "JOIN users u ON c.user_id = u.id " +
                            "WHERE c.address IS NOT NULL ORDER BY c.id DESC LIMIT 5"
                        );
                        while(rs.next()) {
                            String status = rs.getString("status");
                            if(status == null) status = "pending";
                            String statusClass = "status-pending";
                            if("processing".equals(status)) statusClass = "status-processing";
                            else if("delivered".equals(status)) statusClass = "status-delivered";
                    %>
                    <tr>
                        <td>#<%=rs.getInt("id")%></td>
                        <td><%=rs.getString("customer_email")%></td>
                        <td>₹ <%=df.format(rs.getInt("total"))%></td>
                        <td><%=rs.getString("orderDate") != null ? rs.getString("orderDate") : "-"%></td>
                        <td><span class="status-badge <%=statusClass%>"><%=status.toUpperCase()%></span></td>
                        <td><a href="orders.jsp" class="view-btn">View</a></td>
                    </tr>
                    <%
                        }
                        con.close();
                    } catch(Exception e) {
                        System.out.println(e);
                    }
                    %>
                </tbody>
            </table>
        </div>
    </div>
    
    <div class="footer">
        <p>&copy; 2024 ShopEase Luxury Admin Panel. All rights reserved.</p>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Order Status Chart
const ctx = document.getElementById('orderChart').getContext('2d');
new Chart(ctx, {
    type: 'doughnut',
    data: {
        labels: ['Pending', 'Completed'],
        datasets: [{
            data: [<%=pendingOrders%>, <%=completedOrders%>],
            backgroundColor: ['#ffc107', '#28a745'],
            borderWidth: 0,
            hoverOffset: 10
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: {
                position: 'bottom',
                labels: { color: '#fff' }
            }
        }
    }
});
</script>
</body>
</html>