<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.shopping.db.DatabaseConnection"%>
<%@ page import="java.sql.*"%>

<%
String id = request.getParameter("id");

try {
    Connection con = DatabaseConnection.getConnection();
    
    // First delete from cart where product exists
    PreparedStatement cartPs = con.prepareStatement("DELETE FROM cart WHERE product_id=?");
    cartPs.setString(1, id);
    cartPs.executeUpdate();
    
    // Then delete product
    PreparedStatement ps = con.prepareStatement("DELETE FROM product WHERE id=?");
    ps.setString(1, id);
    ps.executeUpdate();
    
    response.sendRedirect("products.jsp?msg=deleted");
    con.close();
} catch(Exception e) {
    System.out.println(e);
    response.sendRedirect("products.jsp?msg=error");
}
%>