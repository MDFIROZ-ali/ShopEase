<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.shopping.db.DatabaseConnection"%>
<%@ page import="java.sql.*"%>

<%
String id = request.getParameter("id");
String name = request.getParameter("name");
String category = request.getParameter("category");
String price = request.getParameter("price");
String stock = request.getParameter("stock");
String active = request.getParameter("active");

try {
    Connection con = DatabaseConnection.getConnection();
    PreparedStatement ps = con.prepareStatement("UPDATE product SET name=?, category=?, price=?, stock=?, active=? WHERE id=?");
    ps.setString(1, name);
    ps.setString(2, category);
    ps.setInt(3, Integer.parseInt(price));
    ps.setInt(4, Integer.parseInt(stock));
    ps.setString(5, active);
    ps.setString(6, id);
    
    ps.executeUpdate();
    response.sendRedirect("products.jsp?msg=updated");
    con.close();
} catch(Exception e) {
    System.out.println("Error: " + e);
    response.sendRedirect("edit-product.jsp?id=" + id + "&error=exception");
}
%>