<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.shopping.db.DatabaseConnection"%>
<%@ page import="java.sql.*"%>

<%
String email = (String) session.getAttribute("email");
if(email == null || !"admin@gmail.com".equals(email)) {
    response.sendRedirect("../login.jsp");
    return;
}

String productId = request.getParameter("id");
if(productId == null) {
    response.sendRedirect("products.jsp");
    return;
}
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product - ShopEase Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: #0a0a0a;
            font-family: 'Segoe UI', sans-serif;
        }
        
        /* Sidebar */
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            height: 100%;
            width: 260px;
            background: #1a1a2e;
            padding: 20px 0;
            z-index: 100;
        }
        
        .sidebar h3 {
            color: #d4af37;
            text-align: center;
            margin-bottom: 30px;
        }
        
        .sidebar a {
            display: block;
            color: white;
            padding: 12px 25px;
            text-decoration: none;
            transition: 0.3s;
        }
        
        .sidebar a:hover {
            background: #d4af37;
            color: #0a0a0a;
        }
        
        .sidebar a.active {
            background: #d4af37;
            color: #0a0a0a;
        }
        
        /* Main Content */
        .main-content {
            margin-left: 260px;
            padding: 25px;
            min-height: 100vh;
        }
        
        /* Header */
        .header {
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid #333;
        }
        
        .header h2 {
            color: #d4af37;
            font-size: 28px;
        }
        
        .header p {
            color: #888;
        }
        
        /* Form Container */
        .form-container {
            background: #1a1a2e;
            border-radius: 15px;
            padding: 30px;
            max-width: 650px;
            margin: 0 auto;
            border: 1px solid #333;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #d4af37;
        }
        
        .form-group label i {
            margin-right: 8px;
        }
        
        .form-control, .form-select {
            width: 100%;
            padding: 12px 15px;
            background: #0a0a0a;
            border: 1px solid #333;
            border-radius: 8px;
            color: white;
            font-size: 15px;
        }
        
        .form-control:focus, .form-select:focus {
            outline: none;
            border-color: #d4af37;
        }
        
        .image-help {
            font-size: 12px;
            color: #888;
            margin-top: 5px;
        }
        
        .image-preview {
            margin-top: 10px;
            text-align: center;
        }
        
        .image-preview img {
            max-width: 150px;
            border-radius: 8px;
            border: 1px solid #333;
        }
        
        /* Buttons */
        .btn-update {
            background: #d4af37;
            color: #0a0a0a;
            padding: 12px 25px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            width: 100%;
            transition: 0.3s;
        }
        
        .btn-update:hover {
            background: #b8960c;
            transform: scale(1.02);
        }
        
        .btn-cancel {
            background: transparent;
            border: 1px solid #d4af37;
            color: #d4af37;
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            display: inline-block;
            text-align: center;
            transition: 0.3s;
        }
        
        .btn-cancel:hover {
            background: #d4af37;
            color: #0a0a0a;
        }
        
        .button-group {
            display: flex;
            gap: 15px;
            margin-top: 25px;
        }
        
        .button-group .btn-update {
            flex: 2;
        }
        
        .button-group .btn-cancel {
            flex: 1;
            text-align: center;
        }
        
        /* Footer */
        .footer {
            text-align: center;
            padding: 20px;
            margin-top: 30px;
            border-top: 1px solid #333;
            color: #666;
            font-size: 13px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 70px;
            }
            .sidebar span {
                display: none;
            }
            .main-content {
                margin-left: 70px;
            }
            .button-group {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <h3><i class="fas fa-crown"></i> ShopEase</h3>
    <hr style="border-color: #333;">
    <a href="dashboard.jsp"><i class="fas fa-tachometer-alt"></i> <span>Dashboard</span></a>
    <a href="products.jsp" class="active"><i class="fas fa-box"></i> <span>Products</span></a>
    <a href="orders.jsp"><i class="fas fa-shopping-cart"></i> <span>Orders</span></a>
    <a href="users.jsp"><i class="fas fa-users"></i> <span>Users</span></a>
    <a href="../logout.jsp"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a>
</div>

<!-- Main Content -->
<div class="main-content">
    <div class="header">
        <h2><i class="fas fa-edit"></i> Edit Product</h2>
        <p>Update your product details</p>
    </div>
    
    <div class="form-container">
        <%
        try {
            Connection con = DatabaseConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM product WHERE id = ?");
            ps.setString(1, productId);
            ResultSet rs = ps.executeQuery();
            
            if(rs.next()) {
        %>
        <form action="edit-product-action.jsp" method="post">
            <input type="hidden" name="id" value="<%=productId%>">
            
            <div class="form-group">
                <label><i class="fas fa-tag"></i> Product Name</label>
                <input type="text" name="name" class="form-control" value="<%=rs.getString("name")%>" required>
            </div>
            
            <div class="form-group">
                <label><i class="fas fa-folder"></i> Category</label>
                <select name="category" class="form-select" required>
                    <option value="Electronics" <%=rs.getString("category").equals("Electronics") ? "selected" : ""%>>Electronics</option>
                    <option value="Clothing" <%=rs.getString("category").equals("Clothing") ? "selected" : ""%>>Clothing</option>
                    <option value="Home" <%=rs.getString("category").equals("Home") ? "selected" : ""%>>Home & Living</option>
                    <option value="Books" <%=rs.getString("category").equals("Books") ? "selected" : ""%>>Books</option>
                    <option value="Sports" <%=rs.getString("category").equals("Sports") ? "selected" : ""%>>Sports</option>
                    <option value="Beauty" <%=rs.getString("category").equals("Beauty") ? "selected" : ""%>>Beauty</option>
                </select>
            </div>
            
            <div class="form-group">
                <label><i class="fas fa-rupee-sign"></i> Price (₹)</label>
                <input type="number" name="price" class="form-control" value="<%=rs.getInt("price")%>" required>
            </div>
            
            <div class="form-group">
                <label><i class="fas fa-boxes"></i> Stock Quantity</label>
                <input type="number" name="stock" class="form-control" value="<%=rs.getInt("stock")%>" required>
            </div>
            
            <div class="form-group">
                <label><i class="fas fa-image"></i> Image URL</label>
                <input type="text" name="image_url" id="image_url" class="form-control" value="<%=rs.getString("image_url") != null ? rs.getString("image_url") : ""%>" placeholder="https://example.com/image.jpg">
                <div class="image-help">Leave empty to use default image based on category</div>
                <div class="image-preview" id="imagePreview">
                    <% if(rs.getString("image_url") != null && !rs.getString("image_url").isEmpty()) { %>
                        <img src="<%=rs.getString("image_url")%>" alt="Preview" style="max-width: 150px;">
                    <% } %>
                </div>
            </div>
            
            <div class="form-group">
                <label><i class="fas fa-toggle-on"></i> Status</label>
                <select name="active" class="form-select">
                    <option value="Yes" <%=rs.getString("active").equals("Yes") ? "selected" : ""%>>Active</option>
                    <option value="No" <%=rs.getString("active").equals("No") ? "selected" : ""%>>Inactive</option>
                </select>
            </div>
            
            <div class="button-group">
                <button type="submit" class="btn-update"><i class="fas fa-save"></i> Update Product</button>
                <a href="products.jsp" class="btn-cancel"><i class="fas fa-times"></i> Cancel</a>
            </div>
        </form>
        <%
            } else {
                out.println("<div style='color: #ff6b6b; text-align: center; padding: 20px;'>Product not found!</div>");
            }
            con.close();
        } catch(Exception e) {
            out.println("<div style='color: #ff6b6b; text-align: center; padding: 20px;'>Error: " + e.getMessage() + "</div>");
        }
        %>
    </div>
    
    <div class="footer">
        <p>&copy; 2026 ShopEase Admin Panel. All rights reserved.</p>
    </div>
</div>

<script>
// Image preview
const imageInput = document.getElementById('image_url');
const imagePreview = document.getElementById('imagePreview');

imageInput.addEventListener('input', function() {
    const url = this.value;
    if(url) {
        imagePreview.innerHTML = `<img src="${url}" alt="Preview" style="max-width: 150px; border-radius: 8px;" onerror="this.src='https://via.placeholder.com/150x100/333/d4af37?text=No+Image'">`;
    } else {
        imagePreview.innerHTML = '';
    }
});
</script>
</body>
</html>