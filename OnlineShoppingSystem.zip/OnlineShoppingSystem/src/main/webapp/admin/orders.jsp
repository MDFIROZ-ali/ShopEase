<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.shopping.db.DatabaseConnection"%>
<%@ page import="java.sql.*"%>
<%@ page import="java.text.*"%>

<%
String email = (String) session.getAttribute("email");
if(email == null || !"admin@gmail.com".equals(email)) {
    response.sendRedirect("../login.jsp");
    return;
}
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Orders - ShopEase Luxury Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Space Grotesk', sans-serif;
            background: #0a0a0a;
            color: #ffffff;
        }
        
        /* Sidebar */
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            height: 100%;
            width: 280px;
            background: linear-gradient(180deg, #0f0f0f 0%, #0a0a0a 100%);
            border-right: 1px solid rgba(212, 175, 55, 0.15);
            padding: 25px 0;
            z-index: 100;
        }
        
        .sidebar-header {
            text-align: center;
            padding: 0 20px 25px;
            border-bottom: 1px solid rgba(212, 175, 55, 0.15);
            margin-bottom: 20px;
        }
        
        .sidebar-header h3 {
            font-size: 24px;
            font-weight: 700;
            background: linear-gradient(135deg, #d4af37, #fff);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
        
        .sidebar-header p {
            font-size: 12px;
            color: rgba(255,255,255,0.5);
            margin-top: 5px;
        }
        
        .sidebar-menu {
            padding: 0 15px;
        }
        
        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 12px 18px;
            margin: 5px 0;
            color: rgba(255,255,255,0.7);
            text-decoration: none;
            border-radius: 12px;
            transition: 0.3s;
            font-weight: 500;
        }
        
        .sidebar-menu a i {
            width: 25px;
            margin-right: 12px;
            font-size: 18px;
        }
        
        .sidebar-menu a:hover {
            background: rgba(212, 175, 55, 0.1);
            color: #d4af37;
        }
        
        .sidebar-menu a.active {
            background: linear-gradient(135deg, #d4af37, #b8960c);
            color: #0a0a0a;
        }
        
        /* Main Content */
        .main-content {
            margin-left: 280px;
            padding: 25px;
            min-height: 100vh;
        }
        
        /* Top Bar */
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid rgba(212, 175, 55, 0.15);
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .page-title h2 {
            font-size: 28px;
            font-weight: 700;
            background: linear-gradient(135deg, #fff, #d4af37);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
        
        .page-title p {
            color: rgba(255,255,255,0.5);
            font-size: 14px;
        }
        
        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: rgba(20, 20, 30, 0.6);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(212, 175, 55, 0.15);
            border-radius: 15px;
            padding: 20px;
            text-align: center;
        }
        
        .stat-number {
            font-size: 32px;
            font-weight: 700;
            color: #d4af37;
        }
        
        .stat-label {
            font-size: 13px;
            color: rgba(255,255,255,0.6);
            margin-top: 5px;
        }
        
        /* Filter Bar */
        .filter-bar {
            background: rgba(20, 20, 30, 0.6);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(212, 175, 55, 0.15);
            border-radius: 15px;
            padding: 15px 20px;
            margin-bottom: 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .filter-select {
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(212, 175, 55, 0.2);
            border-radius: 25px;
            padding: 8px 15px;
            color: white;
            cursor: pointer;
        }
        
        .search-input {
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(212, 175, 55, 0.2);
            border-radius: 25px;
            padding: 8px 15px;
            color: white;
            width: 250px;
        }
        
        .search-input:focus {
            outline: none;
            border-color: #d4af37;
        }
        
        /* Orders Table */
        .orders-table-container {
            background: rgba(20, 20, 30, 0.6);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(212, 175, 55, 0.15);
            border-radius: 20px;
            padding: 20px;
            overflow-x: auto;
        }
        
        .orders-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .orders-table th {
            text-align: left;
            padding: 15px 12px;
            color: #d4af37;
            font-weight: 600;
            border-bottom: 1px solid rgba(212, 175, 55, 0.15);
            white-space: nowrap;
        }
        
        .orders-table td {
            padding: 15px 12px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            vertical-align: middle;
        }
        
        .orders-table tr:hover {
            background: rgba(212, 175, 55, 0.05);
        }
        
        .status-badge {
            padding: 5px 12px;
            border-radius: 50px;
            font-size: 11px;
            font-weight: 600;
            display: inline-block;
        }
        
        .status-pending {
            background: rgba(255, 193, 7, 0.2);
            color: #ffc107;
            border: 1px solid rgba(255, 193, 7, 0.3);
        }
        
        .status-processing {
            background: rgba(23, 162, 184, 0.2);
            color: #17a2b8;
            border: 1px solid rgba(23, 162, 184, 0.3);
        }
        
        .status-shipped {
            background: rgba(0, 123, 255, 0.2);
            color: #007bff;
            border: 1px solid rgba(0, 123, 255, 0.3);
        }
        
        .status-delivered {
            background: rgba(40, 167, 69, 0.2);
            color: #28a745;
            border: 1px solid rgba(40, 167, 69, 0.3);
        }
        
        .status-cancelled {
            background: rgba(220, 53, 69, 0.2);
            color: #dc3545;
            border: 1px solid rgba(220, 53, 69, 0.3);
        }
        
        .payment-badge {
            font-size: 11px;
            padding: 3px 8px;
            border-radius: 20px;
            background: rgba(212, 175, 55, 0.15);
            color: #d4af37;
            display: inline-block;
        }
        
        .status-select {
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(212, 175, 55, 0.2);
            border-radius: 20px;
            padding: 5px 10px;
            color: white;
            font-size: 12px;
        }
        
        .update-btn {
            background: rgba(212, 175, 55, 0.2);
            border: 1px solid rgba(212, 175, 55, 0.3);
            color: #d4af37;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 11px;
            cursor: pointer;
            transition: 0.3s;
        }
        
        .update-btn:hover {
            background: #d4af37;
            color: #0a0a0a;
        }
        
        .alert {
            padding: 15px 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            font-size: 14px;
        }
        
        .alert-success {
            background: rgba(40, 167, 69, 0.2);
            border: 1px solid rgba(40, 167, 69, 0.3);
            color: #6bff6b;
        }
        
        .footer {
            text-align: center;
            padding: 25px 0;
            margin-top: 30px;
            border-top: 1px solid rgba(212, 175, 55, 0.15);
            color: rgba(255,255,255,0.4);
            font-size: 13px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 70px;
            }
            .sidebar-header h3, .sidebar-header p, .sidebar-menu a span {
                display: none;
            }
            .sidebar-menu a {
                justify-content: center;
                padding: 12px;
            }
            .sidebar-menu a i {
                margin-right: 0;
            }
            .main-content {
                margin-left: 70px;
            }
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <div class="sidebar-header">
        <h3><i class="fas fa-crown"></i> ShopEase</h3>
        <p>Admin Panel v2.0</p>
    </div>
    <div class="sidebar-menu">
        <a href="dashboard.jsp"><i class="fas fa-tachometer-alt"></i> <span>Dashboard</span></a>
        <a href="products.jsp"><i class="fas fa-box"></i> <span>Products</span></a>
        <a href="orders.jsp" class="active"><i class="fas fa-shopping-cart"></i> <span>Orders</span></a>
        <a href="users.jsp"><i class="fas fa-users"></i> <span>Users</span></a>
        <a href="../logout.jsp"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a>
    </div>
</div>

<!-- Main Content -->
<div class="main-content">
    <div class="top-bar">
        <div class="page-title">
            <h2><i class="fas fa-shopping-cart"></i> Order Management</h2>
            <p>Track and manage all customer orders</p>
        </div>
    </div>
    
    <%
    int totalOrders = 0;
    int pendingOrders = 0;
    int deliveredOrders = 0;
    double totalRevenue = 0;
    
    try {
        Connection con = DatabaseConnection.getConnection();
        Statement st = con.createStatement();
        
        ResultSet rs1 = st.executeQuery("SELECT COUNT(*) as count FROM cart WHERE address IS NOT NULL");
        if(rs1.next()) totalOrders = rs1.getInt("count");
        
        ResultSet rs2 = st.executeQuery("SELECT COUNT(*) as count FROM cart WHERE address IS NOT NULL AND (status='pending' OR status IS NULL)");
        if(rs2.next()) pendingOrders = rs2.getInt("count");
        
        ResultSet rs3 = st.executeQuery("SELECT COUNT(*) as count FROM cart WHERE address IS NOT NULL AND status='delivered'");
        if(rs3.next()) deliveredOrders = rs3.getInt("count");
        
        ResultSet rs4 = st.executeQuery("SELECT SUM(total) as revenue FROM cart WHERE address IS NOT NULL");
        if(rs4.next()) totalRevenue = rs4.getDouble("revenue");
        
        con.close();
    } catch(Exception e) {
        System.out.println(e);
    }
    %>
    
    <!-- Stats Cards -->
    <div class="stats-grid">
        <div class="stat-card"><div class="stat-number"><%=totalOrders%></div><div class="stat-label">Total Orders</div></div>
        <div class="stat-card"><div class="stat-number"><%=pendingOrders%></div><div class="stat-label">Pending</div></div>
        <div class="stat-card"><div class="stat-number"><%=deliveredOrders%></div><div class="stat-label">Delivered</div></div>
        <div class="stat-card"><div class="stat-number">₹ <%=String.format("%,d", (int)totalRevenue)%></div><div class="stat-label">Total Revenue</div></div>
    </div>
    
    <!-- Filter Bar -->
    <div class="filter-bar">
        <select id="statusFilter" class="filter-select" onchange="filterOrders()">
            <option value="all">All Orders</option>
            <option value="pending">Pending</option>
            <option value="processing">Processing</option>
            <option value="shipped">Shipped</option>
            <option value="delivered">Delivered</option>
            <option value="cancelled">Cancelled</option>
        </select>
        <input type="text" id="searchInput" class="search-input" placeholder="Search by email or order ID..." onkeyup="filterOrders()">
    </div>
    
    <%
    String msg = request.getParameter("msg");
    if("updated".equals(msg)) {
    %>
    <div class="alert alert-success">Order status updated successfully!</div>
    <% } %>
    
    <div class="orders-table-container">
        <table class="orders-table" id="ordersTable">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Customer</th>
                    <th>Product</th>
                    <th>Qty</th>
                    <th>Amount</th>
                    <th>Order Date</th>
                    <th>Payment</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <%
                DecimalFormat df = new DecimalFormat("#,###");
                try {
                    Connection con = DatabaseConnection.getConnection();
                    Statement st = con.createStatement();
                    ResultSet rs = st.executeQuery(
                        "SELECT c.*, u.email as customer_email, u.name as customer_name, p.name as product_name " +
                        "FROM cart c " +
                        "LEFT JOIN users u ON c.user_id = u.id " +
                        "LEFT JOIN product p ON c.product_id = p.id " +
                        "WHERE c.address IS NOT NULL " +
                        "ORDER BY c.orderDate DESC, c.id DESC"
                    );
                    
                    while(rs.next()) {
                        String status = rs.getString("status");
                        if(status == null) status = "pending";
                        
                        String statusClass = "status-pending";
                        if("processing".equals(status)) statusClass = "status-processing";
                        else if("shipped".equals(status)) statusClass = "status-shipped";
                        else if("delivered".equals(status)) statusClass = "status-delivered";
                        else if("cancelled".equals(status)) statusClass = "status-cancelled";
                        
                        String orderDate = rs.getString("orderDate");
                        if(orderDate == null) orderDate = "-";
                        
                        String paymentMethod = rs.getString("paymentMethod");
                        if(paymentMethod == null) paymentMethod = "COD";
                        
                        String customerName = rs.getString("customer_name");
                        if(customerName == null) customerName = rs.getString("customer_email");
                %>
                <tr data-status="<%=status%>" data-email="<%=rs.getString("customer_email")%>" data-id="<%=rs.getInt("id")%>">
                    <td>#<%=rs.getInt("id")%></td>
                    <td><%=rs.getString("customer_email")%></td>
                    <td><%=rs.getString("product_name") != null ? rs.getString("product_name") : "N/A"%></td>
                    <td><%=rs.getInt("quantity")%></td>
                    <td>₹ <%=df.format(rs.getInt("total"))%></td>
                    <td><%=orderDate%></td>
                    <td><span class="payment-badge"><%=paymentMethod%></span></td>
                    <td><span class="status-badge <%=statusClass%>"><%=status.toUpperCase()%></span></td>
                    <td>
                        <form action="update-order-status.jsp" method="post" style="display: flex; gap: 5px;">
                            <input type="hidden" name="orderId" value="<%=rs.getInt("id")%>">
                            <select name="status" class="status-select">
                                <option value="pending" <%=status.equals("pending") ? "selected" : ""%>>Pending</option>
                                <option value="processing" <%=status.equals("processing") ? "selected" : ""%>>Processing</option>
                                <option value="shipped" <%=status.equals("shipped") ? "selected" : ""%>>Shipped</option>
                                <option value="delivered" <%=status.equals("delivered") ? "selected" : ""%>>Delivered</option>
                                <option value="cancelled" <%=status.equals("cancelled") ? "selected" : ""%>>Cancelled</option>
                            </select>
                            <button type="submit" class="update-btn">Update</button>
                        </form>
                    </td>
                </tr>
                <%
                    }
                    con.close();
                } catch(Exception e) {
                    System.out.println(e);
                }
                %>
            </tbody>
        </table>
    </div>
    
    <div class="footer">
        <p>&copy; 2026 ShopEase Luxury Admin Panel. All rights reserved.</p>
    </div>
</div>

<script>
function filterOrders() {
    const status = document.getElementById('statusFilter').value;
    const search = document.getElementById('searchInput').value.toLowerCase();
    const rows = document.querySelectorAll('#ordersTable tbody tr');
    
    rows.forEach(row => {
        const rowStatus = row.getAttribute('data-status');
        const rowEmail = row.getAttribute('data-email') || '';
        const rowId = row.getAttribute('data-id') || '';
        
        let statusMatch = status === 'all' || rowStatus === status;
        let searchMatch = search === '' || rowEmail.includes(search) || rowId.includes(search);
        
        row.style.display = (statusMatch && searchMatch) ? '' : 'none';
    });
}
</script>
</body>
</html>