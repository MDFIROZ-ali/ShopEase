<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.shopping.db.DatabaseConnection"%>
<%@ page import="java.sql.*"%>
<%@ page import="java.text.*"%>

<%
String email = (String) session.getAttribute("email");
if(email == null || !"admin@gmail.com".equals(email)) {
    response.sendRedirect("../login.jsp");
    return;
}
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Products - ShopEase Luxury Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Space Grotesk', sans-serif;
            background: #0a0a0a;
            color: #ffffff;
        }
        
        /* Sidebar */
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            height: 100%;
            width: 280px;
            background: linear-gradient(180deg, #0f0f0f 0%, #0a0a0a 100%);
            border-right: 1px solid rgba(212, 175, 55, 0.15);
            padding: 25px 0;
            z-index: 100;
        }
        
        .sidebar-header {
            text-align: center;
            padding: 0 20px 25px;
            border-bottom: 1px solid rgba(212, 175, 55, 0.15);
            margin-bottom: 20px;
        }
        
        .sidebar-header h3 {
            font-size: 24px;
            font-weight: 700;
            background: linear-gradient(135deg, #d4af37, #fff);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
        
        .sidebar-header p {
            font-size: 12px;
            color: rgba(255,255,255,0.5);
            margin-top: 5px;
        }
        
        .sidebar-menu {
            padding: 0 15px;
        }
        
        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 12px 18px;
            margin: 5px 0;
            color: rgba(255,255,255,0.7);
            text-decoration: none;
            border-radius: 12px;
            transition: 0.3s;
            font-weight: 500;
        }
        
        .sidebar-menu a i {
            width: 25px;
            margin-right: 12px;
            font-size: 18px;
        }
        
        .sidebar-menu a:hover {
            background: rgba(212, 175, 55, 0.1);
            color: #d4af37;
        }
        
        .sidebar-menu a.active {
            background: linear-gradient(135deg, #d4af37, #b8960c);
            color: #0a0a0a;
        }
        
        /* Main Content */
        .main-content {
            margin-left: 280px;
            padding: 25px;
            min-height: 100vh;
        }
        
        /* Top Bar */
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid rgba(212, 175, 55, 0.15);
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .page-title h2 {
            font-size: 28px;
            font-weight: 700;
            background: linear-gradient(135deg, #fff, #d4af37);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
        
        .page-title p {
            color: rgba(255,255,255,0.5);
            font-size: 14px;
        }
        
        .btn-add {
            background: linear-gradient(135deg, #d4af37, #b8960c);
            color: #0a0a0a;
            padding: 12px 25px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 600;
            transition: 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-add:hover {
            transform: scale(1.02);
            box-shadow: 0 0 20px rgba(212, 175, 55, 0.4);
        }
        
        /* Alert Messages */
        .alert {
            padding: 15px 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            font-size: 14px;
        }
        
        .alert-success {
            background: rgba(40, 167, 69, 0.2);
            border: 1px solid rgba(40, 167, 69, 0.3);
            color: #6bff6b;
        }
        
        /* Products Table */
        .products-table-container {
            background: rgba(20, 20, 30, 0.6);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(212, 175, 55, 0.15);
            border-radius: 20px;
            padding: 20px;
            overflow-x: auto;
        }
        
        .products-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .products-table th {
            text-align: left;
            padding: 15px 12px;
            color: #d4af37;
            font-weight: 600;
            border-bottom: 1px solid rgba(212, 175, 55, 0.15);
        }
        
        .products-table td {
            padding: 15px 12px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            vertical-align: middle;
        }
        
        .products-table tr:hover {
            background: rgba(212, 175, 55, 0.05);
        }
        
        .product-img {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            object-fit: cover;
            background: rgba(212, 175, 55, 0.1);
        }
        
        .status-active {
            background: rgba(40, 167, 69, 0.2);
            color: #28a745;
            padding: 4px 12px;
            border-radius: 50px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
        }
        
        .status-inactive {
            background: rgba(220, 53, 69, 0.2);
            color: #dc3545;
            padding: 4px 12px;
            border-radius: 50px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
        }
        
        .stock-high {
            color: #28a745;
        }
        
        .stock-low {
            color: #ffc107;
        }
        
        .stock-out {
            color: #dc3545;
        }
        
        .btn-edit {
            background: rgba(23, 162, 184, 0.2);
            border: 1px solid rgba(23, 162, 184, 0.3);
            color: #17a2b8;
            padding: 6px 15px;
            border-radius: 20px;
            font-size: 12px;
            text-decoration: none;
            transition: 0.3s;
            margin-right: 8px;
            display: inline-block;
        }
        
        .btn-edit:hover {
            background: #17a2b8;
            color: white;
        }
        
        .btn-delete {
            background: rgba(220, 53, 69, 0.2);
            border: 1px solid rgba(220, 53, 69, 0.3);
            color: #ff6b6b;
            padding: 6px 15px;
            border-radius: 20px;
            font-size: 12px;
            text-decoration: none;
            transition: 0.3s;
            display: inline-block;
        }
        
        .btn-delete:hover {
            background: #dc3545;
            color: white;
        }
        
        /* Footer */
        .footer {
            text-align: center;
            padding: 25px 0;
            margin-top: 30px;
            border-top: 1px solid rgba(212, 175, 55, 0.15);
            color: rgba(255,255,255,0.4);
            font-size: 13px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 70px;
            }
            .sidebar-header h3, .sidebar-header p, .sidebar-menu a span {
                display: none;
            }
            .sidebar-menu a {
                justify-content: center;
                padding: 12px;
            }
            .sidebar-menu a i {
                margin-right: 0;
            }
            .main-content {
                margin-left: 70px;
            }
            .products-table th, .products-table td {
                padding: 10px 8px;
                font-size: 12px;
            }
            .btn-edit, .btn-delete {
                padding: 4px 10px;
                font-size: 10px;
            }
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <div class="sidebar-header">
        <h3><i class="fas fa-crown"></i> ShopEase</h3>
        <p>Admin Panel v2.0</p>
    </div>
    <div class="sidebar-menu">
        <a href="dashboard.jsp">
            <i class="fas fa-tachometer-alt"></i> <span>Dashboard</span>
        </a>
        <a href="products.jsp" class="active">
            <i class="fas fa-box"></i> <span>Products</span>
        </a>
        <a href="orders.jsp">
            <i class="fas fa-shopping-cart"></i> <span>Orders</span>
        </a>
        <a href="users.jsp">
            <i class="fas fa-users"></i> <span>Users</span>
        </a>
        <a href="../logout.jsp">
            <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
        </a>
    </div>
</div>

<!-- Main Content -->
<div class="main-content">
    <div class="top-bar">
        <div class="page-title">
            <h2><i class="fas fa-box"></i> Product Management</h2>
            <p>Manage your luxury product inventory</p>
        </div>
        <a href="add-product.jsp" class="btn-add">
            <i class="fas fa-plus-circle"></i> Add New Product
        </a>
    </div>
    
    <%
    String msg = request.getParameter("msg");
    if("added".equals(msg)) {
    %>
    <div class="alert alert-success">
        <i class="fas fa-check-circle"></i> Product added successfully!
    </div>
    <% } else if("updated".equals(msg)) { %>
    <div class="alert alert-success">
        <i class="fas fa-check-circle"></i> Product updated successfully!
    </div>
    <% } else if("deleted".equals(msg)) { %>
    <div class="alert alert-success">
        <i class="fas fa-check-circle"></i> Product deleted successfully!
    </div>
    <% } %>
    
    <div class="products-table-container">
        <table class="products-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Image</th>
                    <th>Product Name</th>
                    <th>Category</th>
                    <th>Price</th>
                    <th>Stock</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <%
                DecimalFormat df = new DecimalFormat("#,###");
                try {
                    Connection con = DatabaseConnection.getConnection();
                    Statement st = con.createStatement();
                    ResultSet rs = st.executeQuery("SELECT * FROM product ORDER BY id DESC");
                    
                    while(rs.next()) {
                        String imgUrl = rs.getString("image_url");
                        if(imgUrl == null || imgUrl.isEmpty()) {
                            imgUrl = "https://via.placeholder.com/50x50/1a1a2e/d4af37?text=" + rs.getString("name").charAt(0);
                        }
                        
                        int stock = rs.getInt("stock");
                        String stockClass = "stock-high";
                        String stockText = stock + " units";
                        if(stock == 0) {
                            stockClass = "stock-out";
                            stockText = "Out of Stock";
                        } else if(stock < 10) {
                            stockClass = "stock-low";
                            stockText = stock + " units (Low)";
                        }
                        
                        String active = rs.getString("active");
                %>
                <tr>
                    <td><%=rs.getInt("id")%></td>
                    <td><img src="<%=imgUrl%>" class="product-img" onerror="this.src='https://via.placeholder.com/50x50/1a1a2e/d4af37?text=No'"></td>
                    <td><%=rs.getString("name")%></td>
                    <td><%=rs.getString("category")%></td>
                    <td>₹ <%=df.format(rs.getInt("price"))%></td>
                    <td><span class="<%=stockClass%>"><%=stockText%></span></td>
                    <td>
                        <% if("Yes".equals(active)) { %>
                            <span class="status-active">Active</span>
                        <% } else { %>
                            <span class="status-inactive">Inactive</span>
                        <% } %>
                    </td>
                    <td>
                        <a href="edit-product.jsp?id=<%=rs.getInt("id")%>" class="btn-edit">
                            <i class="fas fa-edit"></i> Edit
                        </a>
                        <a href="delete-product.jsp?id=<%=rs.getInt("id")%>" class="btn-delete" onclick="return confirm('Are you sure you want to delete this product?')">
                            <i class="fas fa-trash-alt"></i> Delete
                        </a>
                    </td>
                </tr>
                <%
                    }
                    con.close();
                } catch(Exception e) {
                    System.out.println(e);
                %>
                <tr>
                    <td colspan="8" class="text-center" style="color: #ff6b6b;">Error loading products: <%=e.getMessage()%></td>
                </tr>
                <% } %>
            </tbody>
        </table>
    </div>
    
    <div class="footer">
        <p>&copy; 2024 ShopEase Luxury Admin Panel. All rights reserved.</p>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>