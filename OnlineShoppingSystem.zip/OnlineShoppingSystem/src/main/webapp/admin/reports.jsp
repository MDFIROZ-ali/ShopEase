<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.shopping.db.DatabaseConnection"%>
<%@ page import="java.sql.*"%>
<%@ page import="java.text.*"%>

<%
String email = (String) session.getAttribute("email");
if(email == null || !"admin@gmail.com".equals(email)) {
    response.sendRedirect("../login.jsp");
    return;
}
%>

<!DOCTYPE html>
<html>
<head>
    <title>Reports - ShopEase Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            height: 100%;
            width: 280px;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: white;
            padding: 20px 0;
        }
        .sidebar-menu a {
            display: block;
            padding: 12px 25px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
        }
        .sidebar-menu a:hover, .sidebar-menu a.active { background: #667eea; }
        .sidebar-menu a i { width: 25px; margin-right: 15px; }
        .main-content { margin-left: 280px; padding: 20px; }
        .top-bar { background: white; padding: 15px 20px; border-radius: 10px; margin-bottom: 20px; }
        .report-card { background: white; border-radius: 15px; padding: 20px; margin-bottom: 25px; box-shadow: 0 5px 15px rgba(0,0,0,0.08); }
        @media (max-width: 768px) {
            .sidebar { width: 70px; }
            .sidebar span { display: none; }
            .main-content { margin-left: 70px; }
        }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="text-center mb-4">
        <h3><i class="fas fa-shopping-bag"></i> <span>ShopEase</span></h3>
    </div>
    <div class="sidebar-menu">
        <a href="dashboard.jsp"><i class="fas fa-tachometer-alt"></i> <span>Dashboard</span></a>
        <a href="products.jsp"><i class="fas fa-box"></i> <span>Products</span></a>
        <a href="orders.jsp"><i class="fas fa-shopping-cart"></i> <span>Orders</span></a>
        <a href="users.jsp"><i class="fas fa-users"></i> <span>Users</span></a>
        <a href="reports.jsp" class="active"><i class="fas fa-chart-line"></i> <span>Reports</span></a>
        <a href="../logout.jsp"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a>
    </div>
</div>

<div class="main-content">
    <div class="top-bar">
        <h4><i class="fas fa-chart-line"></i> Sales Reports</h4>
    </div>

    <%
    DecimalFormat df = new DecimalFormat("#,###");
    int monthlySales = 0, weeklySales = 0, todaySales = 0;
    int totalOrders = 0, avgOrderValue = 0;
    
    try {
        Connection con = DatabaseConnection.getConnection();
        Statement st = con.createStatement();
        
        ResultSet rs1 = st.executeQuery("SELECT SUM(total) FROM cart WHERE address IS NOT NULL AND MONTH(orderDate) = MONTH(CURDATE())");
        if(rs1.next()) monthlySales = rs1.getInt(1);
        
        ResultSet rs2 = st.executeQuery("SELECT SUM(total) FROM cart WHERE address IS NOT NULL AND WEEK(orderDate) = WEEK(CURDATE())");
        if(rs2.next()) weeklySales = rs2.getInt(1);
        
        ResultSet rs3 = st.executeQuery("SELECT SUM(total) FROM cart WHERE address IS NOT NULL AND DATE(orderDate) = CURDATE()");
        if(rs3.next()) todaySales = rs3.getInt(1);
        
        ResultSet rs4 = st.executeQuery("SELECT COUNT(*) FROM cart WHERE address IS NOT NULL");
        if(rs4.next()) totalOrders = rs4.getInt(1);
        
        if(totalOrders > 0) avgOrderValue = monthlySales / totalOrders;
        
        con.close();
    } catch(Exception e) { System.out.println(e); }
    %>

    <div class="row">
        <div class="col-md-4 mb-3">
            <div class="report-card text-center">
                <i class="fas fa-calendar-day fa-3x text-primary mb-3"></i>
                <h3>₹<%=df.format(todaySales)%></h3>
                <p>Today's Sales</p>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="report-card text-center">
                <i class="fas fa-calendar-week fa-3x text-success mb-3"></i>
                <h3>₹<%=df.format(weeklySales)%></h3>
                <p>This Week's Sales</p>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="report-card text-center">
                <i class="fas fa-calendar-alt fa-3x text-warning mb-3"></i>
                <h3>₹<%=df.format(monthlySales)%></h3>
                <p>This Month's Sales</p>
            </div>
        </div>
    </div>

    <div class="report-card">
        <h5>Sales Chart</h5>
        <canvas id="salesChart" height="100"></canvas>
    </div>

    <div class="report-card">
        <h5>Top Selling Products</h5>
        <table class="table">
            <thead>
                <tr><th>Product</th><th>Quantity Sold</th><th>Revenue</th></tr>
            </thead>
            <tbody>
                <%
                try {
                    Connection con = DatabaseConnection.getConnection();
                    Statement st = con.createStatement();
                    ResultSet rs = st.executeQuery(
                        "SELECT p.name, SUM(c.quantity) as qty, SUM(c.total) as revenue " +
                        "FROM cart c JOIN product p ON c.product_id = p.id " +
                        "WHERE c.address IS NOT NULL GROUP BY p.id ORDER BY qty DESC LIMIT 5"
                    );
                    while(rs.next()) {
                %>
                <tr>
                    <td><%=rs.getString("name")%></td>
                    <td><%=rs.getInt("qty")%></td>
                    <td>₹<%=df.format(rs.getInt("revenue"))%></td>
                </tr>
                <%
                    }
                    con.close();
                } catch(Exception e) { System.out.println(e); }
                %>
            </tbody>
        </table>
    </div>
</div>

<script>
const ctx = document.getElementById('salesChart').getContext('2d');
new Chart(ctx, {
    type: 'line',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        datasets: [{
            label: 'Monthly Sales (₹)',
            data: [50000, 75000, 65000, 90000, 110000, 130000, 120000, 145000, 160000, 180000, 200000, <%=monthlySales%>],
            borderColor: '#667eea',
            backgroundColor: 'rgba(102, 126, 234, 0.1)',
            tension: 0.4,
            fill: true
        }]
    },
    options: { responsive: true, maintainAspectRatio: true }
});
</script>
</body>
</html>