<%@ page import="com.shopping.db.DatabaseConnection"%>
<%@ page import="java.sql.*"%>
<%
String userId = request.getParameter("id");
try {
    Connection con = DatabaseConnection.getConnection();
    PreparedStatement ps = con.prepareStatement("UPDATE users SET password='user123' WHERE id=?");
    ps.setString(1, userId);
    ps.executeUpdate();
    response.sendRedirect("users.jsp?msg=reset");
    con.close();
} catch(Exception e) {
    response.sendRedirect("users.jsp?msg=error");
}
%>