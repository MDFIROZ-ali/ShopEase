<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.shopping.db.DatabaseConnection"%>
<%@ page import="java.sql.*"%>

<%
String orderId = request.getParameter("orderId");
String status = request.getParameter("status");

try {
    Connection con = DatabaseConnection.getConnection();
    
    // Simple update without deliveryDate
    PreparedStatement ps = con.prepareStatement("UPDATE cart SET status=? WHERE id=?");
    ps.setString(1, status);
    ps.setString(2, orderId);
    ps.executeUpdate();
    
    response.sendRedirect("orders.jsp?msg=updated");
    con.close();
} catch(Exception e) {
    System.out.println("Update error: " + e);
    response.sendRedirect("orders.jsp?msg=error");
}
%>