<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.shopping.db.DatabaseConnection"%>
<%@ page import="java.sql.*"%>
<%@ page import="java.text.*"%>

<%
String email = (String) session.getAttribute("email");
if(email == null || !"admin@gmail.com".equals(email)) {
    response.sendRedirect("../login.jsp");
    return;
}
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - ShopEase Luxury Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Space Grotesk', sans-serif;
            background: #0a0a0a;
            color: #ffffff;
        }
        
        /* Sidebar */
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            height: 100%;
            width: 280px;
            background: linear-gradient(180deg, #0f0f0f 0%, #0a0a0a 100%);
            border-right: 1px solid rgba(212, 175, 55, 0.15);
            padding: 25px 0;
            z-index: 100;
        }
        
        .sidebar-header {
            text-align: center;
            padding: 0 20px 25px;
            border-bottom: 1px solid rgba(212, 175, 55, 0.15);
            margin-bottom: 20px;
        }
        
        .sidebar-header h3 {
            font-size: 24px;
            font-weight: 700;
            background: linear-gradient(135deg, #d4af37, #fff);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
        
        .sidebar-header p {
            font-size: 12px;
            color: rgba(255,255,255,0.5);
            margin-top: 5px;
        }
        
        .sidebar-menu {
            padding: 0 15px;
        }
        
        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 12px 18px;
            margin: 5px 0;
            color: rgba(255,255,255,0.7);
            text-decoration: none;
            border-radius: 12px;
            transition: 0.3s;
            font-weight: 500;
        }
        
        .sidebar-menu a i {
            width: 25px;
            margin-right: 12px;
            font-size: 18px;
        }
        
        .sidebar-menu a:hover {
            background: rgba(212, 175, 55, 0.1);
            color: #d4af37;
        }
        
        .sidebar-menu a.active {
            background: linear-gradient(135deg, #d4af37, #b8960c);
            color: #0a0a0a;
        }
        
        /* Main Content */
        .main-content {
            margin-left: 280px;
            padding: 25px;
            min-height: 100vh;
        }
        
        /* Top Bar */
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid rgba(212, 175, 55, 0.15);
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .page-title h2 {
            font-size: 28px;
            font-weight: 700;
            background: linear-gradient(135deg, #fff, #d4af37);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
        
        .page-title p {
            color: rgba(255,255,255,0.5);
            font-size: 14px;
        }
        
        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: rgba(20, 20, 30, 0.6);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(212, 175, 55, 0.15);
            border-radius: 15px;
            padding: 20px;
            text-align: center;
            transition: 0.3s;
        }
        
        .stat-card:hover {
            border-color: rgba(212, 175, 55, 0.4);
        }
        
        .stat-number {
            font-size: 32px;
            font-weight: 700;
            color: #d4af37;
        }
        
        .stat-label {
            font-size: 13px;
            color: rgba(255,255,255,0.6);
            margin-top: 5px;
        }
        
        /* Filter Bar */
        .filter-bar {
            background: rgba(20, 20, 30, 0.6);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(212, 175, 55, 0.15);
            border-radius: 15px;
            padding: 15px 20px;
            margin-bottom: 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .search-input {
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(212, 175, 55, 0.2);
            border-radius: 25px;
            padding: 10px 18px;
            color: white;
            width: 250px;
        }
        
        .search-input:focus {
            outline: none;
            border-color: #d4af37;
        }
        
        /* Users Table */
        .users-table-container {
            background: rgba(20, 20, 30, 0.6);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(212, 175, 55, 0.15);
            border-radius: 20px;
            padding: 20px;
            overflow-x: auto;
        }
        
        .users-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .users-table th {
            text-align: left;
            padding: 15px 12px;
            color: #d4af37;
            font-weight: 600;
            border-bottom: 1px solid rgba(212, 175, 55, 0.15);
        }
        
        .users-table td {
            padding: 15px 12px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            vertical-align: middle;
        }
        
        .users-table tr:hover {
            background: rgba(212, 175, 55, 0.05);
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #d4af37, #b8960c);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            color: #0a0a0a;
        }
        
        .role-badge {
            padding: 4px 12px;
            border-radius: 50px;
            font-size: 11px;
            font-weight: 600;
            display: inline-block;
        }
        
        .role-admin {
            background: rgba(212, 175, 55, 0.2);
            color: #d4af37;
            border: 1px solid rgba(212, 175, 55, 0.3);
        }
        
        .role-user {
            background: rgba(40, 167, 69, 0.2);
            color: #28a745;
            border: 1px solid rgba(40, 167, 69, 0.3);
        }
        
        .status-active {
            background: rgba(40, 167, 69, 0.2);
            color: #28a745;
            padding: 4px 10px;
            border-radius: 50px;
            font-size: 11px;
            display: inline-block;
        }
        
        .btn-view {
            background: rgba(23, 162, 184, 0.2);
            border: 1px solid rgba(23, 162, 184, 0.3);
            color: #17a2b8;
            padding: 6px 15px;
            border-radius: 20px;
            font-size: 12px;
            text-decoration: none;
            transition: 0.3s;
            margin-right: 5px;
            display: inline-block;
        }
        
        .btn-view:hover {
            background: #17a2b8;
            color: white;
        }
        
        .btn-reset {
            background: rgba(212, 175, 55, 0.2);
            border: 1px solid rgba(212, 175, 55, 0.3);
            color: #d4af37;
            padding: 6px 15px;
            border-radius: 20px;
            font-size: 12px;
            text-decoration: none;
            transition: 0.3s;
            display: inline-block;
        }
        
        .btn-reset:hover {
            background: #d4af37;
            color: #0a0a0a;
        }
        
        .btn-delete {
            background: rgba(220, 53, 69, 0.2);
            border: 1px solid rgba(220, 53, 69, 0.3);
            color: #ff6b6b;
            padding: 6px 15px;
            border-radius: 20px;
            font-size: 12px;
            text-decoration: none;
            transition: 0.3s;
            display: inline-block;
        }
        
        .btn-delete:hover {
            background: #dc3545;
            color: white;
        }
        
        /* Alert */
        .alert {
            padding: 15px 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            font-size: 14px;
        }
        
        .alert-success {
            background: rgba(40, 167, 69, 0.2);
            border: 1px solid rgba(40, 167, 69, 0.3);
            color: #6bff6b;
        }
        
        /* Pagination */
        .pagination {
            display: flex;
            justify-content: center;
            gap: 8px;
            margin-top: 25px;
        }
        
        .page-btn {
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(212, 175, 55, 0.2);
            border-radius: 8px;
            padding: 8px 12px;
            color: rgba(255,255,255,0.7);
            cursor: pointer;
            transition: 0.3s;
        }
        
        .page-btn:hover, .page-btn.active {
            background: #d4af37;
            color: #0a0a0a;
            border-color: #d4af37;
        }
        
        /* Modal */
        .modal-content {
            background: #1a1a2e;
            border: 1px solid rgba(212, 175, 55, 0.3);
            border-radius: 20px;
        }
        
        .modal-header {
            border-bottom: 1px solid rgba(212, 175, 55, 0.2);
        }
        
        .modal-header .btn-close {
            filter: invert(1);
        }
        
        .modal-title {
            color: #d4af37;
        }
        
        /* Footer */
        .footer {
            text-align: center;
            padding: 25px 0;
            margin-top: 30px;
            border-top: 1px solid rgba(212, 175, 55, 0.15);
            color: rgba(255,255,255,0.4);
            font-size: 13px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 70px;
            }
            .sidebar-header h3, .sidebar-header p, .sidebar-menu a span {
                display: none;
            }
            .sidebar-menu a {
                justify-content: center;
                padding: 12px;
            }
            .sidebar-menu a i {
                margin-right: 0;
            }
            .main-content {
                margin-left: 70px;
            }
            .users-table th, .users-table td {
                padding: 10px 8px;
                font-size: 12px;
            }
            .btn-view, .btn-reset, .btn-delete {
                padding: 4px 10px;
                font-size: 10px;
            }
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <div class="sidebar-header">
        <h3><i class="fas fa-crown"></i> ShopEase</h3>
        <p>Admin Panel v2.0</p>
    </div>
    <div class="sidebar-menu">
        <a href="dashboard.jsp">
            <i class="fas fa-tachometer-alt"></i> <span>Dashboard</span>
        </a>
        <a href="products.jsp">
            <i class="fas fa-box"></i> <span>Products</span>
        </a>
        <a href="orders.jsp">
            <i class="fas fa-shopping-cart"></i> <span>Orders</span>
        </a>
        <a href="users.jsp" class="active">
            <i class="fas fa-users"></i> <span>Users</span>
        </a>
        <a href="../logout.jsp">
            <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
        </a>
    </div>
</div>

<!-- Main Content -->
<div class="main-content">
    <div class="top-bar">
        <div class="page-title">
            <h2><i class="fas fa-users"></i> User Management</h2>
            <p>Manage your registered customers</p>
        </div>
    </div>
    
    <%
    // Get statistics
    int totalUsers = 0;
    int newUsersThisMonth = 0;
    
    try {
        Connection con = DatabaseConnection.getConnection();
        Statement st = con.createStatement();
        
        ResultSet rs1 = st.executeQuery("SELECT COUNT(*) as count FROM users WHERE role='user' OR role IS NULL");
        if(rs1.next()) totalUsers = rs1.getInt("count");
        
        ResultSet rs2 = st.executeQuery("SELECT COUNT(*) as count FROM users WHERE MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())");
        if(rs2.next()) newUsersThisMonth = rs2.getInt("count");
        
        con.close();
    } catch(Exception e) {
        System.out.println(e);
    }
    %>
    
    <!-- Stats Cards -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-number"><%=totalUsers%></div>
            <div class="stat-label">Total Customers</div>
        </div>
        <div class="stat-card">
            <div class="stat-number"><%=newUsersThisMonth%></div>
            <div class="stat-label">New This Month</div>
        </div>
        <div class="stat-card">
            <div class="stat-number">Active</div>
            <div class="stat-label">All users active</div>
        </div>
    </div>
    
    <!-- Filter Bar -->
    <div class="filter-bar">
        <input type="text" id="searchInput" class="search-input" placeholder="Search by name or email..." onkeyup="filterUsers()">
        <div>
            <button class="btn-reset" onclick="resetFilters()" style="background: rgba(212,175,55,0.2);"><i class="fas fa-sync-alt"></i> Reset</button>
        </div>
    </div>
    
    <%
    String msg = request.getParameter("msg");
    if("deleted".equals(msg)) {
    %>
    <div class="alert alert-success">
        <i class="fas fa-check-circle"></i> User deleted successfully!
    </div>
    <% } else if("reset".equals(msg)) { %>
    <div class="alert alert-success">
        <i class="fas fa-check-circle"></i> Password reset successfully!
    </div>
    <% } %>
    
    <div class="users-table-container">
        <table class="users-table" id="usersTable">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>User</th>
                    <th>Email</th>
                    <th>Mobile</th>
                    <th>Role</th>
                    <th>Joined Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <%
                DecimalFormat df = new DecimalFormat("#,###");
                try {
                    Connection con = DatabaseConnection.getConnection();
                    Statement st = con.createStatement();
                    ResultSet rs = st.executeQuery("SELECT * FROM users ORDER BY id DESC");
                    
                    while(rs.next()) {
                        String userRole = rs.getString("role");
                        if(userRole == null) userRole = "user";
                        int userId = rs.getInt("id");
                        String userName = rs.getString("name");
                        if(userName == null || userName.isEmpty()) {
                            userName = rs.getString("full_name");
                        }
                        if(userName == null || userName.isEmpty()) {
                            userName = "User";
                        }
                        String userEmail = rs.getString("email");
                        String userMobile = rs.getString("mobile");
                        if(userMobile == null) userMobile = rs.getString("mobileNumber");
                        if(userMobile == null) userMobile = "-";
                        
                        String createdAt = rs.getString("created_at");
                        if(createdAt == null) createdAt = "-";
                %>
                <td>
                    <td data-id="<%=userId%>"><%=userId%></td>
                    <td>
                        <div style="display: flex; align-items: center; gap: 12px;">
                            <div class="user-avatar">
                                <i class="fas fa-user"></i>
                            </div>
                            <div>
                                <strong><%=userName%></strong>
                            </div>
                        </div>
                    </td>
                    <td data-email="<%=userEmail%>"><%=userEmail%></td>
                    <td><%=userMobile%></td>
                    <td>
                        <% if("admin".equals(userRole)) { %>
                            <span class="role-badge role-admin"><i class="fas fa-crown"></i> Admin</span>
                        <% } else { %>
                            <span class="role-badge role-user"><i class="fas fa-user"></i> Customer</span>
                        <% } %>
                    </td>
                    <td><%=createdAt%></td>
                    <td>
                        <button class="btn-view" onclick="viewUserDetails(<%=userId%>, '<%=userName%>', '<%=userEmail%>', '<%=userMobile%>', '<%=createdAt%>')">
                            <i class="fas fa-eye"></i> View
                        </button>
                        <% if(!"admin".equals(userRole)) { %>
                            <button class="btn-reset" onclick="resetPassword(<%=userId%>)">
                                <i class="fas fa-key"></i> Reset
                            </button>
                            <button class="btn-delete" onclick="deleteUser(<%=userId%>)">
                                <i class="fas fa-trash-alt"></i> Delete
                            </button>
                        <% } %>
                    </td>
                </tr>
                <%
                    }
                    con.close();
                } catch(Exception e) {
                    System.out.println(e);
                %>
                <tr>
                    <td colspan="7" class="text-center" style="color: #ff6b6b;">Error loading users: <%=e.getMessage()%></td>
                </tr>
                <% } %>
            </tbody>
        </table>
    </div>
    
    <div class="footer">
        <p>&copy; 2024 ShopEase Luxury Admin Panel. All rights reserved.</p>
    </div>
</div>

<!-- User Details Modal -->
<div class="modal fade" id="userModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-user-circle"></i> User Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="userModalBody">
                <!-- Dynamic content -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function filterUsers() {
    const search = document.getElementById('searchInput').value.toLowerCase();
    const rows = document.querySelectorAll('#usersTable tbody tr');
    
    rows.forEach(row => {
        const name = row.cells[1]?.innerText.toLowerCase() || '';
        const email = row.cells[2]?.getAttribute('data-email')?.toLowerCase() || '';
        const id = row.cells[0]?.getAttribute('data-id') || '';
        
        if (name.includes(search) || email.includes(search) || id.includes(search)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

function resetFilters() {
    document.getElementById('searchInput').value = '';
    filterUsers();
}

function viewUserDetails(id, name, email, mobile, joinedDate) {
    const modalBody = document.getElementById('userModalBody');
    modalBody.innerHTML = `
        <div style="text-align: center; margin-bottom: 20px;">
            <div style="width: 80px; height: 80px; background: linear-gradient(135deg, #d4af37, #b8960c); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto;">
                <i class="fas fa-user" style="font-size: 40px; color: #0a0a0a;"></i>
            </div>
        </div>
        <table style="width: 100%;">
            <tr><td style="padding: 8px; color: #d4af37;"><strong>User ID:</strong></td><td>${id}</td></tr>
            <tr><td style="padding: 8px; color: #d4af37;"><strong>Name:</strong></td><td>${name}</td></tr>
            <tr><td style="padding: 8px; color: #d4af37;"><strong>Email:</strong></td><td>${email}</td></tr>
            <tr><td style="padding: 8px; color: #d4af37;"><strong>Mobile:</strong></td><td>${mobile}</td></tr>
            <tr><td style="padding: 8px; color: #d4af37;"><strong>Joined:</strong></td><td>${joinedDate}</td></tr>
        </table>
    `;
    new bootstrap.Modal(document.getElementById('userModal')).show();
}

function resetPassword(userId) {
    if(confirm('Reset password for this user? New password will be: user123')) {
        window.location.href = 'reset-user-password.jsp?id=' + userId;
    }
}

function deleteUser(userId) {
    if(confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
        window.location.href = 'delete-user.jsp?id=' + userId;
    }
}
</script>
</body>
</html>