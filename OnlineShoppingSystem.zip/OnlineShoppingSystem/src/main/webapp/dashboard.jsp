<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.shopping.db.DatabaseConnection"%>
<%@ page import="java.sql.*"%>
<%@ page import="java.text.*"%>

<%
String email = (String) session.getAttribute("email");
Integer userId = (Integer) session.getAttribute("userId");

if(email == null || userId == null) {
    response.sendRedirect("login.jsp");
    return;
}

// Get user statistics
int totalOrders = 0;
int totalSpent = 0;
int wishlistCount = 0;
int cartCount = 0;
String userName = "";

try {
    Connection con = DatabaseConnection.getConnection();
    
    // Get user name
    PreparedStatement psName = con.prepareStatement("SELECT name, full_name FROM users WHERE id = ?");
    psName.setInt(1, userId);
    ResultSet rsName = psName.executeQuery();
    if(rsName.next()) {
        userName = rsName.getString("name");
        if(userName == null || userName.isEmpty()) {
            userName = rsName.getString("full_name");
        }
        if(userName == null || userName.isEmpty()) {
            userName = email;
        }
    }
    
    // Get total orders count
    PreparedStatement psCount = con.prepareStatement("SELECT COUNT(*) as count FROM cart WHERE user_id=? AND address IS NOT NULL");
    psCount.setInt(1, userId);
    ResultSet rsCount = psCount.executeQuery();
    if(rsCount.next()) {
        totalOrders = rsCount.getInt("count");
    }
    
    // Get total spent - JOIN with product table to get price
    PreparedStatement psSpent = con.prepareStatement(
        "SELECT COALESCE(SUM(p.price * c.quantity), 0) as spent FROM cart c " +
        "JOIN product p ON c.product_id = p.id " +
        "WHERE c.user_id=? AND c.address IS NOT NULL"
    );
    psSpent.setInt(1, userId);
    ResultSet rsSpent = psSpent.executeQuery();
    if(rsSpent.next()) {
        totalSpent = rsSpent.getInt("spent");
    }
    
    // Get wishlist count
    PreparedStatement psWish = con.prepareStatement("SELECT COUNT(*) as count FROM wishlist WHERE user_id=?");
    psWish.setInt(1, userId);
    ResultSet rsWish = psWish.executeQuery();
    if(rsWish.next()) {
        wishlistCount = rsWish.getInt("count");
    }
    
    
    // Get cart count - count all items in cart for this user
    PreparedStatement psCart = con.prepareStatement("SELECT COALESCE(SUM(quantity), 0) as count FROM cart WHERE user_id=?");
    psCart.setInt(1, userId);
    ResultSet rsCart = psCart.executeQuery();
    if(rsCart.next()) {
        cartCount = rsCart.getInt("count");
    }
    
    con.close();
} catch(Exception e) {
    System.out.println("Dashboard error: " + e);
    e.printStackTrace();
}
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Dashboard - ShopEase Luxury</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Space Grotesk', sans-serif;
            background: #0a0a0a;
            color: #ffffff;
        }
        
        /* Premium Navbar */
        .navbar {
            background: rgba(10, 10, 10, 0.95);
            backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(212, 175, 55, 0.2);
            padding: 18px 0;
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        
        .navbar-brand {
            font-size: 28px;
            font-weight: 700;
            background: linear-gradient(135deg, #fff, #d4af37);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
        
        .navbar-brand i {
            color: #d4af37;
        }
        
        .nav-link {
            color: rgba(255, 255, 255, 0.8) !important;
            margin: 0 15px;
            transition: 0.3s;
        }
        
        .nav-link:hover {
            color: #d4af37 !important;
        }
        
        /* Dashboard Container */
        .dashboard-container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 0 20px;
        }
        
        /* Welcome Header */
        .welcome-header {
            background: linear-gradient(135deg, rgba(212,175,55,0.15), rgba(0,0,0,0));
            border: 1px solid rgba(212,175,55,0.2);
            border-radius: 25px;
            padding: 35px;
            margin-bottom: 35px;
        }
        
        .welcome-header h1 {
            font-size: 32px;
            font-weight: 700;
            background: linear-gradient(135deg, #fff, #d4af37);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            margin-bottom: 8px;
        }
        
        .welcome-header p {
            color: rgba(255, 255, 255, 0.7);
            font-size: 14px;
        }
        
        .user-avatar {
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, #d4af37, #b8960c);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-left: auto;
        }
        
        .user-avatar i {
            font-size: 38px;
            color: #0a0a0a;
        }
        
        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 40px;
        }
        
        .stat-card {
            background: rgba(20, 20, 30, 0.6);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(212, 175, 55, 0.15);
            border-radius: 18px;
            padding: 20px 15px;
            text-align: center;
            transition: 0.3s;
        }
        
        .stat-card:hover {
            transform: translateY(-3px);
            border-color: #d4af37;
        }
        
        .stat-icon {
            width: 50px;
            height: 50px;
            background: rgba(212, 175, 55, 0.15);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 12px;
        }
        
        .stat-icon i {
            font-size: 24px;
            color: #d4af37;
        }
        
        .stat-number {
            font-size: 28px;
            font-weight: 800;
            color: #d4af37;
            margin-bottom: 5px;
        }
        
        .stat-label {
            color: rgba(255, 255, 255, 0.7);
            font-size: 12px;
        }
        
        /* Action Cards */
        .actions-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 40px;
        }
        
        .action-card {
            background: rgba(20, 20, 30, 0.6);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(212, 175, 55, 0.15);
            border-radius: 18px;
            padding: 25px 15px;
            text-align: center;
            transition: 0.3s;
            cursor: pointer;
        }
        
        .action-card:hover {
            transform: translateY(-5px);
            border-color: #d4af37;
        }
        
        .action-icon {
            width: 65px;
            height: 65px;
            background: linear-gradient(135deg, #d4af37, #b8960c);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
        }
        
        .action-icon i {
            font-size: 32px;
            color: #0a0a0a;
        }
        
        .action-card h3 {
            font-size: 18px;
            font-weight: 700;
            margin-bottom: 8px;
            color: white;
        }
        
        .action-card p {
            color: rgba(255, 255, 255, 0.6);
            font-size: 12px;
            margin-bottom: 15px;
        }
        
        .btn-action {
            background: linear-gradient(135deg, #d4af37, #b8960c);
            color: #0a0a0a;
            padding: 8px 20px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 600;
            font-size: 13px;
            display: inline-block;
            transition: 0.3s;
        }
        
        .btn-action:hover {
            transform: scale(1.02);
        }
        
        /* Recent Orders */
        .recent-section {
            background: rgba(20, 20, 30, 0.6);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(212, 175, 55, 0.15);
            border-radius: 18px;
            padding: 25px;
        }
        
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            flex-wrap: wrap;
            gap: 10px;
        }
        
        .section-header h3 {
            font-size: 20px;
            font-weight: 700;
            color: white;
            margin: 0;
        }
        
        .section-header a {
            color: #d4af37;
            text-decoration: none;
            font-size: 13px;
        }
        
        .order-item {
            padding: 12px 0;
            border-bottom: 1px solid rgba(255,255,255,0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
        }
        
        .order-item:last-child {
            border-bottom: none;
        }
        
        .order-id {
            font-weight: 700;
            color: #d4af37;
            font-size: 14px;
        }
        
        .order-date {
            font-size: 11px;
            color: rgba(255,255,255,0.5);
        }
        
        .order-status {
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
        }
        
        .status-pending {
            background: rgba(255,193,7,0.2);
            color: #ffc107;
        }
        
        .status-processing {
            background: rgba(23,162,184,0.2);
            color: #17a2b8;
        }
        
        .status-delivered {
            background: rgba(40,167,69,0.2);
            color: #28a745;
        }
        
        .order-amount {
            font-weight: 700;
            color: #d4af37;
            font-size: 14px;
        }
        
        .empty-state {
            text-align: center;
            padding: 30px;
            color: rgba(255,255,255,0.5);
        }
        
        .empty-state i {
            font-size: 50px;
            margin-bottom: 15px;
            color: rgba(212,175,55,0.3);
        }
        
        /* Footer */
        .footer {
            background: #050505;
            border-top: 1px solid rgba(212, 175, 55, 0.2);
            padding: 30px 0;
            text-align: center;
            margin-top: 40px;
        }
        
        .footer p {
            color: rgba(255, 255, 255, 0.5);
            font-size: 13px;
        }
        
        @media (max-width: 992px) {
            .stats-grid, .actions-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        
        @media (max-width: 576px) {
            .stats-grid, .actions-grid {
                grid-template-columns: 1fr;
            }
            .welcome-header h1 {
                font-size: 24px;
            }
            .user-avatar {
                margin: 15px auto 0;
            }
        }
    </style>
</head>
<body>

<!-- Premium Navbar -->
<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="index.jsp">
            <i class="fas fa-crown"></i> ShopEase
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon" style="filter: invert(1);"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.jsp">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="user/products.jsp">Products</a></li>
                <li class="nav-item"><a class="nav-link" href="user/cart.jsp">Cart</a></li>
                <li class="nav-item"><a class="nav-link" href="user/wishlist.jsp">Wishlist</a></li>
                <li class="nav-item"><a class="nav-link" href="user/orders.jsp">Orders</a></li>
                <li class="nav-item"><a class="nav-link" href="logout.jsp">Logout</a></li>
                <li class="nav-item"><span style="color: #d4af37;"><i class="fas fa-user-circle"></i> <%=email%></span></li>
            </ul>
        </div>
    </div>
</nav>

<!-- Dashboard Container -->
<div class="dashboard-container">
    
    <!-- Welcome Header -->
    <div class="welcome-header">
        <div class="row align-items-center">
            <div class="col-md-8">
                <h1>Welcome back, <%=userName%>!</h1>
                <p>We're delighted to see you again. Explore your luxury shopping journey.</p>
            </div>
            <div class="col-md-4 text-end">
                <div class="user-avatar">
                    <i class="fas fa-user-circle"></i>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Stats Cards -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon"><i class="fas fa-shopping-bag"></i></div>
            <div class="stat-number"><%=totalOrders%></div>
            <div class="stat-label">Total Orders</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon"><i class="fas fa-rupee-sign"></i></div>
            <div class="stat-number">₹ <%=String.format("%,d", totalSpent)%></div>
            <div class="stat-label">Total Spent</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon"><i class="fas fa-heart"></i></div>
            <div class="stat-number"><%=wishlistCount%></div>
            <div class="stat-label">Wishlist Items</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon"><i class="fas fa-shopping-cart"></i></div>
            <div class="stat-number"><%=cartCount%></div>
            <div class="stat-label">Cart Items</div>
        </div>
    </div>
    
    <!-- Action Cards -->
    <div class="actions-grid">
        <div class="action-card" onclick="location.href='user/orders.jsp'">
            <div class="action-icon"><i class="fas fa-truck"></i></div>
            <h3>My Orders</h3>
            <p>Track and manage your orders</p>
            <a href="user/orders.jsp" class="btn-action">View Orders <i class="fas fa-arrow-right"></i></a>
        </div>
        
        <div class="action-card" onclick="location.href='user/products.jsp'">
            <div class="action-icon"><i class="fas fa-box-open"></i></div>
            <h3>Shop Now</h3>
            <p>Discover luxury products</p>
            <a href="user/products.jsp" class="btn-action">Start Shopping <i class="fas fa-arrow-right"></i></a>
        </div>
        
        <div class="action-card" onclick="location.href='user/wishlist.jsp'">
            <div class="action-icon"><i class="fas fa-heart"></i></div>
            <h3>My Wishlist</h3>
            <p>View your saved items</p>
            <a href="user/wishlist.jsp" class="btn-action">View Wishlist <i class="fas fa-arrow-right"></i></a>
        </div>
        
        <div class="action-card" onclick="location.href='user/cart.jsp'">
            <div class="action-icon"><i class="fas fa-shopping-cart"></i></div>
            <h3>My Cart</h3>
            <p>Review your cart items</p>
            <a href="user/cart.jsp" class="btn-action">Go to Cart <i class="fas fa-arrow-right"></i></a>
        </div>
    </div>
    
    <!-- Recent Orders Section -->
    <div class="recent-section">
        <div class="section-header">
            <h3><i class="fas fa-clock"></i> Recent Orders</h3>
            <a href="user/orders.jsp">View All <i class="fas fa-arrow-right"></i></a>
        </div>
        
        <%
        DecimalFormat df = new DecimalFormat("#,###");
        boolean hasOrders = false;
        try {
            Connection con = DatabaseConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(
                "SELECT c.*, p.price as product_price FROM cart c " +
                "JOIN product p ON c.product_id = p.id " +
                "WHERE c.user_id = ? AND c.address IS NOT NULL ORDER BY c.id DESC LIMIT 3"
            );
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()) {
                hasOrders = true;
                String status = rs.getString("status");
                if(status == null) status = "pending";
                String statusClass = "status-pending";
                if("processing".equals(status)) statusClass = "status-processing";
                else if("delivered".equals(status)) statusClass = "status-delivered";
                
                int orderTotal = rs.getInt("total");
                if(orderTotal == 0) {
                    orderTotal = rs.getInt("product_price") * rs.getInt("quantity");
                }
        %>
        <div class="order-item">
            <div>
                <div class="order-id">Order #<%=rs.getInt("id")%></div>
                <div class="order-date"><%=rs.getString("orderDate") != null ? rs.getString("orderDate") : "Processing"%></div>
            </div>
            <span class="order-status <%=statusClass%>"><%=status.toUpperCase()%></span>
            <div class="order-amount">₹ <%=df.format(orderTotal)%></div>
        </div>
        <%
            }
            con.close();
        } catch(Exception e) {
            System.out.println("Recent orders error: " + e);
        }
        
        if(!hasOrders) {
        %>
        <div class="empty-state">
            <i class="fas fa-shopping-bag"></i>
            <p>You haven't placed any orders yet.</p>
            <a href="user/products.jsp" class="btn-action" style="margin-top: 15px;">Start Shopping</a>
        </div>
        <% } %>
    </div>
</div>

<!-- Footer -->
<footer class="footer">
    <div class="container">
        <p>&copy; 2026 ShopEase Luxury. All rights reserved. | Welcome back, <%=userName%>!</p>
    </div>
</footer>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>