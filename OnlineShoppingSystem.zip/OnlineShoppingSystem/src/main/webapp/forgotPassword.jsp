<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.shopping.db.DatabaseConnection"%>
<%@ page import="java.sql.*"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - ShopEase</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea, #764ba2);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: 'Segoe UI', sans-serif;
            padding: 20px;
        }
        .card {
            background: white;
            padding: 40px;
            border-radius: 20px;
            width: 100%;
            max-width: 450px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            animation: fadeIn 0.5s ease;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .card i {
            font-size: 60px;
            display: block;
            text-align: center;
            color: #667eea;
            margin-bottom: 20px;
        }
        h2 {
            text-align: center;
            margin-bottom: 10px;
            color: #333;
        }
        p {
            text-align: center;
            color: #666;
            margin-bottom: 30px;
            font-size: 14px;
        }
        input {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
        }
        input:focus {
            border-color: #667eea;
            outline: none;
        }
        button {
            width: 100%;
            padding: 12px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            margin-top: 20px;
            transition: 0.3s;
        }
        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102,126,234,0.4);
        }
        .alert {
            padding: 10px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
        }
        .alert-success {
            background: #d4edda;
            color: #155724;
        }
        .alert-danger {
            background: #f8d7da;
            color: #721c24;
        }
        .back-link {
            display: block;
            text-align: center;
            margin-top: 15px;
            color: #667eea;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="card">
        <i class="fas fa-key"></i>
        <h2>Reset Password</h2>
        <p>Enter your email and new password</p>
        
        <%
        String msg = request.getParameter("msg");
        if("success".equals(msg)) {
        %>
        <div class="alert alert-success">
            <i class="fas fa-check-circle"></i> Password reset successful! <a href="login.jsp">Login here</a>
        </div>
        <%
        } else if("notfound".equals(msg)) {
        %>
        <div class="alert alert-danger">
            <i class="fas fa-exclamation-circle"></i> Email not found!
        </div>
        <%
        } else if("short".equals(msg)) {
        %>
        <div class="alert alert-danger">
            <i class="fas fa-exclamation-circle"></i> Password must be at least 4 characters!
        </div>
        <%
        }
        %>
        
        <form action="resetPasswordAction.jsp" method="post">
            <input type="email" name="email" placeholder="Email Address" required>
            <input type="password" name="newPassword" placeholder="New Password" required>
            <button type="submit">Reset Password</button>
        </form>
        
        <a href="login.jsp" class="back-link">Back to Login</a>
    </div>
</body>
</html>