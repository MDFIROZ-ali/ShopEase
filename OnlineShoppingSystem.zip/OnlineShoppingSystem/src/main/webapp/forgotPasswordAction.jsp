<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.shopping.db.DatabaseConnection"%>
<%@ page import="java.sql.*"%>

<%
String email = request.getParameter("email");

try {
    Connection con = DatabaseConnection.getConnection();
    PreparedStatement ps = con.prepareStatement("SELECT * FROM users WHERE email=?");
    ps.setString(1, email);
    ResultSet rs = ps.executeQuery();
    
    if(rs.next()) {
        // Check if user has security question set
        String securityQuestion = rs.getString("securityQuestion");
        if(securityQuestion != null && !securityQuestion.isEmpty()) {
            response.sendRedirect("forgotPassword.jsp?step=security&email=" + email);
        } else {
            String tempPassword = "temp123";
            PreparedStatement updatePs = con.prepareStatement("UPDATE users SET password=? WHERE email=?");
            updatePs.setString(1, tempPassword);
            updatePs.setString(2, email);
            updatePs.executeUpdate();
            response.sendRedirect("forgotPassword.jsp?msg=sent");
        }
    } else {
        response.sendRedirect("forgotPassword.jsp?msg=notfound");
    }
    con.close();
} catch(Exception e) {
    System.out.println("Error: " + e);
    response.sendRedirect("forgotPassword.jsp?msg=notfound");
}
%>