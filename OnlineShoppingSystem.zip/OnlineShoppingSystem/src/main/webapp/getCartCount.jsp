<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.shopping.db.DatabaseConnection"%>
<%@ page import="java.sql.*"%>

<%
Integer userId = (Integer) session.getAttribute("userId");
int count = 0;

if(userId != null) {
    try {
        Connection con = DatabaseConnection.getConnection();
        PreparedStatement ps = con.prepareStatement("SELECT SUM(quantity) as total FROM cart WHERE user_id=?");
        ps.setInt(1, userId);
        ResultSet rs = ps.executeQuery();
        if(rs.next()) {
            count = rs.getInt("total");
        }
        con.close();
    } catch(Exception e) {
        System.out.println("Cart count error: " + e);
    }
}
out.print(count);
%>