<%@ page import="com.shopping.db.DatabaseConnection"%>
<%@ page import="java.sql.*"%>

<%
String cartId = request.getParameter("id");
String action = request.getParameter("action");

try {
    Connection con = DatabaseConnection.getConnection();
    
    if("inc".equals(action)) {
        PreparedStatement ps = con.prepareStatement("UPDATE cart SET quantity = quantity + 1 WHERE id = ?");
        ps.setString(1, cartId);
        ps.executeUpdate();
    } else if("dec".equals(action)) {
        PreparedStatement ps = con.prepareStatement("UPDATE cart SET quantity = quantity - 1 WHERE id = ? AND quantity > 1");
        ps.setString(1, cartId);
        ps.executeUpdate();
    }
    
    response.sendRedirect("user/cart.jsp");
    con.close();
} catch(Exception e) {
    response.sendRedirect("user/cart.jsp");
}
%>