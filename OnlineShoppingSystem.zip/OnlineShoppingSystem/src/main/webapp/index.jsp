<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.shopping.db.DatabaseConnection"%>
<%@ page import="java.sql.*"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ShopEase | Futuristic Luxury E-Commerce</title>
    <!-- Bootstrap 5 + Icons + Fonts -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Space Grotesk', sans-serif;
            background: #0a0a0a;
            color: #ffffff;
            overflow-x: hidden;
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar { width: 8px; }
        ::-webkit-scrollbar-track { background: #1a1a1a; }
        ::-webkit-scrollbar-thumb { background: linear-gradient(135deg, #d4af37, #667eea); border-radius: 10px; }

        /* Glassmorphism Navbar */
        .navbar {
            background: rgba(10, 10, 10, 0.85);
            backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(212, 175, 55, 0.2);
            padding: 18px 0;
            transition: all 0.3s;
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        .navbar.scrolled {
            padding: 12px 0;
            background: rgba(10, 10, 10, 0.95);
            box-shadow: 0 5px 25px rgba(0,0,0,0.3);
        }
        .navbar-brand {
            font-size: 28px;
            font-weight: 700;
            background: linear-gradient(135deg, #fff, #d4af37, #667eea);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            letter-spacing: 1px;
        }
        .navbar-brand i {
            color: #d4af37;
            margin-right: 5px;
        }
        .nav-link {
            color: rgba(255,255,255,0.8) !important;
            font-weight: 500;
            margin: 0 12px;
            transition: 0.3s;
            position: relative;
        }
        .nav-link:hover {
            color: #d4af37 !important;
        }
        .nav-link::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 50%;
            transform: translateX(-50%);
            width: 0;
            height: 2px;
            background: linear-gradient(90deg, #d4af37, #667eea);
            transition: 0.3s;
            border-radius: 2px;
        }
        .nav-link:hover::after {
            width: 70%;
        }
        .search-glass {
            background: rgba(255,255,255,0.08);
            border: 1px solid rgba(212,175,55,0.3);
            border-radius: 50px;
            padding: 8px 18px;
            color: white;
            width: 220px;
            transition: 0.3s;
        }
        .search-glass:focus {
            outline: none;
            border-color: #d4af37;
            box-shadow: 0 0 15px rgba(212,175,55,0.2);
            width: 260px;
        }
        .cart-icon {
            position: relative;
            font-size: 22px;
            color: white;
            transition: 0.3s;
        }
        .cart-icon:hover { color: #d4af37; transform: scale(1.05); }
        .cart-count {
            position: absolute;
            top: -8px;
            right: -12px;
            background: #d4af37;
            color: #0a0a0a;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 10px;
            font-weight: bold;
        }
        .btn-glow {
            background: linear-gradient(135deg, #d4af37, #b8960c);
            border: none;
            border-radius: 50px;
            padding: 8px 25px;
            color: #0a0a0a;
            font-weight: 600;
            transition: 0.3s;
            box-shadow: 0 0 10px rgba(212,175,55,0.3);
        }
        .btn-glow:hover {
            transform: translateY(-2px);
            box-shadow: 0 0 25px rgba(212,175,55,0.6);
        }

        /* Hero Section */
        .hero {
            height: 90vh;
            position: relative;
            background: radial-gradient(circle at 20% 50%, #1a1a2e, #0a0a0a);
            overflow: hidden;
            display: flex;
            align-items: center;
        }
        .hero::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="rgba(212,175,55,0.05)" d="M0,96L48,112C96,128,192,160,288,160C384,160,480,128,576,122.7C672,117,768,139,864,154.7C960,171,1056,181,1152,165.3C1248,149,1344,107,1392,85.3L1440,64L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg>') no-repeat bottom;
            background-size: cover;
        }
        .glow-text {
            font-size: 68px;
            font-weight: 800;
            background: linear-gradient(135deg, #fff, #d4af37, #667eea);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            animation: fadeInUp 0.8s ease;
        }
        .hero p {
            font-size: 18px;
            color: rgba(255,255,255,0.7);
            margin: 20px 0;
        }
        .btn-hero-gold {
            background: linear-gradient(135deg, #d4af37, #b8960c);
            border: none;
            border-radius: 50px;
            padding: 14px 35px;
            font-weight: 700;
            margin-right: 15px;
            transition: 0.3s;
            box-shadow: 0 0 15px rgba(212,175,55,0.4);
        }
        .btn-hero-outline {
    background: transparent;
    border: 2px solid #d4af37;           /* Gold border */
    color: #f0e6d2;                       /* Light cream text (VISIBLE) */
    border-radius: 50px;
    padding: 12px 32px;
    font-weight: 600;
    transition: 0.3s;
}
.btn-hero-outline:hover {
    background: #d4af37;                  /* Gold fill on hover */
    color: #0a0a0a;                       /* Dark text on hover */
    box-shadow: 0 0 20px rgba(212,175,55,0.5);
}
        .floating-element {
            position: absolute;
            right: 5%;
            top: 50%;
            transform: translateY(-50%);
            width: 400px;
            height: 400px;
            background: radial-gradient(circle, rgba(212,175,55,0.15), transparent);
            border-radius: 50%;
            animation: float 4s ease-in-out infinite;
        }
        @keyframes float { 0%,100% { transform: translateY(-50%) translateX(0); } 50% { transform: translateY(-55%) translateX(-10px); } }
        @keyframes fadeInUp { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }

        /* Glass Cards */
        .glass-card {
            background: rgba(20, 20, 30, 0.6);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(212,175,55,0.2);
            border-radius: 20px;
            transition: 0.4s;
            padding: 30px 20px;
            text-align: center;
            height: 100%;
        }
        .glass-card:hover {
            transform: translateY(-10px);
            border-color: #d4af37;
            box-shadow: 0 15px 35px rgba(212,175,55,0.2);
        }
        .glass-card i { font-size: 45px; background: linear-gradient(135deg, #d4af37, #667eea); -webkit-background-clip: text; background-clip: text; color: transparent; margin-bottom: 15px; display: inline-block; }

        /* Product Cards */
        .product-card {
            background: rgba(20, 20, 30, 0.7);
            backdrop-filter: blur(8px);
            border: 1px solid rgba(212,175,55,0.15);
            border-radius: 20px;
            overflow: hidden;
            transition: 0.4s;
            margin-bottom: 30px;
        }
        .product-card:hover {
            transform: translateY(-8px);
            border-color: #d4af37;
            box-shadow: 0 15px 35px rgba(212,175,55,0.2);
        }
        .product-img {
            height: 220px;
            overflow: hidden;
            position: relative;
        }
        .product-img img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: 0.5s;
        }
        .product-card:hover .product-img img { transform: scale(1.08); }
        .product-badge {
            position: absolute;
            top: 15px;
            left: 15px;
            background: #d4af37;
            color: #0a0a0a;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: bold;
        }
        .product-info { padding: 20px; text-align: center; }
        .product-title { font-size: 18px; font-weight: 600; margin-bottom: 8px; color: white; }
        .product-price { font-size: 22px; font-weight: 700; color: #d4af37; margin: 10px 0; }
        .rating { color: #d4af37; margin-bottom: 10px; }
        .btn-add-cart {
            width: 100%;
            padding: 10px;
            background: linear-gradient(135deg, #d4af37, #b8960c);
            color: #0a0a0a;
            border: none;
            border-radius: 50px;
            font-weight: 600;
            transition: 0.3s;
        }
        .btn-add-cart:hover { transform: scale(1.02); box-shadow: 0 0 15px rgba(212,175,55,0.5); }

        /* Offer Banner */
        .offer-banner {
            background: linear-gradient(135deg, #1a1a2e, #0a0a0a);
            border: 1px solid rgba(212,175,55,0.3);
            border-radius: 30px;
            padding: 60px 40px;
            text-align: center;
            margin: 40px 0;
            position: relative;
            overflow: hidden;
        }
        .offer-banner::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(212,175,55,0.1), transparent);
            animation: rotate 20s linear infinite;
        }
        @keyframes rotate { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        .countdown-box {
            background: rgba(0,0,0,0.5);
            backdrop-filter: blur(5px);
            border: 1px solid #d4af37;
            border-radius: 15px;
            padding: 15px;
            min-width: 90px;
            display: inline-block;
            margin: 0 10px;
        }
        .countdown-number { font-size: 36px; font-weight: 800; color: #d4af37; }

        /* Testimonial */
        .testimonial-card {
            background: rgba(20, 20, 30, 0.6);
            backdrop-filter: blur(8px);
            border: 1px solid rgba(212,175,55,0.2);
            border-radius: 20px;
            padding: 25px;
            text-align: center;
            transition: 0.3s;
        }
        .testimonial-card:hover { border-color: #d4af37; transform: translateY(-5px); }
        .testimonial-avatar {
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, #d4af37, #667eea);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            font-size: 30px;
            color: #0a0a0a;
        }

        /* Footer */
        .footer {
            background: #050505;
            border-top: 1px solid rgba(212,175,55,0.2);
            padding: 60px 0 30px;
            margin-top: 60px;
        }
        .footer h5 { color: #d4af37; margin-bottom: 20px; }
        .footer a { color: rgba(255,255,255,0.6); text-decoration: none; transition: 0.3s; }
        .footer a:hover { color: #d4af37; padding-left: 5px; }
        .social-icon {
            display: inline-block;
            width: 40px;
            height: 40px;
            background: rgba(255,255,255,0.05);
            border-radius: 50%;
            text-align: center;
            line-height: 40px;
            margin-right: 10px;
            transition: 0.3s;
        }
        .social-icon:hover { background: #d4af37; color: #0a0a0a; transform: translateY(-3px); }
        .newsletter-input {
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(212,175,55,0.3);
            border-radius: 50px;
            padding: 12px 20px;
            width: 70%;
            color: white;
        }
        .footer-bottom { text-align: center; padding-top: 30px; margin-top: 30px; border-top: 1px solid rgba(255,255,255,0.05); }

        /* Responsive */
        @media (max-width: 768px) {
            .glow-text { font-size: 40px; }
            .hero { height: 70vh; text-align: center; }
            .floating-element { display: none; }
            .countdown-box { padding: 10px; min-width: 70px; margin: 5px; }
            .countdown-number { font-size: 24px; }
        }
    </style>
</head>
<body>

<!-- Premium Futuristic Navbar -->
<nav class="navbar navbar-expand-lg fixed-top">
    <div class="container">
        <a class="navbar-brand" href="index.jsp"><i class="fas fa-crown"></i> ShopEase</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon" style="filter: invert(1);"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item"><a class="nav-link" href="index.jsp">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="user/products.jsp">Products</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Categories</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Deals</a></li>
            </ul>
            <div class="d-flex align-items-center gap-3">
                <div class="position-relative">
                    <input type="text" class="search-glass" placeholder="Search...">
                    <i class="fas fa-search position-absolute" style="right: 15px; top: 12px; color: #888;"></i>
                </div>
                <a href="user/cart.jsp" class="cart-icon"><i class="fas fa-shopping-cart"></i><span class="cart-count" id="cartCount">0</span></a>
                <%
                    String email = (String) session.getAttribute("email");
                    if(email != null && !email.isEmpty()) {
                %>
                <div class="dropdown">
                    <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown"><i class="fas fa-user-circle"></i> <%=email%></a>
                    <ul class="dropdown-menu dropdown-menu-dark">
                        <li><a class="dropdown-item" href="user/orders.jsp">My Orders</a></li>
                        <li><a class="dropdown-item" href="user/wishlist.jsp">Wishlist</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="logout.jsp">Logout</a></li>
                    </ul>
                </div>
                <% } else { %>
                <a href="login.jsp" class="btn-glow">Login</a>
                <a href="signup.jsp" class="nav-link">Register</a>
                <% } %>
            </div>
        </div>
    </div>
</nav>

<!-- Hero Section -->
<section class="hero">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <h1 class="glow-text">Future of<br>Luxury Shopping</h1>
                <p>Experience the next generation of e-commerce with premium products, exclusive deals, and next-day delivery.</p>
                <div>
                    <a href="user/products.jsp" class="btn btn-hero-gold">Shop Now <i class="fas fa-arrow-right"></i></a>
                    <a href="#" class="btn btn-hero-outline">Explore Collection</a>
                </div>
            </div>
            <div class="col-lg-6 text-center">
                <div class="floating-element"></div>
                <i class="fas fa-shopping-bag" style="font-size: 250px; color: rgba(212,175,55,0.15); position: relative; z-index: 2;"></i>
            </div>
        </div>
    </div>
</section>

<!-- Features -->
<section class="container my-5">
    <div class="row g-4">
        <div class="col-md-3"><div class="glass-card"><i class="fas fa-gem"></i><h5>Premium Quality</h5><p class="small">Luxury products only</p></div></div>
        <div class="col-md-3"><div class="glass-card"><i class="fas fa-truck-fast"></i><h5>Express Delivery</h5><p class="small">Free shipping over ₹999</p></div></div>
        <div class="col-md-3"><div class="glass-card"><i class="fas fa-shield-alt"></i><h5>Secure Payment</h5><p class="small">100% protected</p></div></div>
        <div class="col-md-3"><div class="glass-card"><i class="fas fa-headset"></i><h5>24/7 Support</h5><p class="small">Dedicated concierge</p></div></div>
    </div>
</section>

<!-- Categories -->
<section class="container my-5">
    <h2 class="text-center mb-5" style="color: #d4af37;">Luxury Collections</h2>
    <div class="row g-4">
        <div class="col-md-2 col-6"><div class="glass-card" onclick="location.href='user/products.jsp?category=Electronics'"><i class="fas fa-mobile-alt"></i><h6>Electronics</h6></div></div>
        <div class="col-md-2 col-6"><div class="glass-card" onclick="location.href='user/products.jsp?category=Fashion'"><i class="fas fa-tshirt"></i><h6>Fashion</h6></div></div>
        <div class="col-md-2 col-6"><div class="glass-card" onclick="location.href='user/products.jsp?category=Watches'"><i class="fas fa-clock"></i><h6>Luxury Watches</h6></div></div>
        <div class="col-md-2 col-6"><div class="glass-card" onclick="location.href='user/products.jsp?category=Sports'"><i class="fas fa-futbol"></i><h6>Sports</h6></div></div>
        <div class="col-md-2 col-6"><div class="glass-card" onclick="location.href='user/products.jsp?category=Gaming'"><i class="fas fa-gamepad"></i><h6>Gaming</h6></div></div>
        <div class="col-md-2 col-6"><div class="glass-card" onclick="location.href='user/products.jsp?category=Beauty'"><i class="fas fa-spa"></i><h6>Beauty</h6></div></div>
    </div>
</section>

<!-- Featured Products -->
<section class="container my-5">
    <h2 class="text-center mb-5" style="color: #d4af37;">Featured Masterpieces</h2>
    <div class="row">
        <%
        try {
            Connection con = DatabaseConnection.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM product WHERE active='Yes' LIMIT 4");
            while(rs.next()) {
                String imgUrl = rs.getString("image_url");
                if(imgUrl == null || imgUrl.isEmpty()) imgUrl = "https://via.placeholder.com/300x220/1a1a2e/d4af37?text=" + rs.getString("name");
        %>
        <div class="col-lg-3 col-md-6">
            <div class="product-card">
                <div class="product-img"><img src="<%=imgUrl%>" alt="<%=rs.getString("name")%>"><span class="product-badge">Exclusive</span></div>
                <div class="product-info">
                    <div class="product-title"><%=rs.getString("name")%></div>
                    <div class="rating"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star-half-alt"></i> <span style="color:#888;">(128)</span></div>
                    <div class="product-price">₹ <%=String.format("%,d", rs.getInt("price"))%></div>
                    <a href="addToCartAction.jsp?id=<%=rs.getInt("id")%>" class="btn-add-cart">Add to Cart</a>
                </div>
            </div>
        </div>
        <% } con.close(); } catch(Exception e) { System.out.println(e); } %>
    </div>
    <div class="text-center mt-4"><a href="user/products.jsp" class="btn-glow" style="padding: 12px 35px;">View All Products <i class="fas fa-arrow-right"></i></a></div>
</section>

<!-- Special Offer Banner -->
<section class="container">
    <div class="offer-banner">
        <h2 style="font-size: 48px; font-weight: 800;">Flash Sale <span style="color:#d4af37;">70% OFF</span></h2>
        <p>Limited time luxury deals. Premium items at unbeatable prices.</p>
        <div class="countdown d-flex justify-content-center flex-wrap" id="countdown">
            <div class="countdown-box"><div class="countdown-number" id="days">00</div><div>Days</div></div>
            <div class="countdown-box"><div class="countdown-number" id="hours">00</div><div>Hours</div></div>
            <div class="countdown-box"><div class="countdown-number" id="minutes">00</div><div>Mins</div></div>
            <div class="countdown-box"><div class="countdown-number" id="seconds">00</div><div>Secs</div></div>
        </div>
        <a href="user/products.jsp" class="btn-glow mt-4" style="display: inline-block;">Shop Sale <i class="fas fa-tag"></i></a>
    </div>
</section>

<!-- Testimonials -->
<section class="container my-5">
    <h2 class="text-center mb-5" style="color: #d4af37;">Elite Reviews</h2>
    <div class="row g-4">
        <div class="col-md-4"><div class="testimonial-card"><div class="testimonial-avatar"><i class="fas fa-user"></i></div><div class="rating mb-2"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i></div><p>"Absolutely premium experience. The quality exceeded expectations."</p><h6>— Vikram Rathore</h6></div></div>
        <div class="col-md-4"><div class="testimonial-card"><div class="testimonial-avatar"><i class="fas fa-user"></i></div><div class="rating mb-2"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i></div><p>"Fast delivery, stunning packaging, and authentic products."</p><h6>— Neha Sharma</h6></div></div>
        <div class="col-md-4"><div class="testimonial-card"><div class="testimonial-avatar"><i class="fas fa-user"></i></div><div class="rating mb-2"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i></div><p>"Best luxury shopping platform in India. Highly recommended!"</p><h6>— Aditya Mehta</h6></div></div>
    </div>
</section>

<!-- Footer -->
<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-4 mb-4"><h5><i class="fas fa-crown"></i> ShopEase</h5><p style="color:#888;">Redefining luxury e-commerce with premium products and exceptional service.</p><div><a href="#" class="social-icon"><i class="fab fa-instagram"></i></a><a href="#" class="social-icon"><i class="fab fa-twitter"></i></a><a href="#" class="social-icon"><i class="fab fa-facebook-f"></i></a></div></div>
            <div class="col-md-2 mb-4"><h5>Explore</h5><p><a href="index.jsp">Home</a></p><p><a href="user/products.jsp">Products</a></p><p><a href="user/cart.jsp">Cart</a></p></div>
            <div class="col-md-3 mb-4"><h5>Support</h5><p><a href="#">FAQ</a></p><p><a href="#">Returns</a></p><p><a href="#">Privacy</a></p></div>
            <div class="col-md-3 mb-4"><h5>Newsletter</h5><div><input type="email" placeholder="Your email" class="newsletter-input"><button class="btn-glow mt-2 w-100">Subscribe</button></div></div>
        </div>
        <div class="footer-bottom"><p>&copy; 2026 ShopEase. The Future of Luxury Shopping.</p></div>
    </div>
</footer>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Navbar scroll effect
    window.addEventListener('scroll', function() { document.querySelector('.navbar').classList.toggle('scrolled', window.scrollY > 50); });
    // Countdown
    function startCountdown() { let target = new Date(); target.setDate(target.getDate() + 3); target.setHours(23,59,59,999); setInterval(() => { let now = new Date().getTime(), dist = target - now; document.getElementById('days').innerHTML = String(Math.floor(dist / (1000*60*60*24))).padStart(2,'0'); document.getElementById('hours').innerHTML = String(Math.floor((dist % (86400000)) / 3600000)).padStart(2,'0'); document.getElementById('minutes').innerHTML = String(Math.floor((dist % 3600000) / 60000)).padStart(2,'0'); document.getElementById('seconds').innerHTML = String(Math.floor((dist % 60000) / 1000)).padStart(2,'0'); }, 1000); }
    startCountdown();
    function updateCartCount() { $.ajax({ url: 'getCartCount.jsp', success: function(c) { $('.cart-count').text(c); } }); }
    $(document).ready(function() { updateCartCount(); });
</script>
</body>
</html>