<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - ShopEase Luxury</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Space Grotesk', sans-serif;
            background: #0a0a0a;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow-x: hidden;
        }
        
        /* Animated Background */
        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: radial-gradient(circle at 20% 50%, rgba(212,175,55,0.05), transparent);
            pointer-events: none;
        }
        
        /* Floating Particles */
        .particle {
            position: absolute;
            background: rgba(212,175,55,0.3);
            border-radius: 50%;
            pointer-events: none;
            animation: float 6s ease-in-out infinite;
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0) translateX(0); opacity: 0.3; }
            50% { transform: translateY(-20px) translateX(10px); opacity: 0.6; }
        }
        
        /* Login Card */
        .login-card {
            background: rgba(20, 20, 30, 0.7);
            backdrop-filter: blur(15px);
            border: 1px solid rgba(212, 175, 55, 0.2);
            border-radius: 30px;
            padding: 45px 40px;
            width: 100%;
            max-width: 450px;
            margin: 20px;
            position: relative;
            z-index: 10;
            transition: 0.3s;
            box-shadow: 0 25px 50px rgba(0,0,0,0.3);
        }
        
        .login-card:hover {
            border-color: rgba(212, 175, 55, 0.4);
            box-shadow: 0 25px 50px rgba(212,175,55,0.1);
        }
        
        /* Logo */
        .logo {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .logo i {
            font-size: 60px;
            background: linear-gradient(135deg, #d4af37, #fff);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
        
        .logo h2 {
            font-size: 32px;
            font-weight: 700;
            background: linear-gradient(135deg, #fff, #d4af37);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            margin-top: 10px;
        }
        
        .logo p {
            color: rgba(255,255,255,0.5);
            font-size: 14px;
        }
        
        /* Form Fields */
        .input-group {
            margin-bottom: 25px;
            position: relative;
        }
        
        .input-group i {
            position: absolute;
            left: 18px;
            top: 50%;
            transform: translateY(-50%);
            color: #d4af37;
            font-size: 18px;
            z-index: 2;
        }
        
        .input-group input {
            width: 100%;
            padding: 15px 15px 15px 50px;
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(212,175,55,0.2);
            border-radius: 50px;
            color: white;
            font-size: 16px;
            transition: 0.3s;
        }
        
        .input-group input:focus {
            outline: none;
            border-color: #d4af37;
            box-shadow: 0 0 20px rgba(212,175,55,0.2);
            background: rgba(255,255,255,0.08);
        }
        
        .input-group input::placeholder {
            color: rgba(255,255,255,0.4);
        }
        
        /* Options Row */
        .options {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            font-size: 13px;
        }
        
        .remember {
            display: flex;
            align-items: center;
            gap: 8px;
            color: rgba(255,255,255,0.6);
            cursor: pointer;
        }
        
        .remember input {
            accent-color: #d4af37;
            width: 16px;
            height: 16px;
            cursor: pointer;
        }
        
        .forgot-link {
            color: #d4af37;
            text-decoration: none;
            transition: 0.3s;
        }
        
        .forgot-link:hover {
            text-decoration: underline;
        }
        
        /* Login Button */
        .btn-login {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #d4af37, #b8960c);
            border: none;
            border-radius: 50px;
            color: #0a0a0a;
            font-size: 18px;
            font-weight: 700;
            cursor: pointer;
            transition: 0.3s;
            margin-bottom: 20px;
        }
        
        .btn-login:hover {
            transform: scale(1.02);
            box-shadow: 0 0 25px rgba(212,175,55,0.5);
        }
        
        /* Signup Link */
        .signup-link {
            text-align: center;
            color: rgba(255,255,255,0.6);
            font-size: 14px;
        }
        
        .signup-link a {
            color: #d4af37;
            text-decoration: none;
            font-weight: 600;
        }
        
        .signup-link a:hover {
            text-decoration: underline;
        }
        
        /* Alert Messages */
        .alert {
            padding: 12px 18px;
            border-radius: 50px;
            margin-bottom: 20px;
            font-size: 14px;
            text-align: center;
            animation: fadeIn 0.5s ease;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .alert-danger {
            background: rgba(220,53,69,0.2);
            border: 1px solid rgba(220,53,69,0.3);
            color: #ff6b6b;
        }
        
        .alert-success {
            background: rgba(40,167,69,0.2);
            border: 1px solid rgba(40,167,69,0.3);
            color: #6bff6b;
        }
        
        /* Responsive */
        @media (max-width: 480px) {
            .login-card {
                padding: 35px 25px;
                margin: 15px;
            }
            .logo h2 {
                font-size: 28px;
            }
        }
    </style>
</head>
<body>

<!-- Floating Particles -->
<div class="particle" style="width: 100px; height: 100px; top: 10%; left: 5%; animation-duration: 8s;"></div>
<div class="particle" style="width: 60px; height: 60px; bottom: 15%; right: 8%; animation-duration: 6s;"></div>
<div class="particle" style="width: 40px; height: 40px; top: 30%; right: 15%; animation-duration: 10s;"></div>
<div class="particle" style="width: 80px; height: 80px; bottom: 20%; left: 10%; animation-duration: 7s;"></div>

<div class="login-card">
    <div class="logo">
        <i class="fas fa-crown"></i>
        <h2>ShopEase</h2>
        <p>Welcome back to luxury shopping</p>
    </div>
    
    <%
    String msg = request.getParameter("msg");
    if("notexist".equals(msg)) {
    %>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-circle"></i> Invalid email or password!
    </div>
    <% } else if("invalid".equals(msg)) { %>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-circle"></i> Something went wrong! Please try again.
    </div>
    <% } else if("registered".equals(msg)) { %>
    <div class="alert alert-success">
        <i class="fas fa-check-circle"></i> Registration successful! Please login.
    </div>
    <% } else if("passwordreset".equals(msg)) { %>
    <div class="alert alert-success">
        <i class="fas fa-check-circle"></i> Password reset successful! Please login with your new password.
    </div>
    <% } %>
    
    <form action="loginAction.jsp" method="post">
        <div class="input-group">
            <i class="fas fa-envelope"></i>
            <input type="email" name="email" placeholder="Email Address" required autofocus>
        </div>
        
        <div class="input-group">
            <i class="fas fa-lock"></i>
            <input type="password" name="password" placeholder="Password" required>
        </div>
        
        <div class="options">
            <label class="remember">
                <input type="checkbox" name="remember"> Remember Me
            </label>
            <a href="forgotPassword.jsp" class="forgot-link">Forgot Password?</a>
        </div>
        
        <button type="submit" class="btn-login">
            <i class="fas fa-sign-in-alt"></i> Login
        </button>
    </form>
    
    <div class="signup-link">
        Don't have an account? <a href="signup.jsp">Create Account</a>
    </div>
</div>

</body>
</html>