<%@ page import="com.shopping.db.DatabaseConnection"%>
<%@ page import="java.sql.*"%>

<%
String email = request.getParameter("email");
String password = request.getParameter("password");

// Check if Admin
if("admin@gmail.com".equals(email) && "admin123".equals(password))
{
    session.setAttribute("email", email);
    session.setAttribute("role", "admin");
    response.sendRedirect("admin/dashboard.jsp");  // Goes to ADMIN dashboard
}
else
{
    try
    {
        Connection con = DatabaseConnection.getConnection();
        PreparedStatement ps = con.prepareStatement("SELECT * FROM users WHERE email=? AND password=?");
        ps.setString(1, email);
        ps.setString(2, password);
        ResultSet rs = ps.executeQuery();
        
        if(rs.next())
        {
            session.setAttribute("email", email);
            session.setAttribute("userId", rs.getInt("id"));
            session.setAttribute("role", "user");
            response.sendRedirect("dashboard.jsp");  // Goes to USER dashboard
        }
        else
        {
            response.sendRedirect("login.jsp?msg=notexist");
        }
        con.close();
    }
    catch(Exception e)
    {
        response.sendRedirect("login.jsp?msg=invalid");
    }
}
%>