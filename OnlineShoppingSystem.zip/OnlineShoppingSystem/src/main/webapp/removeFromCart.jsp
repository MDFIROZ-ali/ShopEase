<%@ page import="com.shopping.db.DatabaseConnection"%>
<%@ page import="java.sql.*"%>

<%
String cartId = request.getParameter("id");

try {
    Connection con = DatabaseConnection.getConnection();
    PreparedStatement ps = con.prepareStatement("DELETE FROM cart WHERE id = ?");
    ps.setString(1, cartId);
    ps.executeUpdate();
    response.sendRedirect("user/cart.jsp");
    con.close();
} catch(Exception e) {
    response.sendRedirect("user/cart.jsp");
}
%>