<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.shopping.db.DatabaseConnection"%>
<%@ page import="java.sql.*"%>

<%
String email = request.getParameter("email");
String newPassword = request.getParameter("newPassword");

// Check password length
if(newPassword.length() < 4) {
    response.sendRedirect("forgotPassword.jsp?msg=short");
    return;
}

try {
    Connection con = DatabaseConnection.getConnection();
    
    // Check if email exists
    PreparedStatement checkPs = con.prepareStatement("SELECT * FROM users WHERE email=?");
    checkPs.setString(1, email);
    ResultSet rs = checkPs.executeQuery();
    
    if(rs.next()) {
        // Update password
        PreparedStatement updatePs = con.prepareStatement("UPDATE users SET password=? WHERE email=?");
        updatePs.setString(1, newPassword);
        updatePs.setString(2, email);
        updatePs.executeUpdate();
        response.sendRedirect("forgotPassword.jsp?msg=success");
    } else {
        response.sendRedirect("forgotPassword.jsp?msg=notfound");
    }
    con.close();
} catch(Exception e) {
    System.out.println("Reset error: " + e);
    response.sendRedirect("forgotPassword.jsp?msg=error");
}
%>