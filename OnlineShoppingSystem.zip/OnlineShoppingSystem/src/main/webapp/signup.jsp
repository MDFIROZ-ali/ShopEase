<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - ShopEase Luxury</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Space Grotesk', sans-serif;
            background: #0a0a0a;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px 20px;
        }
        
        .signup-card {
            background: rgba(20, 20, 30, 0.7);
            backdrop-filter: blur(15px);
            border: 1px solid rgba(212, 175, 55, 0.2);
            border-radius: 30px;
            padding: 45px 40px;
            width: 100%;
            max-width: 500px;
            transition: 0.3s;
            box-shadow: 0 25px 50px rgba(0,0,0,0.3);
        }
        
        .signup-card:hover {
            border-color: rgba(212, 175, 55, 0.4);
        }
        
        .logo {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .logo i {
            font-size: 60px;
            background: linear-gradient(135deg, #d4af37, #fff);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
        
        .logo h2 {
            font-size: 32px;
            font-weight: 700;
            background: linear-gradient(135deg, #fff, #d4af37);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            margin-top: 10px;
        }
        
        .logo p {
            color: rgba(255,255,255,0.5);
            font-size: 14px;
        }
        
        .input-group {
            margin-bottom: 20px;
            position: relative;
        }
        
        .input-group i {
            position: absolute;
            left: 18px;
            top: 50%;
            transform: translateY(-50%);
            color: #d4af37;
            font-size: 18px;
            z-index: 2;
        }
        
        .input-group input {
            width: 100%;
            padding: 14px 15px 14px 50px;
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(212,175,55,0.2);
            border-radius: 50px;
            color: white;
            font-size: 15px;
            transition: 0.3s;
        }
        
        .input-group input:focus {
            outline: none;
            border-color: #d4af37;
            box-shadow: 0 0 20px rgba(212,175,55,0.2);
        }
        
        .input-group input::placeholder {
            color: rgba(255,255,255,0.4);
        }
        
        .btn-signup {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #d4af37, #b8960c);
            border: none;
            border-radius: 50px;
            color: #0a0a0a;
            font-size: 18px;
            font-weight: 700;
            cursor: pointer;
            transition: 0.3s;
            margin-top: 10px;
            margin-bottom: 20px;
        }
        
        .btn-signup:hover {
            transform: scale(1.02);
            box-shadow: 0 0 25px rgba(212,175,55,0.5);
        }
        
        .login-link {
            text-align: center;
            color: rgba(255,255,255,0.6);
            font-size: 14px;
        }
        
        .login-link a {
            color: #d4af37;
            text-decoration: none;
            font-weight: 600;
        }
        
        .login-link a:hover {
            text-decoration: underline;
        }
        
        .alert {
            padding: 12px 18px;
            border-radius: 50px;
            margin-bottom: 20px;
            font-size: 14px;
            text-align: center;
        }
        
        .alert-danger {
            background: rgba(220,53,69,0.2);
            border: 1px solid rgba(220,53,69,0.3);
            color: #ff6b6b;
        }
        
        @media (max-width: 480px) {
            .signup-card {
                padding: 35px 25px;
            }
        }
    </style>
</head>
<body>

<div class="signup-card">
    <div class="logo">
        <i class="fas fa-crown"></i>
        <h2>Create Account</h2>
        <p>Join the luxury shopping experience</p>
    </div>
    
    <%
    String msg = request.getParameter("msg");
    if("exists".equals(msg)) {
    %>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-circle"></i> Email already exists! Please use different email.
    </div>
    <% } else if("error".equals(msg)) { %>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-circle"></i> Registration failed! Please try again.
    </div>
    <% } %>
    
    <form action="signupAction.jsp" method="post">
        <div class="input-group">
            <i class="fas fa-user"></i>
            <input type="text" name="name" placeholder="Full Name" required>
        </div>
        
        <div class="input-group">
            <i class="fas fa-envelope"></i>
            <input type="email" name="email" placeholder="Email Address" required>
        </div>
        
        <div class="input-group">
            <i class="fas fa-phone"></i>
            <input type="text" name="mobileNumber" placeholder="Mobile Number" required>
        </div>
        
        <div class="input-group">
            <i class="fas fa-lock"></i>
            <input type="password" name="password" placeholder="Password" required>
        </div>
        
        <button type="submit" class="btn-signup">
            <i class="fas fa-user-plus"></i> Create Account
        </button>
    </form>
    
    <div class="login-link">
        Already have an account? <a href="login.jsp">Login here</a>
    </div>
</div>

</body>
</html>