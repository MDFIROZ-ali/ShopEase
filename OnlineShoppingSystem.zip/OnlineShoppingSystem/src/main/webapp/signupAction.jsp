<%@ page import="com.shopping.db.DatabaseConnection"%>
<%@ page import="java.sql.*"%>

<%
String name = request.getParameter("name");
String email = request.getParameter("email");
String mobileNumber = request.getParameter("mobileNumber");
String password = request.getParameter("password");

try {
    Connection con = DatabaseConnection.getConnection();
    
    // Check if email exists
    PreparedStatement check = con.prepareStatement("SELECT * FROM users WHERE email=?");
    check.setString(1, email);
    ResultSet rs = check.executeQuery();
    
    if(rs.next()) {
        response.sendRedirect("signup.jsp?msg=exists");
    } else {
        // Insert new user
        PreparedStatement insert = con.prepareStatement("INSERT INTO users (full_name, email, mobile, password, role) VALUES (?,?,?,?,'user')");
        insert.setString(1, name);
        insert.setString(2, email);
        insert.setString(3, mobileNumber);
        insert.setString(4, password);
        insert.executeUpdate();
        response.sendRedirect("login.jsp?msg=registered");
    }
    con.close();
} catch(Exception e) {
    response.sendRedirect("signup.jsp?msg=error");
}
%>