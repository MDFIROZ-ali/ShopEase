<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<a href="addToCartAction.jsp?id=1">TEST ADD TO CART (Product ID 1)</a>