<%@ page import="com.shopping.db.DatabaseConnection"%>
<%@ page import="java.sql.*"%>

<h2>Product List Debug</h2>
<table border="1">
    <tr><th>ID</th><th>Name</th><th>Active</th><th>Action</th></tr>
<%
try {
    Connection con = DatabaseConnection.getConnection();
    Statement st = con.createStatement();
    ResultSet rs = st.executeQuery("SELECT id, name, active FROM product");
    
    while(rs.next()) {
%>
    <tr>
        <td><%=rs.getInt("id")%></td>
        <td><%=rs.getString("name")%></td>
        <td><%=rs.getString("active")%></td>
        <td><a href="addToCartAction.jsp?id=<%=rs.getInt("id")%>">Test Add to Cart</a></td>
    </tr>
<%
    }
    con.close();
} catch(Exception e) {
    out.println("Error: " + e);
}
%>
</table>