<%@ page import="com.shopping.db.DatabaseConnection"%>
<%@ page import="java.sql.*"%>
<%
Integer userId = (Integer) session.getAttribute("userId");
if(userId == null) { response.sendRedirect("login.jsp"); return; }

// Direct insert test
try {
    Connection con = DatabaseConnection.getConnection();
    PreparedStatement ps = con.prepareStatement("INSERT INTO wishlist (user_id, product_id) VALUES (?, 1)");
    ps.setInt(1, userId);
    ps.executeUpdate();
    out.println("Added product ID 1 to wishlist!");
    con.close();
} catch(Exception e) {
    out.println("Error: " + e.getMessage());
}
%>