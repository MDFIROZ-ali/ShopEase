<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.shopping.db.DatabaseConnection"%>
<%@ page import="java.sql.*"%>

<%
String email = request.getParameter("email");
String newPassword = request.getParameter("newPassword");
String confirmPassword = request.getParameter("confirmPassword");

if(!newPassword.equals(confirmPassword)) {
    response.sendRedirect("forgotPassword.jsp?step=reset&email=" + email + "&msg=mismatch");
    return;
}

if(newPassword.length() < 4) {
    response.sendRedirect("forgotPassword.jsp?step=reset&email=" + email + "&msg=short");
    return;
}

try {
    Connection con = DatabaseConnection.getConnection();
    PreparedStatement ps = con.prepareStatement("UPDATE users SET password=? WHERE email=?");
    ps.setString(1, newPassword);
    ps.setString(2, email);
    int result = ps.executeUpdate();
    
    if(result > 0) {
        response.sendRedirect("login.jsp?msg=passwordreset");
    } else {
        response.sendRedirect("forgotPassword.jsp?step=reset&email=" + email + "&msg=error");
    }
    con.close();
} catch(Exception e) {
    System.out.println("Error: " + e);
    response.sendRedirect("forgotPassword.jsp?step=reset&email=" + email + "&msg=error");
}
%>