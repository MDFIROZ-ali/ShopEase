<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.shopping.db.DatabaseConnection"%>
<%@ page import="java.sql.*"%>
<%@ page import="java.text.*"%>

<%
Integer userId = (Integer) session.getAttribute("userId");
String email = (String) session.getAttribute("email");

if(userId == null) {
    response.sendRedirect("../login.jsp");
    return;
}
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Cart - ShopEase Luxury</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Space Grotesk', sans-serif;
            background: #0a0a0a;
            color: #ffffff;
        }
        
        /* Premium Navbar */
        .navbar {
            background: rgba(10, 10, 10, 0.95);
            backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(212, 175, 55, 0.2);
            padding: 18px 0;
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        
        .navbar-brand {
            font-size: 28px;
            font-weight: 700;
            background: linear-gradient(135deg, #fff, #d4af37);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
        
        .navbar-brand i {
            color: #d4af37;
        }
        
        .nav-link {
            color: rgba(255, 255, 255, 0.8) !important;
            margin: 0 15px;
            transition: 0.3s;
        }
        
        .nav-link:hover {
            color: #d4af37 !important;
        }
        
        /* Cart Container */
        .cart-container {
            max-width: 1200px;
            margin: 40px auto;
            padding: 0 20px;
        }
        
        .cart-header {
            text-align: center;
            margin-bottom: 40px;
        }
        
        .cart-header h1 {
            font-size: 42px;
            font-weight: 700;
            background: linear-gradient(135deg, #fff, #d4af37);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            margin-bottom: 10px;
        }
        
        .cart-header p {
            color: rgba(255, 255, 255, 0.6);
        }
        
        /* Cart Table */
        .cart-table {
            background: rgba(20, 20, 30, 0.6);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            overflow: hidden;
            border: 1px solid rgba(212, 175, 55, 0.15);
        }
        
        .cart-table thead th {
            background: rgba(212, 175, 55, 0.1);
            color: #d4af37;
            padding: 18px;
            font-weight: 600;
            border-bottom: 1px solid rgba(212, 175, 55, 0.2);
        }
        
        .cart-table tbody td {
            padding: 20px;
            vertical-align: middle;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            color: rgba(255, 255, 255, 0.9);
        }
        
        .product-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .product-icon {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, #d4af37, #b8960c);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .product-icon i {
            font-size: 28px;
            color: #0a0a0a;
        }
        
        .product-name {
            font-weight: 600;
            font-size: 16px;
        }
        
        .product-category {
            font-size: 12px;
            color: rgba(255, 255, 255, 0.5);
        }
        
        .price {
            font-weight: 600;
            color: #d4af37;
        }
        
        .quantity-control {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .quantity-btn {
            width: 32px;
            height: 32px;
            background: rgba(212, 175, 55, 0.2);
            border: 1px solid rgba(212, 175, 55, 0.3);
            border-radius: 50%;
            color: #d4af37;
            cursor: pointer;
            transition: 0.3s;
        }
        
        .quantity-btn:hover {
            background: #d4af37;
            color: #0a0a0a;
            transform: scale(1.05);
        }
        
        .quantity-value {
            font-weight: 600;
            min-width: 30px;
            text-align: center;
        }
        
        .total-price {
            font-weight: 700;
            font-size: 18px;
            color: #d4af37;
        }
        
        .remove-btn {
            background: rgba(220, 53, 69, 0.2);
            border: 1px solid rgba(220, 53, 69, 0.3);
            border-radius: 25px;
            padding: 6px 15px;
            color: #ff6b6b;
            cursor: pointer;
            transition: 0.3s;
        }
        
        .remove-btn:hover {
            background: #dc3545;
            color: white;
        }
        
        /* Cart Summary */
        .cart-summary {
            background: rgba(20, 20, 30, 0.6);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-top: 30px;
            border: 1px solid rgba(212, 175, 55, 0.15);
        }
        
        .summary-row {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
        }
        
        .summary-label {
            color: rgba(255, 255, 255, 0.7);
        }
        
        .summary-value {
            font-weight: 600;
            color: white;
        }
        
        .grand-total {
            border-top: 1px solid rgba(212, 175, 55, 0.2);
            margin-top: 10px;
            padding-top: 15px;
        }
        
        .grand-total .summary-label,
        .grand-total .summary-value {
            font-size: 22px;
            font-weight: 700;
            color: #d4af37;
        }
        
        .checkout-btn {
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, #d4af37, #b8960c);
            color: #0a0a0a;
            border: none;
            border-radius: 50px;
            font-weight: 700;
            font-size: 18px;
            margin-top: 20px;
            transition: 0.3s;
        }
        
        .checkout-btn:hover {
            transform: scale(1.02);
            box-shadow: 0 0 25px rgba(212, 175, 55, 0.5);
        }
        
        /* Empty Cart */
        .empty-cart {
            text-align: center;
            padding: 80px 20px;
            background: rgba(20, 20, 30, 0.6);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            border: 1px solid rgba(212, 175, 55, 0.15);
        }
        
        .empty-cart i {
            font-size: 80px;
            color: rgba(212, 175, 55, 0.3);
            margin-bottom: 20px;
        }
        
        .empty-cart h3 {
            margin-bottom: 15px;
        }
        
        .empty-cart p {
            color: rgba(255, 255, 255, 0.6);
            margin-bottom: 25px;
        }
        
        .shop-now-btn {
            background: linear-gradient(135deg, #d4af37, #b8960c);
            color: #0a0a0a;
            padding: 12px 35px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 600;
            display: inline-block;
            transition: 0.3s;
        }
        
        .shop-now-btn:hover {
            transform: scale(1.05);
            box-shadow: 0 0 20px rgba(212, 175, 55, 0.4);
        }
        
        /* Footer */
        .footer {
            background: #050505;
            border-top: 1px solid rgba(212, 175, 55, 0.2);
            padding: 40px 0;
            text-align: center;
            margin-top: 50px;
        }
        
        .footer p {
            color: rgba(255, 255, 255, 0.5);
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .cart-table thead {
                display: none;
            }
            .cart-table tbody tr {
                display: block;
                margin-bottom: 20px;
                border: 1px solid rgba(212, 175, 55, 0.2);
                border-radius: 15px;
            }
            .cart-table tbody td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 12px 15px;
            }
            .cart-table tbody td:before {
                content: attr(data-label);
                font-weight: 600;
                color: #d4af37;
            }
            .product-info {
                flex-direction: column;
                text-align: center;
            }
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="../index.jsp">
            <i class="fas fa-crown"></i> ShopEase
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon" style="filter: invert(1);"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="../index.jsp">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="products.jsp">Products</a></li>
                <li class="nav-item"><a class="nav-link" href="cart.jsp"><i class="fas fa-shopping-cart"></i> Cart</a></li>
                <li class="nav-item"><a class="nav-link" href="wishlist.jsp"><i class="fas fa-heart"></i> Wishlist</a></li>
                <li class="nav-item"><a class="nav-link" href="orders.jsp">Orders</a></li>
                <li class="nav-item"><a class="nav-link" href="../logout.jsp">Logout</a></li>
                <li class="nav-item"><span style="color: #d4af37;"><i class="fas fa-user-circle"></i> <%=email%></span></li>
            </ul>
        </div>
    </div>
</nav>

<!-- Cart Container -->
<div class="cart-container">
    <div class="cart-header">
        <h1><i class="fas fa-shopping-bag"></i> Your Cart</h1>
        <p>Review and modify your luxury selections</p>
    </div>
    
    <%
    DecimalFormat df = new DecimalFormat("#,###");
    int grandTotal = 0;
    boolean hasItems = false;
    
    try {
        Connection con = DatabaseConnection.getConnection();
        PreparedStatement ps = con.prepareStatement(
            "SELECT c.id, p.name, p.category, p.price, c.quantity FROM cart c " +
            "JOIN product p ON c.product_id = p.id WHERE c.user_id = ?"
        );
        ps.setInt(1, userId);
        ResultSet rs = ps.executeQuery();
    %>
    
    <div class="table-responsive">
        <table class="cart-table">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <%
            while(rs.next()) {
                hasItems = true;
                int total = rs.getInt("price") * rs.getInt("quantity");
                grandTotal += total;
                
                String iconClass = "fa-box-open";
                String category = rs.getString("category");
                if("Electronics".equals(category)) iconClass = "fa-mobile-alt";
                else if("Clothing".equals(category)) iconClass = "fa-tshirt";
                else if("Home".equals(category)) iconClass = "fa-home";
                else if("Sports".equals(category)) iconClass = "fa-futbol";
            %>
            <tr>
                <td data-label="Product">
                    <div class="product-info">
                        <div class="product-icon">
                            <i class="fas <%=iconClass%>"></i>
                        </div>
                        <div>
                            <div class="product-name"><%=rs.getString("name")%></div>
                            <div class="product-category"><%=category%></div>
                        </div>
                    </div>
                </td>
                <td data-label="Price" class="price">₹ <%=df.format(rs.getInt("price"))%></td>
                <td data-label="Quantity">
                    <div class="quantity-control">
                        <button class="quantity-btn" onclick="updateQuantity(<%=rs.getInt("id")%>, 'dec')">-</button>
                        <span class="quantity-value"><%=rs.getInt("quantity")%></span>
                        <button class="quantity-btn" onclick="updateQuantity(<%=rs.getInt("id")%>, 'inc')">+</button>
                    </div>
                </td>
                <td data-label="Total" class="total-price">₹ <%=df.format(total)%></td>
                <td data-label="Action">
                    <button class="remove-btn" onclick="removeItem(<%=rs.getInt("id")%>)">
                        <i class="fas fa-trash-alt"></i> Remove
                    </button>
                </td>
            </tr>
            <% } con.close(); } catch(Exception e) { System.out.println(e); } %>
            </tbody>
        </table>
    </div>
    
    <% if(hasItems) { %>
    <div class="cart-summary">
        <div class="summary-row">
            <span class="summary-label">Subtotal</span>
            <span class="summary-value">₹ <%=df.format(grandTotal)%></span>
        </div>
        <div class="summary-row">
            <span class="summary-label">Shipping</span>
            <span class="summary-value">Free</span>
        </div>
        <div class="summary-row grand-total">
            <span class="summary-label">Grand Total</span>
            <span class="summary-value">₹ <%=df.format(grandTotal)%></span>
        </div>
        <button class="checkout-btn" onclick="checkout()">
            <i class="fas fa-credit-card"></i> Proceed to Checkout
        </button>
    </div>
    <% } else { %>
    <div class="empty-cart">
        <i class="fas fa-shopping-cart"></i>
        <h3>Your cart is empty</h3>
        <p>Looks like you haven't added any luxury items yet</p>
        <a href="products.jsp" class="shop-now-btn">Explore Collection <i class="fas fa-arrow-right"></i></a>
    </div>
    <% } %>
</div>

<!-- Footer -->
<footer class="footer">
    <div class="container">
        <p>&copy; 2024 ShopEase Luxury. All rights reserved. | Free shipping on orders above ₹999</p>
    </div>
</footer>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function updateQuantity(cartId, action) {
    window.location.href = '../incDecQuantityAction.jsp?id=' + cartId + '&action=' + action;
}

function removeItem(cartId) {
    if(confirm('Remove this item from your cart?')) {
        window.location.href = '../removeFromCart.jsp?id=' + cartId;
    }
}

function checkout() {
    window.location.href = 'checkout.jsp';
}
</script>
</body>
</html>