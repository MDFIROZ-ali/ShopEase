<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.shopping.db.DatabaseConnection"%>
<%@ page import="java.sql.*"%>
<%@ page import="java.text.*"%>

<%
Integer userId = (Integer) session.getAttribute("userId");
String email = (String) session.getAttribute("email");

if(userId == null) {
    response.sendRedirect("../login.jsp");
    return;
}
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - ShopEase Luxury</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Space Grotesk', sans-serif;
            background: #0a0a0a;
            color: #ffffff;
        }
        
        /* Premium Navbar */
        .navbar {
            background: rgba(10, 10, 10, 0.95);
            backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(212, 175, 55, 0.2);
            padding: 18px 0;
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        
        .navbar-brand {
            font-size: 28px;
            font-weight: 700;
            background: linear-gradient(135deg, #fff, #d4af37);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
        
        .navbar-brand i {
            color: #d4af37;
        }
        
        .nav-link {
            color: rgba(255, 255, 255, 0.8) !important;
            margin: 0 15px;
            transition: 0.3s;
        }
        
        .nav-link:hover {
            color: #d4af37 !important;
        }
        
        /* Checkout Container */
        .checkout-container {
            max-width: 1200px;
            margin: 40px auto;
            padding: 0 20px;
        }
        
        .checkout-header {
            text-align: center;
            margin-bottom: 40px;
        }
        
        .checkout-header h1 {
            font-size: 42px;
            font-weight: 700;
            background: linear-gradient(135deg, #fff, #d4af37);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            margin-bottom: 10px;
        }
        
        .checkout-header p {
            color: rgba(255, 255, 255, 0.6);
        }
        
        /* Checkout Card */
        .checkout-card {
            background: rgba(20, 20, 30, 0.6);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(212, 175, 55, 0.2);
            border-radius: 25px;
            padding: 35px;
            transition: 0.3s;
        }
        
        .checkout-card:hover {
            border-color: rgba(212, 175, 55, 0.4);
        }
        
        .section-title {
            font-size: 20px;
            font-weight: 600;
            color: #d4af37;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid rgba(212, 175, 55, 0.2);
        }
        
        /* Form Styles */
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: rgba(255, 255, 255, 0.8);
            font-weight: 500;
            font-size: 14px;
        }
        
        .form-control {
            width: 100%;
            padding: 14px 18px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(212, 175, 55, 0.2);
            border-radius: 12px;
            color: white;
            font-size: 15px;
            transition: 0.3s;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #d4af37;
            box-shadow: 0 0 15px rgba(212, 175, 55, 0.2);
            background: rgba(255, 255, 255, 0.08);
        }
        
        textarea.form-control {
            resize: vertical;
            min-height: 100px;
        }
        
        /* Payment Methods */
        .payment-methods {
            display: flex;
            flex-direction: column;
            gap: 12px;
            margin-top: 15px;
        }
        
        .payment-option {
            display: flex;
            align-items: center;
            padding: 15px;
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid rgba(212, 175, 55, 0.15);
            border-radius: 12px;
            cursor: pointer;
            transition: 0.3s;
        }
        
        .payment-option:hover {
            background: rgba(212, 175, 55, 0.1);
            border-color: rgba(212, 175, 55, 0.3);
        }
        
        .payment-option input {
            margin-right: 15px;
            accent-color: #d4af37;
            width: 18px;
            height: 18px;
        }
        
        .payment-option label {
            flex: 1;
            cursor: pointer;
            margin: 0;
            font-weight: 500;
        }
        
        .payment-option i {
            font-size: 24px;
            color: #d4af37;
            margin-right: 15px;
        }
        
        /* Order Summary */
        .order-summary {
            background: rgba(0, 0, 0, 0.3);
            border-radius: 20px;
            padding: 25px;
        }
        
        .summary-item {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }
        
        .summary-item:last-child {
            border-bottom: none;
        }
        
        .summary-label {
            color: rgba(255, 255, 255, 0.7);
        }
        
        .summary-value {
            font-weight: 600;
            color: white;
        }
        
        .summary-total {
            margin-top: 15px;
            padding-top: 15px;
            border-top: 2px solid rgba(212, 175, 55, 0.3);
        }
        
        .summary-total .summary-label,
        .summary-total .summary-value {
            font-size: 20px;
            font-weight: 700;
            color: #d4af37;
        }
        
        /* Place Order Button */
        .btn-place-order {
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, #d4af37, #b8960c);
            color: #0a0a0a;
            border: none;
            border-radius: 50px;
            font-size: 18px;
            font-weight: 700;
            margin-top: 25px;
            transition: 0.3s;
            cursor: pointer;
        }
        
        .btn-place-order:hover {
            transform: scale(1.02);
            box-shadow: 0 0 25px rgba(212, 175, 55, 0.5);
        }
        
        /* Empty Cart */
        .empty-cart {
            text-align: center;
            padding: 60px;
            background: rgba(20, 20, 30, 0.6);
            backdrop-filter: blur(10px);
            border-radius: 25px;
            border: 1px solid rgba(212, 175, 55, 0.2);
        }
        
        .empty-cart i {
            font-size: 80px;
            color: rgba(212, 175, 55, 0.3);
            margin-bottom: 20px;
        }
        
        .empty-cart h3 {
            margin-bottom: 15px;
        }
        
        .empty-cart p {
            color: rgba(255, 255, 255, 0.6);
            margin-bottom: 25px;
        }
        
        /* Alert Messages */
        .alert {
            padding: 15px 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            font-size: 14px;
        }
        
        .alert-danger {
            background: rgba(220, 53, 69, 0.2);
            border: 1px solid rgba(220, 53, 69, 0.3);
            color: #ff6b6b;
        }
        
        /* Footer */
        .footer {
            background: #050505;
            border-top: 1px solid rgba(212, 175, 55, 0.2);
            padding: 40px 0;
            text-align: center;
            margin-top: 50px;
        }
        
        .footer p {
            color: rgba(255, 255, 255, 0.5);
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .checkout-card {
                padding: 25px;
            }
            .checkout-header h1 {
                font-size: 32px;
            }
            .payment-option i {
                display: none;
            }
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="../index.jsp">
            <i class="fas fa-crown"></i> ShopEase
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon" style="filter: invert(1);"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="../index.jsp">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="products.jsp">Products</a></li>
                <li class="nav-item"><a class="nav-link" href="cart.jsp">Cart</a></li>
                <li class="nav-item"><a class="nav-link" href="wishlist.jsp">Wishlist</a></li>
                <li class="nav-item"><a class="nav-link" href="orders.jsp">Orders</a></li>
                <li class="nav-item"><a class="nav-link" href="../logout.jsp">Logout</a></li>
                <li class="nav-item"><span style="color: #d4af37;"><i class="fas fa-user-circle"></i> <%=email%></span></li>
            </ul>
        </div>
    </div>
</nav>

<!-- Checkout Container -->
<div class="checkout-container">
    <div class="checkout-header">
        <h1><i class="fas fa-credit-card"></i> Secure Checkout</h1>
        <p>Complete your luxury purchase with confidence</p>
    </div>
    
    <%
    // Check if cart has items
    int cartItemCount = 0;
    try {
        Connection con = DatabaseConnection.getConnection();
        PreparedStatement ps = con.prepareStatement("SELECT COUNT(*) as count FROM cart WHERE user_id = ? AND address IS NULL");
        ps.setInt(1, userId);
        ResultSet rs = ps.executeQuery();
        if(rs.next()) {
            cartItemCount = rs.getInt("count");
        }
        con.close();
    } catch(Exception e) {
        System.out.println(e);
    }
    
    if(cartItemCount == 0) {
    %>
    <div class="empty-cart">
        <i class="fas fa-shopping-cart"></i>
        <h3>Your cart is empty</h3>
        <p>Add some luxury items to your cart before checkout</p>
        <a href="products.jsp" class="btn-action" style="background: linear-gradient(135deg, #d4af37, #b8960c); color: #0a0a0a; padding: 12px 35px; border-radius: 50px; text-decoration: none; font-weight: 600;">Explore Products</a>
    </div>
    <%
    } else {
    %>
    
    <div class="row">
        <div class="col-lg-7">
            <div class="checkout-card">
                <h3 class="section-title"><i class="fas fa-map-marker-alt"></i> Shipping Address</h3>
                
                <%
                String msg = request.getParameter("msg");
                if("error".equals(msg)) {
                %>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> Failed to place order! Please try again.
                </div>
                <% } %>
                
                <form action="../addressPaymentForOrderAction.jsp" method="post" id="checkoutForm">
                    <div class="form-group">
                        <label>Full Address</label>
                        <textarea name="address" class="form-control" placeholder="Enter your complete address" required></textarea>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>City</label>
                                <input type="text" name="city" class="form-control" placeholder="City" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>State</label>
                                <input type="text" name="state" class="form-control" placeholder="State" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Country</label>
                                <input type="text" name="country" class="form-control" placeholder="Country" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Mobile Number</label>
                                <input type="tel" name="mobileNumber" class="form-control" placeholder="Mobile Number" required>
                            </div>
                        </div>
                    </div>
                    
                    <h3 class="section-title mt-4"><i class="fas fa-wallet"></i> Payment Method</h3>
                    
                    <div class="payment-methods">
                        <div class="payment-option">
                            <input type="radio" name="paymentMethod" id="cod" value="COD" checked>
                            <i class="fas fa-money-bill-wave"></i>
                            <label for="cod">Cash on Delivery (COD)</label>
                        </div>
                        <div class="payment-option">
                            <input type="radio" name="paymentMethod" id="card" value="Card">
                            <i class="fab fa-cc-visa"></i>
                            <label for="card">Credit / Debit Card</label>
                        </div>
                        <div class="payment-option">
                            <input type="radio" name="paymentMethod" id="upi" value="UPI">
                            <i class="fas fa-qrcode"></i>
                            <label for="upi">UPI (Google Pay, PhonePe, Paytm)</label>
                        </div>
                        <div class="payment-option">
                            <input type="radio" name="paymentMethod" id="netbanking" value="NetBanking">
                            <i class="fas fa-university"></i>
                            <label for="netbanking">Net Banking</label>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn-place-order">
                        <i class="fas fa-check-circle"></i> Place Order
                    </button>
                </form>
            </div>
        </div>
        
        <div class="col-lg-5">
            <div class="checkout-card">
                <h3 class="section-title"><i class="fas fa-receipt"></i> Order Summary</h3>
                
                <%
                DecimalFormat df = new DecimalFormat("#,###");
                int subtotal = 0;
                try {
                    Connection con = DatabaseConnection.getConnection();
                    PreparedStatement ps = con.prepareStatement(
                        "SELECT p.name, c.quantity, (p.price * c.quantity) as total FROM cart c " +
                        "JOIN product p ON c.product_id = p.id WHERE c.user_id = ? AND c.address IS NULL"
                    );
                    ps.setInt(1, userId);
                    ResultSet rs = ps.executeQuery();
                    
                    while(rs.next()) {
                        int total = rs.getInt("total");
                        subtotal += total;
                %>
                <div class="summary-item">
                    <span class="summary-label"><%=rs.getString("name")%> x <%=rs.getInt("quantity")%></span>
                    <span class="summary-value">₹ <%=df.format(total)%></span>
                </div>
                <%
                    }
                    
                    int shipping = subtotal > 999 ? 0 : 50;
                    int tax = (int)Math.round(subtotal * 0.18);
                    int total = subtotal + shipping + tax;
                    con.close();
                %>
                
                <div class="summary-item">
                    <span class="summary-label">Subtotal</span>
                    <span class="summary-value">₹ <%=df.format(subtotal)%></span>
                </div>
                <div class="summary-item">
                    <span class="summary-label">Shipping</span>
                    <span class="summary-value"><%=shipping == 0 ? "FREE" : "₹ " + shipping%></span>
                </div>
                <div class="summary-item">
                    <span class="summary-label">Tax (GST 18%)</span>
                    <span class="summary-value">₹ <%=df.format(tax)%></span>
                </div>
                <div class="summary-item summary-total">
                    <span class="summary-label">Total Amount</span>
                    <span class="summary-value">₹ <%=df.format(total)%></span>
                </div>
                
                <%
                } catch(Exception e) {
                    System.out.println("Checkout error: " + e);
                }
                %>
            </div>
        </div>
    </div>
    <% } %>
</div>

<!-- Footer -->
<footer class="footer">
    <div class="container">
        <p>&copy; 2024 ShopEase Luxury. All rights reserved. | Free shipping on orders above ₹999</p>
    </div>
</footer>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Form validation
document.getElementById('checkoutForm')?.addEventListener('submit', function(e) {
    var address = document.querySelector('textarea[name="address"]').value;
    var city = document.querySelector('input[name="city"]').value;
    var mobile = document.querySelector('input[name="mobileNumber"]').value;
    
    if(!address.trim()) {
        alert('Please enter your address');
        e.preventDefault();
        return false;
    }
    if(!city.trim()) {
        alert('Please enter your city');
        e.preventDefault();
        return false;
    }
    if(!mobile.trim()) {
        alert('Please enter your mobile number');
        e.preventDefault();
        return false;
    }
});
</script>
</body>
</html>