<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.shopping.db.DatabaseConnection"%>
<%@ page import="java.sql.*"%>
<%@ page import="java.text.*"%>

<%
Integer userId = (Integer) session.getAttribute("userId");
String email = (String) session.getAttribute("email");

if(userId == null) {
    response.sendRedirect("../login.jsp");
    return;
}
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Orders - ShopEase Luxury</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Space Grotesk', sans-serif;
            background: #0a0a0a;
            color: #ffffff;
        }
        
        /* Navbar */
        .navbar {
            background: rgba(10, 10, 10, 0.95);
            backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(212, 175, 55, 0.2);
            padding: 18px 0;
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        
        .navbar-brand {
            font-size: 28px;
            font-weight: 700;
            background: linear-gradient(135deg, #fff, #d4af37);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
        
        .navbar-brand i {
            color: #d4af37;
        }
        
        .nav-link {
            color: rgba(255, 255, 255, 0.8) !important;
            margin: 0 15px;
            transition: 0.3s;
        }
        
        .nav-link:hover {
            color: #d4af37 !important;
        }
        
        /* Orders Container */
        .orders-container {
            max-width: 1200px;
            margin: 40px auto;
            padding: 0 20px;
        }
        
        .orders-header {
            text-align: center;
            margin-bottom: 40px;
        }
        
        .orders-header h1 {
            font-size: 42px;
            font-weight: 700;
            background: linear-gradient(135deg, #fff, #d4af37);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            margin-bottom: 10px;
        }
        
        .orders-header p {
            color: rgba(255, 255, 255, 0.6);
        }
        
        /* Order Card */
        .order-card {
            background: rgba(20, 20, 30, 0.6);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(212, 175, 55, 0.15);
            border-radius: 20px;
            margin-bottom: 25px;
            overflow: hidden;
            transition: 0.3s;
        }
        
        .order-card:hover {
            border-color: rgba(212, 175, 55, 0.4);
        }
        
        /* Order Header */
        .order-header {
            background: rgba(212, 175, 55, 0.1);
            padding: 18px 25px;
            border-bottom: 1px solid rgba(212, 175, 55, 0.15);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .order-id {
            font-weight: 700;
            color: #d4af37;
        }
        
        .order-date {
            font-size: 13px;
            color: rgba(255, 255, 255, 0.6);
        }
        
        .order-status {
            padding: 5px 15px;
            border-radius: 50px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .status-pending {
            background: rgba(255, 193, 7, 0.2);
            color: #ffc107;
            border: 1px solid rgba(255, 193, 7, 0.3);
        }
        
        .status-processing {
            background: rgba(23, 162, 184, 0.2);
            color: #17a2b8;
            border: 1px solid rgba(23, 162, 184, 0.3);
        }
        
        .status-shipped {
            background: rgba(0, 123, 255, 0.2);
            color: #007bff;
            border: 1px solid rgba(0, 123, 255, 0.3);
        }
        
        .status-delivered {
            background: rgba(40, 167, 69, 0.2);
            color: #28a745;
            border: 1px solid rgba(40, 167, 69, 0.3);
        }
        
        .order-total {
            font-weight: 700;
            font-size: 18px;
            color: #d4af37;
        }
        
        /* Order Body */
        .order-body {
            padding: 20px 25px;
        }
        
        /* Product Item */
        .product-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            flex-wrap: wrap;
            gap: 10px;
        }
        
        .product-item:last-child {
            border-bottom: none;
        }
        
        .product-info {
            display: flex;
            align-items: center;
            gap: 15px;
            flex: 2;
        }
        
        .product-icon {
            width: 45px;
            height: 45px;
            background: linear-gradient(135deg, #d4af37, #b8960c);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .product-icon i {
            font-size: 22px;
            color: #0a0a0a;
        }
        
        .product-details {
            flex: 1;
        }
        
        .product-name {
            font-weight: 600;
            margin-bottom: 3px;
        }
        
        .product-category {
            font-size: 11px;
            color: rgba(255, 255, 255, 0.5);
        }
        
        .product-quantity {
            font-size: 13px;
            color: rgba(255, 255, 255, 0.7);
            min-width: 80px;
            text-align: center;
        }
        
        .product-price {
            font-weight: 600;
            color: #d4af37;
            min-width: 100px;
            text-align: right;
        }
        
        /* Order Footer */
        .order-footer {
            background: rgba(0, 0, 0, 0.2);
            padding: 15px 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
            border-top: 1px solid rgba(212, 175, 55, 0.1);
        }
        
        .shipping-info {
            font-size: 13px;
            color: rgba(255, 255, 255, 0.6);
        }
        
        .shipping-info i {
            color: #d4af37;
            margin-right: 5px;
        }
        
        .track-btn {
            background: transparent;
            border: 1px solid #d4af37;
            color: #d4af37;
            padding: 8px 20px;
            border-radius: 50px;
            font-weight: 600;
            transition: 0.3s;
            cursor: pointer;
        }
        
        .track-btn:hover {
            background: #d4af37;
            color: #0a0a0a;
        }
        
        /* Empty State */
        .empty-orders {
            text-align: center;
            padding: 80px 20px;
            background: rgba(20, 20, 30, 0.6);
            backdrop-filter: blur(10px);
            border-radius: 25px;
            border: 1px solid rgba(212, 175, 55, 0.15);
        }
        
        .empty-orders i {
            font-size: 80px;
            color: rgba(212, 175, 55, 0.3);
            margin-bottom: 20px;
        }
        
        .empty-orders h3 {
            margin-bottom: 15px;
        }
        
        .empty-orders p {
            color: rgba(255, 255, 255, 0.6);
            margin-bottom: 25px;
        }
        
        .shop-btn {
            background: linear-gradient(135deg, #d4af37, #b8960c);
            color: #0a0a0a;
            padding: 12px 35px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 600;
            display: inline-block;
        }
        
        /* Alert */
        .alert {
            padding: 15px 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            font-size: 14px;
        }
        
        .alert-success {
            background: rgba(40, 167, 69, 0.2);
            border: 1px solid rgba(40, 167, 69, 0.3);
            color: #6bff6b;
        }
        
        /* Footer */
        .footer {
            background: #050505;
            border-top: 1px solid rgba(212, 175, 55, 0.2);
            padding: 40px 0;
            text-align: center;
            margin-top: 50px;
        }
        
        .footer p {
            color: rgba(255, 255, 255, 0.5);
        }
        
        @media (max-width: 768px) {
            .orders-header h1 {
                font-size: 32px;
            }
            .order-header {
                flex-direction: column;
                text-align: center;
            }
            .order-footer {
                flex-direction: column;
                text-align: center;
            }
            .product-item {
                flex-direction: column;
                text-align: center;
            }
            .product-info {
                flex-direction: column;
            }
            .product-price {
                text-align: center;
            }
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="../index.jsp">
            <i class="fas fa-crown"></i> ShopEase
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon" style="filter: invert(1);"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="../index.jsp">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="products.jsp">Products</a></li>
                <li class="nav-item"><a class="nav-link" href="cart.jsp">Cart</a></li>
                <li class="nav-item"><a class="nav-link" href="wishlist.jsp">Wishlist</a></li>
                <li class="nav-item"><a class="nav-link active" href="orders.jsp">Orders</a></li>
                <li class="nav-item"><a class="nav-link" href="../logout.jsp">Logout</a></li>
                <li class="nav-item"><span style="color: #d4af37;"><i class="fas fa-user-circle"></i> <%=email%></span></li>
            </ul>
        </div>
    </div>
</nav>

<!-- Orders Container -->
<div class="orders-container">
    <div class="orders-header">
        <h1><i class="fas fa-box"></i> My Orders</h1>
        <p>Track and manage your luxury purchases</p>
    </div>
    
    <%
    String msg = request.getParameter("msg");
    if("success".equals(msg) || "placed".equals(msg)) {
    %>
    <div class="alert alert-success">
        <i class="fas fa-check-circle"></i> Order placed successfully!
    </div>
    <% } %>
    
    <%
    DecimalFormat df = new DecimalFormat("#,###");
    boolean hasOrders = false;
    int lastOrderId = -1;
    
    try {
        Connection con = DatabaseConnection.getConnection();
        PreparedStatement ps = con.prepareStatement(
            "SELECT c.*, p.name as product_name, p.price as product_price, p.category " +
            "FROM cart c " +
            "JOIN product p ON c.product_id = p.id " +
            "WHERE c.user_id = ? AND c.address IS NOT NULL " +
            "ORDER BY c.orderDate DESC, c.id DESC"
        );
        ps.setInt(1, userId);
        ResultSet rs = ps.executeQuery();
        
        while(rs.next()) {
            hasOrders = true;
            int orderId = rs.getInt("id");
            String status = rs.getString("status");
            if(status == null) status = "pending";
            
            String statusClass = "status-pending";
            if("processing".equals(status)) statusClass = "status-processing";
            else if("shipped".equals(status)) statusClass = "status-shipped";
            else if("delivered".equals(status)) statusClass = "status-delivered";
            
            String orderDate = rs.getString("orderDate");
            if(orderDate == null) orderDate = rs.getString("created_at");
            if(orderDate == null) orderDate = "Processing";
            
            int orderTotal = rs.getInt("total");
            if(orderTotal == 0) {
                orderTotal = rs.getInt("product_price") * rs.getInt("quantity");
            }
            
            String address = rs.getString("address");
            String city = rs.getString("city");
            String state = rs.getString("state");
            
            String category = rs.getString("category");
            String icon = "fa-box-open";
            if("Electronics".equals(category)) icon = "fa-laptop";
            else if("Clothing".equals(category)) icon = "fa-tshirt";
            else if("Home".equals(category)) icon = "fa-home";
            else if("Sports".equals(category)) icon = "fa-futbol";
    %>
    <!-- Order Card -->
    <div class="order-card">
        <div class="order-header">
            <div>
                <span class="order-id">Order #<%=orderId%></span>
                <div class="order-date"><i class="far fa-calendar-alt"></i> <%=orderDate%></div>
            </div>
            <div>
                <span class="order-status <%=statusClass%>"><%=status.toUpperCase()%></span>
            </div>
            <div>
                <span class="order-total">Total: ₹ <%=df.format(orderTotal)%></span>
            </div>
        </div>
        <div class="order-body">
            <div class="product-item">
                <div class="product-info">
                    <div class="product-icon">
                        <i class="fas <%=icon%>"></i>
                    </div>
                    <div class="product-details">
                        <div class="product-name"><%=rs.getString("product_name")%></div>
                        <div class="product-category"><%=category%></div>
                    </div>
                </div>
                <div class="product-quantity">Qty: <%=rs.getInt("quantity")%></div>
                <div class="product-price">₹ <%=df.format(rs.getInt("product_price"))%></div>
            </div>
        </div>
        <div class="order-footer">
            <div class="shipping-info">
                <i class="fas fa-truck"></i> 
                <% if(address != null && !address.isEmpty()) { %>
                    Shipping to: <%=address%>, <%=city%>, <%=state%>
                <% } else { %>
                    Free shipping on all orders
                <% } %>
            </div>
            <button class="track-btn" onclick="alert('Track your order via email/SMS. Tracking number will be sent soon.')">
                <i class="fas fa-map-marker-alt"></i> Track Order
            </button>
        </div>
    </div>
    <%
        }
        con.close();
    } catch(Exception e) {
        System.out.println("Orders error: " + e);
    }
    
    if(!hasOrders) {
    %>
    <!-- Empty State -->
    <div class="empty-orders">
        <i class="fas fa-shopping-bag"></i>
        <h3>No Orders Yet</h3>
        <p>Your order history is empty. Start exploring our luxury collection!</p>
        <a href="products.jsp" class="shop-btn">
            <i class="fas fa-shopping-bag"></i> Start Shopping
        </a>
    </div>
    <% } %>
</div>

<!-- Footer -->
<footer class="footer">
    <div class="container">
        <p>&copy; 2026 ShopEase Luxury. All rights reserved. | Free shipping on orders above ₹999</p>
    </div>
</footer>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>