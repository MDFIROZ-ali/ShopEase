<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.shopping.db.DatabaseConnection"%>
<%@ page import="java.sql.*"%>
<%@ page import="java.text.*"%>

<%
Integer userId = (Integer) session.getAttribute("userId");
String email = (String) session.getAttribute("email");

if(userId == null) {
    response.sendRedirect("../login.jsp");
    return;
}
%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Products - ShopEase</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #0a0a0a; font-family: 'Segoe UI', sans-serif; color: white; }
        .navbar { background: #1a1a2e; padding: 15px 0; }
        .navbar a { color: white; text-decoration: none; margin: 0 15px; }
        
        .product-card { 
            background: rgba(20,20,30,0.6); 
            border-radius: 15px; 
            overflow: hidden; 
            margin-bottom: 30px; 
            position: relative; 
            transition: 0.3s; 
        }
        .product-card:hover { transform: translateY(-5px); box-shadow: 0 10px 25px rgba(0,0,0,0.3); }
        
        .product-img { height: 200px; overflow: hidden; }
        .product-img img { width: 100%; height: 100%; object-fit: cover; }
        
        .product-info { padding: 20px; text-align: center; }
        .product-title { font-size: 18px; font-weight: bold; }
        .product-price { font-size: 22px; color: #d4af37; font-weight: bold; }
        
        .btn-add { 
            width: 100%; 
            padding: 10px; 
            background: #d4af37; 
            color: #0a0a0a; 
            border: none; 
            border-radius: 25px; 
            cursor: pointer; 
            font-weight: bold; 
        }
        
        /* Improved Wishlist Button */
        .wishlist-btn {
            position: absolute;
            top: 15px;
            right: 15px;
            background: rgba(0,0,0,0.5);
            backdrop-filter: blur(4px);
            border: 1px solid rgba(255,255,255,0.2);
            border-radius: 50%;
            width: 38px;
            height: 38px;
            cursor: pointer;
            z-index: 10;
            transition: 0.3s;
            color: white;
            font-size: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .wishlist-btn:hover {
            transform: scale(1.15);
            background: rgba(0,0,0,0.7);
            border-color: #d4af37;
        }
        
        .wishlist-btn.active {
            color: #ff4757;
            background: rgba(0,0,0,0.6);
            border-color: #ff4757;
        }
        
        .wishlist-btn.active:hover {
            transform: scale(1.15);
        }
        
        footer { background: #050505; text-align: center; padding: 30px; margin-top: 50px; }
    </style>
</head>
<body>

<div class="navbar">
    <div class="container">
        <a href="../index.jsp">ShopEase</a>
        <div style="float: right;">
            <a href="products.jsp">Products</a>
            <a href="cart.jsp">Cart</a>
            <a href="wishlist.jsp">Wishlist</a>
            <a href="orders.jsp">Orders</a>
            <a href="../logout.jsp">Logout</a>
            <span style="color: #d4af37;">Welcome, <%=email%></span>
        </div>
    </div>
</div>

<div class="container mt-4">
    <h2 class="text-center mb-4">All Products</h2>
    <div class="row">
        <%
        DecimalFormat df = new DecimalFormat("#,###");
        try {
            Connection con = DatabaseConnection.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM product WHERE active='Yes' ORDER BY id DESC");
            
            // Get user's wishlist items
            java.util.Set<Integer> wishlistIds = new java.util.HashSet<>();
            PreparedStatement wishPs = con.prepareStatement("SELECT product_id FROM wishlist WHERE user_id=?");
            wishPs.setInt(1, userId);
            ResultSet wishRs = wishPs.executeQuery();
            while(wishRs.next()) {
                wishlistIds.add(wishRs.getInt("product_id"));
            }
            
            while(rs.next()) {
                int productId = rs.getInt("id");
                boolean inWishlist = wishlistIds.contains(productId);
                String imgUrl = rs.getString("image_url");
                if(imgUrl == null || imgUrl.isEmpty()) {
                    imgUrl = "https://via.placeholder.com/300x200/1a1a2e/d4af37?text=" + rs.getString("name").replace(" ", "+");
                }
        %>
        <div class="col-md-3">
            <div class="product-card">
                <button class="wishlist-btn <%=inWishlist ? "active" : ""%>" onclick="toggleWishlist(<%=productId%>, this)">
    <i class="fas fa-heart"></i>
</button>
                <div class="product-img">
                    <img src="<%=imgUrl%>" alt="<%=rs.getString("name")%>">
                </div>
                <div class="product-info">
                    <div class="product-title"><%=rs.getString("name")%></div>
                    <div class="product-category"><%=rs.getString("category")%></div>
                    <div class="product-price">₹ <%=df.format(rs.getInt("price"))%></div>
                    <form action="../addToCartAction.jsp" method="post">
                        <input type="hidden" name="id" value="<%=productId%>">
                        <button type="submit" class="btn-add">Add to Cart</button>
                    </form>
                </div>
            </div>
        </div>
        <%
            }
            con.close();
        } catch(Exception e) {
            System.out.println(e);
        }
        %>
    </div>
</div>

<footer>
    <p>&copy; 2024 ShopEase. All rights reserved.</p>
</footer>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
function toggleWishlist(productId, element) {
    $.ajax({
        url: '../wishlistAction.jsp',
        method: 'POST',
        data: { productId: productId },
        success: function(response) {
            if(response === 'added') {
                $(element).addClass('active');
                showNotification('Added to wishlist!');
            } else if(response === 'removed') {
                $(element).removeClass('active');
                showNotification('Removed from wishlist!');
            } else if(response === 'login') {
                window.location.href = '../login.jsp';
            }
        }
    });
}

function showNotification(message) {
    var notification = $('<div style="position:fixed;bottom:20px;right:20px;background:#d4af37;color:#0a0a0a;padding:12px 25px;border-radius:50px;z-index:9999;">' + message + '</div>');
    $('body').append(notification);
    setTimeout(function() { notification.fadeOut(function() { notification.remove(); }); }, 2000);
}
</script>
</body>
</html>