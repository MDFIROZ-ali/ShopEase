<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.shopping.db.DatabaseConnection"%>
<%@ page import="java.sql.*"%>
<%@ page import="java.text.*"%>

<%
Integer userId = (Integer) session.getAttribute("userId");
String email = (String) session.getAttribute("email");

if(userId == null) {
    response.sendRedirect("../login.jsp");
    return;
}
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Wishlist - ShopEase Luxury</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Space Grotesk', sans-serif;
            background: #0a0a0a;
            color: #ffffff;
        }
        
        .navbar {
            background: rgba(10, 10, 10, 0.95);
            backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(212, 175, 55, 0.2);
            padding: 18px 0;
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        
        .navbar-brand {
            font-size: 28px;
            font-weight: 700;
            background: linear-gradient(135deg, #fff, #d4af37);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
        
        .navbar-brand i {
            color: #d4af37;
        }
        
        .nav-link {
            color: rgba(255, 255, 255, 0.8) !important;
            margin: 0 15px;
            transition: 0.3s;
        }
        
        .nav-link:hover {
            color: #d4af37 !important;
        }
        
        .wishlist-container {
            max-width: 1200px;
            margin: 40px auto;
            padding: 0 20px;
        }
        
        .wishlist-header {
            text-align: center;
            margin-bottom: 40px;
        }
        
        .wishlist-header h1 {
            font-size: 42px;
            font-weight: 700;
            background: linear-gradient(135deg, #fff, #d4af37);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            margin-bottom: 10px;
        }
        
        .wishlist-header p {
            color: rgba(255, 255, 255, 0.6);
        }
        
        .wishlist-card {
            background: rgba(20, 20, 30, 0.6);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            overflow: hidden;
            border: 1px solid rgba(212, 175, 55, 0.15);
            transition: 0.4s;
            margin-bottom: 25px;
        }
        
        .wishlist-card:hover {
            transform: translateY(-5px);
            border-color: #d4af37;
            box-shadow: 0 15px 35px rgba(212, 175, 55, 0.2);
        }
        
        .product-img {
            height: 180px;
            overflow: hidden;
            position: relative;
        }
        
        .product-img img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: 0.5s;
        }
        
        .wishlist-card:hover .product-img img {
            transform: scale(1.05);
        }
        
        .product-badge {
            position: absolute;
            top: 15px;
            left: 15px;
            background: #d4af37;
            color: #0a0a0a;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: bold;
        }
        
        .product-info {
            padding: 20px;
            text-align: center;
        }
        
        .product-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .product-category {
            font-size: 12px;
            color: rgba(255, 255, 255, 0.5);
            margin-bottom: 10px;
        }
        
        .product-price {
            font-size: 22px;
            font-weight: 700;
            color: #d4af37;
            margin: 10px 0;
        }
        
        .rating {
            color: #d4af37;
            margin-bottom: 15px;
            font-size: 13px;
        }
        
        .btn-group {
            display: flex;
            gap: 12px;
            margin-top: 10px;
        }
        
        .btn-move-cart {
            flex: 1;
            background: linear-gradient(135deg, #d4af37, #b8960c);
            color: #0a0a0a;
            border: none;
            border-radius: 50px;
            padding: 10px;
            font-weight: 600;
            transition: 0.3s;
            text-decoration: none;
            display: inline-block;
            text-align: center;
        }
        
        .btn-move-cart:hover {
            transform: scale(1.02);
            box-shadow: 0 0 15px rgba(212, 175, 55, 0.5);
        }
        
        .btn-remove {
            flex: 1;
            background: rgba(220, 53, 69, 0.2);
            border: 1px solid rgba(220, 53, 69, 0.3);
            border-radius: 50px;
            padding: 10px;
            color: #ff6b6b;
            font-weight: 600;
            transition: 0.3s;
            cursor: pointer;
        }
        
        .btn-remove:hover {
            background: #dc3545;
            color: white;
        }
        
        .empty-wishlist {
            text-align: center;
            padding: 80px 20px;
            background: rgba(20, 20, 30, 0.6);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            border: 1px solid rgba(212, 175, 55, 0.15);
        }
        
        .empty-wishlist i {
            font-size: 80px;
            color: rgba(212, 175, 55, 0.3);
            margin-bottom: 20px;
        }
        
        .empty-wishlist h3 {
            margin-bottom: 15px;
        }
        
        .empty-wishlist p {
            color: rgba(255, 255, 255, 0.6);
            margin-bottom: 25px;
        }
        
        .shop-now-btn {
            background: linear-gradient(135deg, #d4af37, #b8960c);
            color: #0a0a0a;
            padding: 12px 35px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 600;
            display: inline-block;
            transition: 0.3s;
        }
        
        .shop-now-btn:hover {
            transform: scale(1.05);
            box-shadow: 0 0 20px rgba(212, 175, 55, 0.4);
        }
        
        .footer {
            background: #050505;
            border-top: 1px solid rgba(212, 175, 55, 0.2);
            padding: 40px 0;
            text-align: center;
            margin-top: 50px;
        }
        
        .footer p {
            color: rgba(255, 255, 255, 0.5);
        }
        
        @media (max-width: 768px) {
            .btn-group {
                flex-direction: column;
            }
            .wishlist-header h1 {
                font-size: 32px;
            }
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="../index.jsp">
            <i class="fas fa-crown"></i> ShopEase
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon" style="filter: invert(1);"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="../index.jsp">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="products.jsp">Products</a></li>
                <li class="nav-item"><a class="nav-link" href="cart.jsp"><i class="fas fa-shopping-cart"></i> Cart</a></li>
                <li class="nav-item"><a class="nav-link" href="wishlist.jsp"><i class="fas fa-heart"></i> Wishlist</a></li>
                <li class="nav-item"><a class="nav-link" href="orders.jsp">Orders</a></li>
                <li class="nav-item"><a class="nav-link" href="../logout.jsp">Logout</a></li>
                <li class="nav-item"><span style="color: #d4af37;"><i class="fas fa-user-circle"></i> <%=email%></span></li>
            </ul>
        </div>
    </div>
</nav>

<div class="wishlist-container">
    <div class="wishlist-header">
        <h1><i class="fas fa-heart"></i> My Wishlist</h1>
        <p>Your curated collection of desired luxury items</p>
    </div>
    
    <div class="row">
        <%
        DecimalFormat df = new DecimalFormat("#,###");
        boolean hasItems = false;
        
        try {
            Connection con = DatabaseConnection.getConnection();
            // REMOVED added_date column from query
            PreparedStatement ps = con.prepareStatement(
                "SELECT p.id, p.name, p.category, p.price, p.image_url FROM wishlist w " +
                "JOIN product p ON w.product_id = p.id WHERE w.user_id = ?"
            );
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()) {
                hasItems = true;
                String imgUrl = rs.getString("image_url");
                if(imgUrl == null || imgUrl.isEmpty()) {
                    imgUrl = "https://via.placeholder.com/300x180/1a1a2e/d4af37?text=" + rs.getString("name").replace(" ", "+");
                }
        %>
        <div class="col-md-3">
            <div class="wishlist-card">
                <div class="product-img">
                    <img src="<%=imgUrl%>" alt="<%=rs.getString("name")%>">
                    <span class="product-badge"><i class="fas fa-heart"></i> Saved</span>
                </div>
                <div class="product-info">
                    <div class="product-title"><%=rs.getString("name")%></div>
                    <div class="product-category"><%=rs.getString("category")%></div>
                    <div class="rating">
                        <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star-half-alt"></i>
                    </div>
                    <div class="product-price">₹ <%=df.format(rs.getInt("price"))%></div>
                    <div class="btn-group">
                        <a href="../addToCartAction.jsp?id=<%=rs.getInt("id")%>" class="btn-move-cart">
                            <i class="fas fa-shopping-cart"></i> Move to Cart
                        </a>
                        <button onclick="removeFromWishlist(<%=rs.getInt("id")%>)" class="btn-remove">
                            <i class="fas fa-trash-alt"></i> Remove
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <% 
            }
            con.close();
        } catch(Exception e) {
            System.out.println("Wishlist error: " + e);
        }
        
        if(!hasItems) {
        %>
        <div class="col-12">
            <div class="empty-wishlist">
                <i class="fas fa-heart-broken"></i>
                <h3>Your wishlist is empty</h3>
                <p>Start adding your favorite luxury items to your wishlist</p>
                <a href="products.jsp" class="shop-now-btn">
                    <i class="fas fa-shopping-bag"></i> Explore Products
                </a>
            </div>
        </div>
        <% } %>
    </div>
</div>

<footer class="footer">
    <div class="container">
        <p>&copy; 2024 ShopEase Luxury. All rights reserved. | Free shipping on orders above ₹999</p>
    </div>
</footer>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function removeFromWishlist(productId) {
    if(confirm('Remove this item from your wishlist?')) {
        window.location.href = '../wishlistAction.jsp?productId=' + productId;
    }
}
</script>
</body>
</html>