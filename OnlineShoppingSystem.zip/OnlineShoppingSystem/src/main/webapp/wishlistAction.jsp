<%@ page import="com.shopping.db.DatabaseConnection"%>
<%@ page import="java.sql.*"%>

<%
Integer userId = (Integer) session.getAttribute("userId");
String productId = request.getParameter("productId");

if(userId == null) {
    out.print("login");
    return;
}

try {
    Connection con = DatabaseConnection.getConnection();
    
    // Check if already exists
    PreparedStatement check = con.prepareStatement("SELECT * FROM wishlist WHERE user_id=? AND product_id=?");
    check.setInt(1, userId);
    check.setString(2, productId);
    ResultSet rs = check.executeQuery();
    
    if(rs.next()) {
        // Remove
        PreparedStatement delete = con.prepareStatement("DELETE FROM wishlist WHERE user_id=? AND product_id=?");
        delete.setInt(1, userId);
        delete.setString(2, productId);
        delete.executeUpdate();
        out.print("removed");
    } else {
        // Add
        PreparedStatement insert = con.prepareStatement("INSERT INTO wishlist (user_id, product_id) VALUES (?, ?)");
        insert.setInt(1, userId);
        insert.setString(2, productId);
        insert.executeUpdate();
        out.print("added");
    }
    con.close();
} catch(Exception e) {
    out.print("error");
}
%>